-- =====================================================================
-- 택시팟 DB 마이그레이션 이력 (설계서 6차 → 14차 ALTER문)
-- 이미 운영 중인 DB에만 위에서부터 순서대로 적용합니다. 신규 DB는 schema.sql 사용.
-- =====================================================================

-- =====================================================================
-- 6차 → 7차 변경 (6차 DDL로 이미 만든 DB에 적용할 ALTER문, 위에서부터 순서대로 실행)
-- 주의: mysql 클라이언트·IDE 연결 문자셋이 utf8mb4여야 함 (아니면 한글 COMMENT와 CHECK의 '탈퇴회원_' 값이 깨짐)
-- 5차 → 6차 ALTER는 6차 설계서 참고 (6차 DB가 아니면 먼저 적용)
-- =====================================================================
SET NAMES utf8mb4;

-- [0] 사전 확인 (모두 0건이어야 함, 결과가 있으면 데이터 정리 후 진행)
SELECT id, capture_img_url FROM STUDENT_VERIFICATION WHERE CHAR_LENGTH(capture_img_url) > 255;
SELECT id, review_status FROM STUDENT_VERIFICATION WHERE capture_img_url IS NULL AND review_status IN ('APPROVED', 'REJECTED');
SELECT id, type, payment_id FROM POINT_HISTORY WHERE (type IN ('CHARGE', 'CHARGE_REFUND')) <> (payment_id IS NOT NULL);
SELECT id, status FROM TAXIPOT WHERE status = 'COMPLETED' AND actual_fare IS NULL;
SELECT id, nickname FROM USERS WHERE status <> 'WITHDRAWN' AND LEFT(nickname, 5) = '탈퇴회원_';

-- [1] 학교 목록 테이블 생성 + 목록 입력 (실제 학교로 교체)
CREATE TABLE UNIVERSITY (
  id BIGINT NOT NULL AUTO_INCREMENT COMMENT '대학교 고유번호',
  name VARCHAR(50) NOT NULL COMMENT '대학교명',
  email_domain VARCHAR(100) NOT NULL COMMENT '학교 이메일 도메인(@ 뒤, 소문자)',
  is_active TINYINT(1) NOT NULL DEFAULT 1 COMMENT '가입 허용 여부',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '등록일시',
  PRIMARY KEY (id),
  UNIQUE KEY uk_university_name (name),
  UNIQUE KEY uk_university_email_domain (email_domain),
  CONSTRAINT chk_university_email_domain CHECK (LOCATE('@', email_domain) = 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='가입 가능 대학교 테이블';
INSERT INTO UNIVERSITY (name, email_domain) VALUES ('한국대학교', 'university.ac.kr');
-- 확인: 0건이어야 FK 추가 가능
SELECT DISTINCT university FROM USERS WHERE university NOT IN (SELECT name FROM UNIVERSITY);

-- [2] USERS
ALTER TABLE USERS MODIFY phone VARCHAR(255) NULL COMMENT '휴대폰번호(AES-256-GCM 암호문)';
ALTER TABLE USERS ADD COLUMN token_version INT NOT NULL DEFAULT 0 COMMENT '토큰 버전' AFTER withdrawn_at;
ALTER TABLE USERS ADD CONSTRAINT chk_users_token_version_rng CHECK (token_version >= 0);
ALTER TABLE USERS ADD CONSTRAINT chk_users_nickname_reserved CHECK (status = 'WITHDRAWN' OR LEFT(nickname, 5) <> '탈퇴회원_');
ALTER TABLE USERS ADD CONSTRAINT fk_users_university FOREIGN KEY (university) REFERENCES UNIVERSITY(name) ON UPDATE CASCADE;

-- [3] STUDENT_VERIFICATION
ALTER TABLE STUDENT_VERIFICATION ADD COLUMN email_code_attempts TINYINT NOT NULL DEFAULT 0 COMMENT '인증코드 입력 실패 횟수' AFTER email_code_expires_at;
ALTER TABLE STUDENT_VERIFICATION ADD CONSTRAINT chk_student_verification_attempts_rng CHECK (email_code_attempts BETWEEN 0 AND 5);
ALTER TABLE STUDENT_VERIFICATION RENAME COLUMN capture_img_url TO capture_img_path;
ALTER TABLE STUDENT_VERIFICATION MODIFY capture_img_path VARCHAR(255) NULL COMMENT '학생정보 캡처 파일 경로(서버 로컬)';
ALTER TABLE STUDENT_VERIFICATION DROP CHECK chk_student_verification_review_status;
ALTER TABLE STUDENT_VERIFICATION MODIFY review_status VARCHAR(15) NOT NULL DEFAULT 'NOT_SUBMITTED' COMMENT '캡처 심사 상태';
UPDATE STUDENT_VERIFICATION SET review_status = 'NOT_SUBMITTED' WHERE capture_img_path IS NULL AND review_status = 'PENDING';
ALTER TABLE STUDENT_VERIFICATION ADD CONSTRAINT chk_student_verification_review_status CHECK (review_status IN ('NOT_SUBMITTED', 'PENDING', 'APPROVED', 'REJECTED'));
ALTER TABLE STUDENT_VERIFICATION ADD CONSTRAINT chk_student_verification_capture_state CHECK ((review_status = 'NOT_SUBMITTED' AND capture_img_path IS NULL) OR (review_status <> 'NOT_SUBMITTED' AND capture_img_path IS NOT NULL));

-- [4] TAXIPOT
ALTER TABLE TAXIPOT MODIFY arrival_deadline DATETIME NOT NULL COMMENT '집결 기한(= 참여 마감)';
ALTER TABLE TAXIPOT ADD COLUMN receipt_img_path VARCHAR(255) NULL COMMENT '결제내역(영수증) 사진 파일 경로(서버 로컬)' AFTER actual_fare;
ALTER TABLE TAXIPOT ADD CONSTRAINT chk_taxipot_actual_fare_rng CHECK (actual_fare >= 0);
ALTER TABLE TAXIPOT ADD CONSTRAINT chk_taxipot_deadline_order CHECK (arrival_deadline < departure_time);
ALTER TABLE TAXIPOT ADD CONSTRAINT chk_taxipot_completed_fare CHECK (status <> 'COMPLETED' OR actual_fare IS NOT NULL);

-- [5] TAXIPOT_MEMBER
ALTER TABLE TAXIPOT_MEMBER MODIFY canceled_at DATETIME NULL COMMENT '취소·퇴장 일시';
ALTER TABLE TAXIPOT_MEMBER DROP CHECK chk_taxipot_member_status;
ALTER TABLE TAXIPOT_MEMBER ADD CONSTRAINT chk_taxipot_member_status CHECK (status IN ('JOINED', 'CANCELED', 'BOARDED', 'NO_SHOW', 'KICKED', 'REQUESTED', 'REJECTED'));

-- [6] SETTLEMENT (수수료는 정산 시점 기록, 노쇼 분담금 NULL, 미수금 관리)
ALTER TABLE SETTLEMENT MODIFY fee_amount INT NULL COMMENT '서비스 수수료(정산 시점 기록)';
UPDATE SETTLEMENT SET fare_share = NULL, fee_amount = NULL, diff_amount = NULL, uncovered_amount = 0 WHERE status <> 'SETTLED';
ALTER TABLE SETTLEMENT MODIFY uncovered_amount INT NOT NULL DEFAULT 0 COMMENT '미수 부족분';
ALTER TABLE SETTLEMENT ADD COLUMN debt_status VARCHAR(10) NOT NULL DEFAULT 'NONE' COMMENT '미수금 상태' AFTER uncovered_amount;
ALTER TABLE SETTLEMENT ADD COLUMN debt_amount INT NOT NULL DEFAULT 0 COMMENT '남은 미수 납부액' AFTER debt_status;
ALTER TABLE SETTLEMENT ADD COLUMN debt_due_at DATETIME NULL COMMENT '미수금 납부 기한' AFTER debt_amount;
ALTER TABLE SETTLEMENT ADD COLUMN debt_paid_at DATETIME NULL COMMENT '미수금 납부 완료 시각' AFTER debt_due_at;
ALTER TABLE SETTLEMENT ADD KEY idx_settle_debt (debt_status, debt_due_at);
ALTER TABLE SETTLEMENT ADD CONSTRAINT chk_settlement_fee_amount_rng CHECK (fee_amount >= 0);
ALTER TABLE SETTLEMENT ADD CONSTRAINT chk_settlement_debt_amount_rng CHECK (debt_amount >= 0);
ALTER TABLE SETTLEMENT ADD CONSTRAINT chk_settlement_debt_status CHECK (debt_status IN ('NONE', 'UNPAID', 'OVERDUE', 'PAID'));
ALTER TABLE SETTLEMENT ADD CONSTRAINT chk_settlement_settled_values CHECK ((status = 'SETTLED' AND fare_share IS NOT NULL AND fee_amount IS NOT NULL AND diff_amount IS NOT NULL) OR (status <> 'SETTLED' AND fare_share IS NULL AND fee_amount IS NULL AND diff_amount IS NULL AND uncovered_amount = 0 AND debt_status = 'NONE'));
ALTER TABLE SETTLEMENT ADD CONSTRAINT chk_settlement_debt_state CHECK ((debt_status = 'NONE' AND debt_amount = 0 AND debt_due_at IS NULL) OR (debt_status IN ('UNPAID', 'OVERDUE') AND debt_amount > 0 AND debt_due_at IS NOT NULL) OR (debt_status = 'PAID' AND debt_amount = 0 AND debt_paid_at IS NOT NULL));

-- [7] RATING
ALTER TABLE RATING ADD COLUMN is_default TINYINT(1) NOT NULL DEFAULT 0 COMMENT '자동 기본 평가 여부' AFTER bad_reason;
ALTER TABLE RATING ADD CONSTRAINT chk_rating_default_values CHECK (is_default = 0 OR (noshow_score = 3 AND manner_score = 3 AND communication_score = 3 AND payment_score = 3 AND bad_reason IS NULL));

-- [8] POINT_HISTORY
ALTER TABLE POINT_HISTORY DROP CHECK chk_point_history_type;
ALTER TABLE POINT_HISTORY ADD CONSTRAINT chk_point_history_type CHECK (type IN ('CHARGE', 'CHARGE_REFUND', 'ADMIN_ADJUST', 'FARE_HOLD', 'FARE_REFUND', 'FARE_ADJUST', 'FARE_PAY', 'FEE', 'HOST_PAYOUT', 'DEBT_PAY', 'BALANCE_EXPIRE'));
ALTER TABLE POINT_HISTORY ADD CONSTRAINT chk_point_history_payment_link CHECK ((type IN ('CHARGE', 'CHARGE_REFUND') AND payment_id IS NOT NULL) OR (type NOT IN ('CHARGE', 'CHARGE_REFUND') AND payment_id IS NULL));
ALTER TABLE POINT_HISTORY ADD CONSTRAINT chk_point_history_balance_after_rng CHECK (balance_after >= 0);

-- [9] PAYMENT (앱 충전은 PORTONE만, DUMMY 코드는 과거 행 호환용으로 CHECK에 남김)
ALTER TABLE PAYMENT ALTER pg_provider SET DEFAULT 'PORTONE';

-- =====================================================================
-- 7차 → 8차 변경: 스키마 변경 없음 (실행할 ALTER문 없음)
-- 미수금 납부 기한 3일·OVERDUE 시 금액 유지·방 생성 최대 24시간은 서버 규칙(API 3.4.0)으로 처리
-- =====================================================================

-- =====================================================================
-- 8차 → 9차 변경 (8차(= 7차 스키마) DB에 적용할 ALTER문, 위에서부터 순서대로 실행)
-- =====================================================================
SET NAMES utf8mb4;

-- [1] USERS: 출금 계좌 (9차 이전 가입자는 NULL — 출금 전 등록)
ALTER TABLE USERS ADD COLUMN bank_code VARCHAR(10) NULL COMMENT '출금 은행 코드' AFTER token_version;
ALTER TABLE USERS ADD COLUMN account_no VARCHAR(255) NULL COMMENT '출금 계좌번호(AES-256-GCM 암호문)' AFTER bank_code;
ALTER TABLE USERS ADD COLUMN account_holder VARCHAR(50) NULL COMMENT '예금주' AFTER account_no;
ALTER TABLE USERS ADD CONSTRAINT chk_users_account_all_or_none CHECK ((bank_code IS NULL AND account_no IS NULL AND account_holder IS NULL) OR (bank_code IS NOT NULL AND account_no IS NOT NULL AND account_holder IS NOT NULL));

-- [2] TAXIPOT: 탑승 시작 시각, 실요금 청구·운영자 확인
ALTER TABLE TAXIPOT ADD COLUMN started_at DATETIME NULL COMMENT '탑승 시작 일시' AFTER receipt_img_path;
ALTER TABLE TAXIPOT ADD COLUMN fare_claim_status VARCHAR(10) NOT NULL DEFAULT 'NONE' COMMENT '실요금 청구 상태' AFTER started_at;
ALTER TABLE TAXIPOT ADD COLUMN fare_claimed_at DATETIME NULL COMMENT '실요금 청구 일시' AFTER fare_claim_status;
ALTER TABLE TAXIPOT ADD COLUMN fare_reviewed_at DATETIME NULL COMMENT '청구 확인 일시' AFTER fare_claimed_at;
ALTER TABLE TAXIPOT ADD COLUMN fare_reject_reason VARCHAR(255) NULL COMMENT '청구 반려 사유' AFTER fare_reviewed_at;
-- 기존 행 정리: 정산 완료 방은 승인된 것으로, 시작 시각은 마지막 수정 시각으로 대체
UPDATE TAXIPOT SET fare_claim_status = 'APPROVED', fare_reviewed_at = updated_at, started_at = updated_at WHERE status = 'COMPLETED';
UPDATE TAXIPOT SET started_at = updated_at WHERE status = 'RUNNING' AND started_at IS NULL;
ALTER TABLE TAXIPOT ADD KEY idx_pot_fare_claim (fare_claim_status, fare_claimed_at);
ALTER TABLE TAXIPOT ADD CONSTRAINT chk_taxipot_fare_claim_status CHECK (fare_claim_status IN ('NONE', 'PENDING', 'APPROVED', 'REJECTED', 'OVERDUE'));
ALTER TABLE TAXIPOT ADD CONSTRAINT chk_taxipot_completed_claim CHECK (status <> 'COMPLETED' OR fare_claim_status = 'APPROVED');
ALTER TABLE TAXIPOT ADD CONSTRAINT chk_taxipot_claim_fare CHECK (fare_claim_status NOT IN ('PENDING', 'APPROVED') OR actual_fare IS NOT NULL);
ALTER TABLE TAXIPOT ADD CONSTRAINT chk_taxipot_claim_reject CHECK (fare_claim_status <> 'REJECTED' OR fare_reject_reason IS NOT NULL);

-- [3] WITHDRAWAL 신규 (POINT_HISTORY FK보다 먼저)
CREATE TABLE WITHDRAWAL (
  id BIGINT NOT NULL AUTO_INCREMENT COMMENT '출금 고유번호',
  member_id BIGINT NOT NULL COMMENT '출금 회원번호',
  amount INT NOT NULL COMMENT '출금 금액',
  bank_code VARCHAR(10) NULL COMMENT '은행 코드(신청 시점)',
  account_no VARCHAR(255) NULL COMMENT '계좌번호(AES-256-GCM 암호문, 신청 시점)',
  account_holder VARCHAR(50) NULL COMMENT '예금주(신청 시점)',
  transfer_provider VARCHAR(20) NOT NULL DEFAULT 'DUMMY' COMMENT '송금 처리 방식',
  transfer_tid VARCHAR(100) NULL COMMENT '송금 거래번호',
  status VARCHAR(10) NOT NULL DEFAULT 'REQUESTED' COMMENT '출금 상태',
  fail_reason VARCHAR(255) NULL COMMENT '실패 사유',
  requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '출금 신청 일시',
  completed_at DATETIME NULL COMMENT '처리 완료 일시',
  PRIMARY KEY (id),
  UNIQUE KEY uk_withdrawal_tid (transfer_tid),
  KEY idx_withdrawal_member (member_id, requested_at),
  CONSTRAINT fk_withdrawal_member_id FOREIGN KEY (member_id) REFERENCES USERS(id),
  CONSTRAINT chk_withdrawal_amount_rng CHECK (amount >= 1000),
  CONSTRAINT chk_withdrawal_provider CHECK (transfer_provider IN ('DUMMY')),
  CONSTRAINT chk_withdrawal_status CHECK (status IN ('REQUESTED', 'COMPLETED', 'FAILED')),
  CONSTRAINT chk_withdrawal_done CHECK ((status = 'REQUESTED' AND completed_at IS NULL) OR (status = 'COMPLETED' AND completed_at IS NOT NULL AND transfer_tid IS NOT NULL) OR (status = 'FAILED' AND completed_at IS NOT NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='출금 테이블';

-- [4] POINT_HISTORY: 출금 유형·출금 연결
ALTER TABLE POINT_HISTORY ADD COLUMN withdrawal_id BIGINT NULL COMMENT '출금 번호' AFTER payment_id;
ALTER TABLE POINT_HISTORY ADD CONSTRAINT fk_point_history_withdrawal_id FOREIGN KEY (withdrawal_id) REFERENCES WITHDRAWAL(id);
ALTER TABLE POINT_HISTORY DROP CHECK chk_point_history_type;
ALTER TABLE POINT_HISTORY ADD CONSTRAINT chk_point_history_type CHECK (type IN ('CHARGE', 'CHARGE_REFUND', 'ADMIN_ADJUST', 'FARE_HOLD', 'FARE_REFUND', 'FARE_ADJUST', 'FARE_PAY', 'FEE', 'HOST_PAYOUT', 'DEBT_PAY', 'BALANCE_EXPIRE', 'WITHDRAW', 'WITHDRAW_REFUND'));
ALTER TABLE POINT_HISTORY ADD CONSTRAINT chk_point_history_withdrawal_link CHECK ((type IN ('WITHDRAW', 'WITHDRAW_REFUND') AND withdrawal_id IS NOT NULL) OR (type NOT IN ('WITHDRAW', 'WITHDRAW_REFUND') AND withdrawal_id IS NULL));

-- =====================================================================
-- 9차 → 10차 변경: 스키마 변경 없음 (실행할 ALTER문 없음)
-- 영수증 사진 90일 보관 후 파기는 서버 스케줄러(API 3.6.0 스케줄러 10번)로 처리
-- =====================================================================

-- =====================================================================
-- 10차 → 11차 변경 (10차(= 9차 스키마) DB에 적용)
-- 예치금 1.2배·충전 환불 폐지·PORTONE 범위 외는 서버 규칙(API 3.7.0)으로 처리, CHARGE_REFUND·REFUNDED 코드는 과거 행 호환용으로 CHECK에 남김
-- =====================================================================
SET NAMES utf8mb4;
ALTER TABLE TAXIPOT ADD COLUMN start_reminded_at DATETIME NULL COMMENT '출발 확인 알림 일시' AFTER started_at;

-- 11차 → 12차 변경: 스키마 변경 없음 (미수금 제한 예외 제거는 서버 규칙)

-- 12차 → 13차 변경: 스키마 변경 없음 (인증코드 유효 시간 1분·재발송 간격 60초는 서버 규칙, API 3.9.0)

-- 13차 → 14차 변경: 스키마 변경 없음 (출금 은행 6곳·1회 충전 10,000 ~ 50,000원·지갑 잔액 상한 500,000원은 서버 규칙, API 3.10.0)
