import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { TabLayout } from '@/components/layout/TabLayout';
import { AppEventsBridge, GuestOnly, PhoneShell, RequireAdmin, RequireAuth } from '@/routes/guards';
import { AdminConsole } from '@/screens/admin/AdminConsole';
import { LoginScreen } from '@/screens/auth/LoginScreen';
import { SignupScreen } from '@/screens/auth/SignupScreen';
import { VerifyScreen } from '@/screens/auth/VerifyScreen';
import { WelcomeScreen } from '@/screens/auth/WelcomeScreen';
import { ChatScreen } from '@/screens/chat/ChatScreen';
import { HomeScreen } from '@/screens/home/HomeScreen';
import { MyPotsScreen } from '@/screens/mypots/MyPotsScreen';
import { NotificationsScreen } from '@/screens/notifications/NotificationsScreen';
import { FareClaimScreen } from '@/screens/pot/FareClaimScreen';
import { PotCreateScreen } from '@/screens/pot/PotCreateScreen';
import { PotDetailScreen } from '@/screens/pot/PotDetailScreen';
import { RatingScreen } from '@/screens/pot/RatingScreen';
import { ReportScreen } from '@/screens/pot/ReportScreen';
import { SettlementScreen } from '@/screens/pot/SettlementScreen';
import { AccountScreen } from '@/screens/profile/AccountScreen';
import { MyReportsScreen } from '@/screens/profile/MyReportsScreen';
import { PasswordScreen } from '@/screens/profile/PasswordScreen';
import { ProfileEditScreen } from '@/screens/profile/ProfileEditScreen';
import { ProfileScreen } from '@/screens/profile/ProfileScreen';
import { WithdrawAccountScreen } from '@/screens/profile/WithdrawAccountScreen';
import { DebtsScreen } from '@/screens/wallet/DebtsScreen';
import { WalletHistoryScreen } from '@/screens/wallet/WalletHistoryScreen';
import { WalletScreen } from '@/screens/wallet/WalletScreen';
import { WithdrawScreen } from '@/screens/wallet/WithdrawScreen';
import { SessionProvider } from '@/store/SessionContext';
import { ToastProvider } from '@/store/ToastContext';

export default function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <SessionProvider>
          <AppEventsBridge />
          <Routes>
            <Route
              path="/admin"
              element={
                <RequireAdmin>
                  <AdminConsole />
                </RequireAdmin>
              }
            />

            <Route element={<PhoneShell />}>
              <Route element={<GuestOnly />}>
                <Route path="/welcome" element={<WelcomeScreen />} />
                <Route path="/login" element={<LoginScreen />} />
                <Route path="/signup" element={<SignupScreen />} />
              </Route>

              <Route element={<RequireAuth />}>
                <Route element={<TabLayout />}>
                  <Route path="/home" element={<HomeScreen />} />
                  <Route path="/pots" element={<MyPotsScreen />} />
                  <Route path="/wallet" element={<WalletScreen />} />
                  <Route path="/me" element={<ProfileScreen />} />
                </Route>

                <Route path="/verify" element={<VerifyScreen />} />
                <Route path="/notifications" element={<NotificationsScreen />} />

                <Route path="/pots/new" element={<PotCreateScreen />} />
                <Route path="/pots/:potId" element={<PotDetailScreen />} />
                <Route path="/pots/:potId/chat" element={<ChatScreen />} />
                <Route path="/pots/:potId/claim" element={<FareClaimScreen />} />
                <Route path="/pots/:potId/settlement" element={<SettlementScreen />} />
                <Route path="/pots/:potId/rate" element={<RatingScreen />} />
                <Route path="/pots/:potId/report" element={<ReportScreen />} />

                <Route path="/wallet/history" element={<WalletHistoryScreen />} />
                <Route path="/wallet/debts" element={<DebtsScreen />} />
                <Route path="/wallet/withdraw" element={<WithdrawScreen />} />

                <Route path="/me/edit" element={<ProfileEditScreen />} />
                <Route path="/me/password" element={<PasswordScreen />} />
                <Route path="/me/account" element={<AccountScreen />} />
                <Route path="/me/reports" element={<MyReportsScreen />} />
                <Route path="/me/withdraw" element={<WithdrawAccountScreen />} />
              </Route>

              <Route path="*" element={<Navigate to="/home" replace />} />
            </Route>
          </Routes>
        </SessionProvider>
      </ToastProvider>
    </BrowserRouter>
  );
}
