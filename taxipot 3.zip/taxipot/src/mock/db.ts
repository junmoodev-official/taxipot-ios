/**
 * 시연용 Mock DB — DB 테이블 설계서 14차의 테이블 구조를 메모리에 재현하고 localStorage 에 보관합니다.
 * 일시는 epoch(ms) 숫자로 저장하고 응답 시 KST ISO 문자열로 바꿉니다.
 */
import { holdAmountOf } from '@/config/policy';
import { PLACE_PRESETS, type Place } from '@/lib/geo';
import type {
  DebtStatus,
  EmailStatus,
  FareClaimStatus,
  Gender,
  GenderOption,
  MsgType,
  NotificationType,
  PointType,
  PotMemberRole,
  PotMemberStatus,
  PotStatus,
  PreferredSeat,
  ReportStatus,
  ReportType,
  ReviewStatus,
  SettlementStatus,
  UserRole,
  UserStatus,
  WithdrawalStatus,
} from '@/api/types';

/* ───────────────────────── 테이블 ───────────────────────── */

export interface UniversityRow {
  id: number;
  name: string;
  emailDomain: string;
  isActive: boolean;
}

export interface UserRow {
  id: number;
  email: string;
  password: string;
  name: string;
  nickname: string;
  phone: string;
  gender: Gender;
  university: string;
  studentNo: string;
  isVerified: boolean;
  ratingAvg: number;
  noShowCount: number;
  reportCount: number;
  cleanStreak: number;
  role: UserRole;
  status: UserStatus;
  suspendedUntil: number | null;
  withdrawnAt: number | null;
  tokenVersion: number;
  bankCode: string | null;
  accountNo: string | null;
  accountHolder: string | null;
  fcmToken: string | null;
  agreeMarketing: boolean;
  createdAt: number;
  updatedAt: number;
  /** Mock 전용: 시연 동승자(봇) 여부 */
  isBot?: boolean;
}

export interface WalletRow {
  id: number;
  memberId: number;
  balance: number;
  heldBalance: number;
  updatedAt: number;
}

export interface VerificationRow {
  id: number;
  memberId: number;
  studentNo: string;
  emailCode: string;
  emailCodeExpiresAt: number;
  emailCodeAttempts: number;
  emailStatus: EmailStatus;
  captureImage: string | null;
  reviewStatus: ReviewStatus;
  rejectReason: string | null;
  reviewedAt: number | null;
  createdAt: number;
}

export interface PotRow {
  id: number;
  hostId: number;
  title: string;
  departureName: string;
  departureLat: number;
  departureLng: number;
  destinationName: string;
  destinationLat: number;
  destinationLng: number;
  departureTime: number;
  arrivalDeadline: number;
  maxMembers: number;
  currentMembers: number;
  genderOption: GenderOption;
  expectedFare: number;
  actualFare: number | null;
  receiptImage: string | null;
  startedAt: number | null;
  startRemindedAt: number | null;
  fareClaimStatus: FareClaimStatus;
  fareClaimedAt: number | null;
  fareReviewedAt: number | null;
  fareRejectReason: string | null;
  status: PotStatus;
  hasCanceled: boolean;
  openChatUrl: string | null;
  createdAt: number;
  updatedAt: number;
  /** Mock 전용: 시연 동승자가 자동으로 참여할 시각 */
  botJoinAt?: number | null;
}

export interface MemberRow {
  id: number;
  potId: number;
  memberId: number;
  role: PotMemberRole;
  preferredSeat: PreferredSeat;
  status: PotMemberStatus;
  arrivedAt: number | null;
  joinedAt: number;
  canceledAt: number | null;
}

export interface SettlementRow {
  id: number;
  potId: number;
  memberId: number;
  heldAmount: number;
  fareShare: number | null;
  feeAmount: number | null;
  diffAmount: number | null;
  uncoveredAmount: number;
  debtStatus: DebtStatus;
  debtAmount: number;
  debtDueAt: number | null;
  debtPaidAt: number | null;
  status: SettlementStatus;
  settledAt: number | null;
  createdAt: number;
}

export interface PointRow {
  id: number;
  memberId: number;
  potId: number | null;
  paymentId: number | null;
  withdrawalId: number | null;
  type: PointType;
  amount: number;
  balanceAfter: number;
  createdAt: number;
}

export interface WithdrawalRow {
  id: number;
  memberId: number;
  amount: number;
  bankCode: string | null;
  accountNo: string | null;
  accountHolder: string | null;
  transferProvider: string;
  transferTid: string | null;
  status: WithdrawalStatus;
  failReason: string | null;
  balanceAfter: number | null;
  requestedAt: number;
  completedAt: number | null;
}

export interface RatingRow {
  id: number;
  potId: number;
  reviewerId: number;
  revieweeId: number;
  noshowScore: number;
  mannerScore: number;
  communicationScore: number;
  paymentScore: number;
  badReason: string | null;
  isDefault: boolean;
  createdAt: number;
}

export interface ReportRow {
  id: number;
  potId: number;
  reporterId: number;
  reportedId: number;
  type: ReportType;
  reason: string;
  status: ReportStatus;
  processedAt: number | null;
  createdAt: number;
}

export interface MessageRow {
  id: number;
  potId: number;
  senderId: number;
  msgType: MsgType;
  content: string;
  sentAt: number;
}

export interface NotificationRow {
  id: number;
  memberId: number;
  potId: number | null;
  type: NotificationType;
  title: string;
  content: string;
  isRead: boolean;
  createdAt: number;
}

export interface MockDb {
  version: number;
  seq: number;
  universities: UniversityRow[];
  users: UserRow[];
  wallets: WalletRow[];
  verifications: VerificationRow[];
  pots: PotRow[];
  members: MemberRow[];
  settlements: SettlementRow[];
  points: PointRow[];
  withdrawals: WithdrawalRow[];
  ratings: RatingRow[];
  reports: ReportRow[];
  messages: MessageRow[];
  notifications: NotificationRow[];
}

/* ───────────────────────── 상수 ───────────────────────── */

export const BANKS = [
  { code: '004', name: 'KB국민은행' },
  { code: '011', name: 'NH농협은행' },
  { code: '088', name: '신한은행' },
  { code: '020', name: '우리은행' },
  { code: '090', name: '카카오뱅크' },
  { code: '092', name: '토스뱅크' },
] as const;

export const QUICK_BLOCKS = [
  { code: 'LATE_1', content: '1분 늦어요' },
  { code: 'LATE_2', content: '2분 늦어요' },
  { code: 'LATE_3', content: '3분 늦어요' },
  { code: 'LATE_4', content: '4분 늦어요' },
  { code: 'LATE_5', content: '5분 늦어요' },
  { code: 'ON_MY_WAY', content: '지금 가고 있어요' },
  { code: 'ARRIVED', content: '도착했어요' },
  { code: 'WAITING', content: '출발지에서 기다리고 있어요' },
] as const;

/** 시연에서 출금 실패를 보여 주는 금액 (app.withdrawal.dummy-fail-amount) */
export const DUMMY_FAIL_AMOUNT = 4_040;

export const DEMO_ACCOUNTS = {
  student: { email: 'student@bu.ac.kr', password: 'taxipot123' },
  admin: { email: 'admin@taxipot.kr', password: 'admin1234' },
} as const;

/* ───────────────────────── 저장 ───────────────────────── */

const STORAGE_KEY = 'taxipot.mock-db.v3';
const DB_VERSION = 3;

export function nextId(db: MockDb): number {
  db.seq += 1;
  return db.seq;
}

export function loadDb(): MockDb {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as MockDb;
      if (parsed.version === DB_VERSION) return parsed;
    }
  } catch {
    // 손상된 시연 데이터는 새로 만듭니다.
  }
  const fresh = seedDb();
  saveDb(fresh);
  return fresh;
}

export function saveDb(db: MockDb): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  } catch {
    // 저장 공간이 부족하면 큰 이미지부터 비우고 다시 시도합니다.
    db.verifications.forEach((v) => {
      if (v.reviewStatus !== 'PENDING') v.captureImage = v.captureImage ? 'placeholder' : null;
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  }
}

export function resetDb(): MockDb {
  localStorage.removeItem(STORAGE_KEY);
  return loadDb();
}

/* ───────────────────────── 시드 ───────────────────────── */

const MIN = 60_000;

function place(name: string): Place {
  return PLACE_PRESETS.find((p) => p.name === name) ?? PLACE_PRESETS[0];
}

function makeUser(db: MockDb, partial: Partial<UserRow> & Pick<UserRow, 'nickname'>): UserRow {
  const now = Date.now();
  const id = nextId(db);
  const user: UserRow = {
    id,
    email: `user${id}@bu.ac.kr`,
    password: 'taxipot123',
    name: partial.nickname,
    phone: `0101234${String(1000 + id).slice(-4)}`,
    gender: 'M',
    university: '백석대학교',
    studentNo: `2026${String(1000 + id).slice(-4)}`,
    isVerified: true,
    ratingAvg: 5,
    noShowCount: 0,
    reportCount: 0,
    cleanStreak: 0,
    role: 'USER',
    status: 'ACTIVE',
    suspendedUntil: null,
    withdrawnAt: null,
    tokenVersion: 0,
    bankCode: '090',
    accountNo: `3333${String(10_000_000 + id)}`,
    accountHolder: partial.name ?? partial.nickname,
    fcmToken: null,
    agreeMarketing: false,
    createdAt: now - 30 * 86_400_000,
    updatedAt: now,
    ...partial,
  };
  db.users.push(user);
  db.wallets.push({ id: nextId(db), memberId: id, balance: 0, heldBalance: 0, updatedAt: now });
  db.verifications.push({
    id: nextId(db),
    memberId: id,
    studentNo: user.studentNo,
    emailCode: '000000',
    emailCodeExpiresAt: user.createdAt + MIN,
    emailCodeAttempts: 0,
    emailStatus: 'VERIFIED',
    captureImage: user.isVerified ? 'placeholder' : null,
    reviewStatus: user.isVerified ? 'APPROVED' : 'NOT_SUBMITTED',
    rejectReason: null,
    reviewedAt: user.isVerified ? user.createdAt + 3_600_000 : null,
    createdAt: user.createdAt,
  });
  return user;
}

function credit(db: MockDb, memberId: number, amount: number, at: number) {
  const wallet = db.wallets.find((w) => w.memberId === memberId)!;
  wallet.balance += amount;
  db.points.push({
    id: nextId(db),
    memberId,
    potId: null,
    paymentId: null,
    withdrawalId: null,
    type: 'ADMIN_ADJUST',
    amount,
    balanceAfter: wallet.balance,
    createdAt: at,
  });
}

interface SeedPot {
  host: UserRow;
  from: string;
  to: string;
  minutes: number;
  maxMembers: 3 | 4;
  fare: number;
  title: string;
  guests?: UserRow[];
  genderOption?: GenderOption;
  hasCanceled?: boolean;
}

/** 모집 중인 시연 택시팟 생성 (봇 방장이 예치까지 마친 상태) */
export function addRecruitingPot(db: MockDb, seed: SeedPot): PotRow {
  const now = Date.now();
  const from = place(seed.from);
  const to = place(seed.to);
  const departureTime = now + seed.minutes * MIN;
  const hold = holdAmountOf(seed.fare, seed.maxMembers);
  const pot: PotRow = {
    id: nextId(db),
    hostId: seed.host.id,
    title: seed.title,
    departureName: from.name,
    departureLat: from.lat,
    departureLng: from.lng,
    destinationName: to.name,
    destinationLat: to.lat,
    destinationLng: to.lng,
    departureTime,
    arrivalDeadline: departureTime - 5 * MIN,
    maxMembers: seed.maxMembers,
    currentMembers: 1 + (seed.guests?.length ?? 0),
    genderOption: seed.genderOption ?? 'ALL',
    expectedFare: seed.fare,
    actualFare: null,
    receiptImage: null,
    startedAt: null,
    startRemindedAt: null,
    fareClaimStatus: 'NONE',
    fareClaimedAt: null,
    fareReviewedAt: null,
    fareRejectReason: null,
    status: 'RECRUITING',
    hasCanceled: seed.hasCanceled ?? false,
    openChatUrl: null,
    createdAt: now - 10 * MIN,
    updatedAt: now - 10 * MIN,
  };
  db.pots.push(pot);
  [seed.host, ...(seed.guests ?? [])].forEach((user, index) => {
    db.members.push({
      id: nextId(db),
      potId: pot.id,
      memberId: user.id,
      role: index === 0 ? 'HOST' : 'GUEST',
      preferredSeat: index === 0 ? 'FRONT' : 'BACK_LEFT',
      status: 'JOINED',
      arrivedAt: index === 0 ? null : null,
      joinedAt: pot.createdAt,
      canceledAt: null,
    });
    const wallet = db.wallets.find((w) => w.memberId === user.id)!;
    wallet.balance -= hold;
    wallet.heldBalance += hold;
    db.settlements.push({
      id: nextId(db),
      potId: pot.id,
      memberId: user.id,
      heldAmount: hold,
      fareShare: null,
      feeAmount: null,
      diffAmount: null,
      uncoveredAmount: 0,
      debtStatus: 'NONE',
      debtAmount: 0,
      debtDueAt: null,
      debtPaidAt: null,
      status: 'HELD',
      settledAt: null,
      createdAt: pot.createdAt,
    });
    db.points.push({
      id: nextId(db),
      memberId: user.id,
      potId: pot.id,
      paymentId: null,
      withdrawalId: null,
      type: 'FARE_HOLD',
      amount: -hold,
      balanceAfter: wallet.balance,
      createdAt: pot.createdAt,
    });
  });
  return pot;
}

export const BOT_POT_TEMPLATES: Omit<SeedPot, 'host' | 'guests'>[] = [
  {
    from: '백석대학교 정문',
    to: '천안아산역 (KTX)',
    minutes: 40,
    maxMembers: 4,
    fare: 18_000,
    title: 'KTX 타러 가실 분',
  },
  {
    from: '두정역',
    to: '단국대학교 천안캠퍼스',
    minutes: 75,
    maxMembers: 3,
    fare: 9_000,
    title: '1교시 같이 가요',
  },
  {
    from: '천안종합버스터미널',
    to: '백석대학교 정문',
    minutes: 130,
    maxMembers: 4,
    fare: 8_000,
    title: '터미널에서 학교까지',
    hasCanceled: true,
  },
  {
    from: '천안역',
    to: '상명대학교 천안캠퍼스',
    minutes: 200,
    maxMembers: 4,
    fare: 7_500,
    title: '천안역 → 상명대',
    genderOption: 'FEMALE',
  },
  {
    from: '불당동 카페거리',
    to: '백석대학교 정문',
    minutes: 320,
    maxMembers: 3,
    fare: 14_000,
    title: '불당동에서 귀가',
  },
];

function seedDb(): MockDb {
  const now = Date.now();
  const db: MockDb = {
    version: DB_VERSION,
    seq: 100,
    universities: [
      { id: 1, name: '백석대학교', emailDomain: 'bu.ac.kr', isActive: true },
      { id: 2, name: '단국대학교', emailDomain: 'dankook.ac.kr', isActive: true },
      { id: 3, name: '상명대학교', emailDomain: 'smu.ac.kr', isActive: true },
      { id: 4, name: '호서대학교', emailDomain: 'hoseo.edu', isActive: true },
      { id: 5, name: '한국기술교육대학교', emailDomain: 'koreatech.ac.kr', isActive: true },
    ],
    users: [],
    wallets: [],
    verifications: [],
    pots: [],
    members: [],
    settlements: [],
    points: [],
    withdrawals: [],
    ratings: [],
    reports: [],
    messages: [],
    notifications: [],
  };

  makeUser(db, {
    email: DEMO_ACCOUNTS.admin.email,
    password: DEMO_ACCOUNTS.admin.password,
    name: '운영자',
    nickname: '택시팟운영자',
    role: 'ADMIN',
    bankCode: null,
    accountNo: null,
    accountHolder: null,
  });

  const student = makeUser(db, {
    email: DEMO_ACCOUNTS.student.email,
    password: DEMO_ACCOUNTS.student.password,
    name: '김하늘',
    nickname: '하늘',
    studentNo: '20260001',
    ratingAvg: 7.4,
    accountNo: '3333012345678',
    accountHolder: '김하늘',
  });
  credit(db, student.id, 30_000, now - 2 * 86_400_000);

  const bots = [
    makeUser(db, { nickname: '민서', name: '이민서', gender: 'F', ratingAvg: 8.2, isBot: true }),
    makeUser(db, { nickname: '지훈', name: '박지훈', ratingAvg: 6.6, isBot: true }),
    makeUser(db, { nickname: '서연', name: '최서연', gender: 'F', ratingAvg: 9.0, isBot: true }),
    makeUser(db, { nickname: '도윤', name: '정도윤', ratingAvg: 5.4, isBot: true }),
    makeUser(db, { nickname: '유진', name: '한유진', gender: 'F', ratingAvg: 7.8, isBot: true }),
  ];
  bots.forEach((bot) => credit(db, bot.id, 200_000, now - 3 * 86_400_000));

  BOT_POT_TEMPLATES.forEach((template, index) => {
    const host = template.genderOption === 'FEMALE' ? bots[2] : bots[index % bots.length];
    const guests = index === 0 ? [bots[4]] : index === 2 ? [bots[1]] : [];
    addRecruitingPot(db, { ...template, host, guests: guests.filter((g) => g.id !== host.id) });
  });

  seedCompletedPot(db, student, [bots[0], bots[3]]);

  db.notifications.push({
    id: nextId(db),
    memberId: student.id,
    potId: null,
    type: 'SYSTEM',
    title: '택시팟에 오신 걸 환영해요',
    content: '시연 계정에 30,000원이 충전되어 있어요. 모집 중인 택시팟에 참여해 보세요.',
    isRead: false,
    createdAt: now - 60 * MIN,
  });

  return db;
}

/** 정산이 끝난 지난 이용 기록 (평가 기간 안) */
function seedCompletedPot(db: MockDb, student: UserRow, others: UserRow[]) {
  const settledAt = Date.now() - 2 * 3_600_000;
  const startedAt = settledAt - 3 * 3_600_000;
  const from = place('천안아산역 (KTX)');
  const to = place('백석대학교 정문');
  const fare = 19_300;
  const hold = holdAmountOf(18_000, 4);
  const pot: PotRow = {
    id: nextId(db),
    hostId: others[0].id,
    title: '아산역에서 학교로',
    departureName: from.name,
    departureLat: from.lat,
    departureLng: from.lng,
    destinationName: to.name,
    destinationLat: to.lat,
    destinationLng: to.lng,
    departureTime: startedAt,
    arrivalDeadline: startedAt - 5 * MIN,
    maxMembers: 4,
    currentMembers: 3,
    genderOption: 'ALL',
    expectedFare: 18_000,
    actualFare: fare,
    receiptImage: 'placeholder',
    startedAt,
    startRemindedAt: null,
    fareClaimStatus: 'APPROVED',
    fareClaimedAt: startedAt + 40 * MIN,
    fareReviewedAt: settledAt,
    fareRejectReason: null,
    status: 'COMPLETED',
    hasCanceled: false,
    openChatUrl: null,
    createdAt: startedAt - 60 * MIN,
    updatedAt: settledAt,
  };
  db.pots.push(pot);
  const share = Math.floor(fare / 3);
  [others[0], student, others[1]].forEach((user, index) => {
    db.members.push({
      id: nextId(db),
      potId: pot.id,
      memberId: user.id,
      role: index === 0 ? 'HOST' : 'GUEST',
      preferredSeat: index === 0 ? 'FRONT' : index === 1 ? 'BACK_LEFT' : 'BACK_RIGHT',
      status: 'BOARDED',
      arrivedAt: startedAt - 8 * MIN,
      joinedAt: pot.createdAt,
      canceledAt: null,
    });
    db.settlements.push({
      id: nextId(db),
      potId: pot.id,
      memberId: user.id,
      heldAmount: hold,
      fareShare: share,
      feeAmount: 1_000,
      diffAmount: hold - (share + 1_000),
      uncoveredAmount: 0,
      debtStatus: 'NONE',
      debtAmount: 0,
      debtDueAt: null,
      debtPaidAt: null,
      status: 'SETTLED',
      settledAt,
      createdAt: pot.createdAt,
    });
  });
  const wallet = db.wallets.find((w) => w.memberId === student.id)!;
  const entries: [PointType, number, number][] = [
    ['FARE_HOLD', -hold, pot.createdAt],
    ['FARE_REFUND', hold, settledAt],
    ['FARE_PAY', -share, settledAt],
    ['FEE', -1_000, settledAt],
  ];
  entries.forEach(([type, amount, at]) => {
    wallet.balance += amount;
    db.points.push({
      id: nextId(db),
      memberId: student.id,
      potId: pot.id,
      paymentId: null,
      withdrawalId: null,
      type,
      amount,
      balanceAfter: wallet.balance,
      createdAt: at,
    });
  });
  db.notifications.push({
    id: nextId(db),
    memberId: student.id,
    potId: pot.id,
    type: 'RATING_REQUEST',
    title: '함께 탄 동승자를 평가해 주세요',
    content: '아산역에서 학교로 · 정산이 끝났어요. 24시간 안에 평가할 수 있어요.',
    isRead: false,
    createdAt: settledAt,
  });
}
