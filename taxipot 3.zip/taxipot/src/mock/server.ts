/**
 * 시연용 Mock 서버 — `TaxipotApi` 계약을 브라우저 안에서 구현합니다.
 * VITE_API_BASE_URL 을 설정하면 이 파일은 사용되지 않습니다.
 */
import type { TaxipotApi } from '@/api/contract';
import { ApiError, errorMessage } from '@/api/errors';
import type { PotEventHandler, RealtimeClient } from '@/api/realtime/types';
import { tokenStore } from '@/api/tokenStore';
import type * as T from '@/api/types';
import { env } from '@/config/env';
import { POLICY, holdAmountOf } from '@/config/policy';
import { appEvents } from '@/lib/events';
import { distanceMeters } from '@/lib/geo';
import { kstHour, toKstDate } from '@/lib/time';
import {
  BANKS,
  DUMMY_FAIL_AMOUNT,
  QUICK_BLOCKS,
  loadDb,
  nextId,
  resetDb,
  saveDb,
  type MockDb,
  type UserRow,
} from './db';
import * as E from './engine';
import { blobFromStored, storeImage } from './images';

const MIN = 60_000;
const HOUR = 60 * MIN;

/* ───────────────────────── 실행기 ───────────────────────── */

/** 실제 서버 모드에서는 Mock DB 를 만들지 않습니다. */
let db: MockDb = env.isMock ? loadDb() : ({} as MockDb);
const potListeners = new Map<number, Set<PotEventHandler>>();
/** 시연용 메일함: 이메일 → 마지막 인증코드 */
const inbox = new Map<string, string>();

function emitRealtime(ctx: E.Ctx) {
  ctx.chats.forEach((chat) =>
    potListeners.get(chat.potId)?.forEach((h) => h({ type: 'CHAT_MESSAGE', payload: chat })),
  );
  ctx.touched.forEach((potId) =>
    potListeners.get(potId)?.forEach((h) => h({ type: 'POT_UPDATED', payload: { potId } })),
  );
}

/** 미수금 이용 제한 허용 목록 (명세 공통 규칙) */
const DEBT_ALLOWED = new Set([
  'auth',
  'users.me',
  'users.updateFcmToken',
  'wallet.get',
  'wallet.history',
  'wallet.debts',
  'wallet.payDebt',
  'wallet.payments',
  'notifications',
  'verification',
]);

function debtAllowed(name: string) {
  return (
    DEBT_ALLOWED.has(name) || DEBT_ALLOWED.has(name.split('.')[0]) || name.startsWith('admin.')
  );
}

const delay = () => new Promise((resolve) => setTimeout(resolve, 120 + Math.random() * 180));

async function run<R>(
  name: string,
  handler: (ctx: E.Ctx) => R | Promise<R>,
  options: { auth?: boolean } = {},
): Promise<R> {
  await delay();
  const ctx: E.Ctx = { db, now: Date.now(), touched: new Set(), chats: [] };
  try {
    E.runSchedulers(ctx);
    if (options.auth !== false && !debtAllowed(name)) {
      const user = E.currentUser(ctx);
      if (user.role !== 'ADMIN') E.assertNoDebt(ctx, user.id);
    }
    const result = await handler(ctx);
    saveDb(db);
    emitRealtime(ctx);
    return structuredClone(result);
  } catch (error) {
    saveDb(db);
    emitRealtime(ctx);
    if (error instanceof ApiError) {
      if (
        error.code === 'TOKEN_REVOKED' ||
        (error.code === 'UNAUTHORIZED' && tokenStore.hasSession())
      ) {
        tokenStore.clear();
        appEvents.emit('session-expired', { message: errorMessage(error) });
      }
      if (error.code === 'UNPAID_DEBT_EXISTS') {
        appEvents.emit('unpaid-debt', { debtAmount: error.num('debtAmount') });
      }
    }
    throw error;
  }
}

/** 주기적으로 스케줄러를 돌려 실시간 변화를 흉내 냅니다. */
if (env.isMock)
  setInterval(() => {
    const ctx: E.Ctx = { db, now: Date.now(), touched: new Set(), chats: [] };
    E.runSchedulers(ctx);
    if (ctx.touched.size || ctx.chats.length) saveDb(db);
    emitRealtime(ctx);
  }, 4000);

const me = (ctx: E.Ctx) => E.currentUser(ctx);

function newEmailCode(): string {
  return String(Math.floor(100_000 + Math.random() * 900_000));
}

function sendEmailCode(ctx: E.Ctx, user: UserRow, row: T.Id) {
  const verification = ctx.db.verifications.find((v) => v.id === row)!;
  verification.emailCode = newEmailCode();
  verification.emailCodeExpiresAt = ctx.now + POLICY.emailCodeTtlSeconds * 1000;
  verification.emailCodeAttempts = 0;
  inbox.set(user.email, verification.emailCode);
}

function toVerification(v: MockDb['verifications'][number]): T.VerificationResponse {
  return {
    id: v.id,
    studentNo: v.studentNo,
    emailStatus: v.emailStatus,
    reviewStatus: v.reviewStatus,
    rejectReason: v.rejectReason,
    reviewedAt: E.iso(v.reviewedAt),
    createdAt: E.iso(v.createdAt),
  };
}

function toAdminVerification(
  ctx: E.Ctx,
  v: MockDb['verifications'][number],
): T.AdminVerificationResponse {
  const user = E.userById(ctx, v.memberId)!;
  return {
    id: v.id,
    memberId: user.id,
    memberName: user.name,
    memberGender: user.gender,
    university: user.university,
    registeredStudentNo: user.studentNo,
    submittedStudentNo: v.studentNo,
    email: user.email,
    emailStatus: ctx.db.verifications.some(
      (x) => x.memberId === user.id && x.emailStatus === 'VERIFIED',
    )
      ? 'VERIFIED'
      : 'PENDING',
    captureImgUrl: v.captureImage ? `/api/admin/verifications/${v.id}/capture` : null,
    reviewStatus: v.reviewStatus,
    rejectReason: v.rejectReason,
    reviewedAt: E.iso(v.reviewedAt),
    createdAt: E.iso(v.createdAt),
  };
}

function toAdminReport(ctx: E.Ctx, r: MockDb['reports'][number]): T.AdminReportResponse {
  const reporter = E.userById(ctx, r.reporterId)!;
  const reported = E.userById(ctx, r.reportedId)!;
  return {
    id: r.id,
    reporterId: r.reporterId,
    reporterNickname: reporter.nickname,
    reportedId: r.reportedId,
    reportedNickname: reported.nickname,
    reportedReportCount: reported.reportCount,
    potId: r.potId,
    potTitle: E.potById(ctx, r.potId).title,
    type: r.type,
    reason: r.reason,
    status: r.status,
    processedAt: E.iso(r.processedAt),
    createdAt: E.iso(r.createdAt),
  };
}

function toWithdrawal(w: MockDb['withdrawals'][number]): T.WithdrawalResponse {
  return {
    id: w.id,
    amount: w.amount,
    bankName: E.bankName(w.bankCode),
    maskedAccountNumber: E.maskAccount(w.accountNo),
    accountHolder: w.accountHolder,
    transferProvider: w.transferProvider,
    transferTid: w.transferTid,
    status: w.status,
    failReason: w.failReason,
    balanceAfter: w.balanceAfter,
    requestedAt: E.iso(w.requestedAt),
    completedAt: E.iso(w.completedAt),
  };
}

function historyOf(ctx: E.Ctx, memberId: number, query: T.MyPotHistoryQuery = {}) {
  return ctx.db.members
    .filter((m) => m.memberId === memberId)
    .filter((m) => !query.role || m.role === query.role)
    .map((m) => E.toHistory(ctx, m))
    .filter((h): h is T.MyPotHistoryResponse => h !== null)
    .filter((h) => !query.status || h.potStatus === query.status)
    .sort((a, b) => b.departureTime.localeCompare(a.departureTime));
}

function hostPot(ctx: E.Ctx, potId: T.Id) {
  const user = me(ctx);
  const pot = E.potById(ctx, potId);
  if (pot.hostId !== user.id) E.fail(403, 'NOT_POT_HOST');
  return { user, pot };
}

function participant(
  ctx: E.Ctx,
  potId: T.Id,
  statuses: T.PotMemberStatus[] = ['JOINED', 'BOARDED'],
) {
  const user = me(ctx);
  const pot = E.potById(ctx, potId);
  const member = E.memberOf(ctx, pot.id, user.id);
  if (!member || !statuses.includes(member.status)) E.fail(403, 'NOT_POT_MEMBER');
  return { user, pot, member };
}

function assertSeat(seat: unknown): T.PreferredSeat {
  const seats: T.PreferredSeat[] = ['FRONT', 'BACK_LEFT', 'BACK_MID', 'BACK_RIGHT', 'NONE'];
  if (seat === undefined) return 'NONE';
  if (!seats.includes(seat as T.PreferredSeat)) E.fail(400, 'INVALID_INPUT', '좌석 값 오류');
  return seat as T.PreferredSeat;
}

/* ───────────────────────── API 구현 ───────────────────────── */

export const mockApi: TaxipotApi = {
  auth: {
    signup: (body) =>
      run(
        'auth.signup',
        (ctx) => {
          const email = body.email.trim().toLowerCase();
          if (!body.agreeRequired) E.fail(400, 'TERMS_NOT_AGREED');
          if (body.password.length < 8 || !/^01[016789]-?\d{3,4}-?\d{4}$/.test(body.phone))
            E.fail(400, 'INVALID_INPUT');
          if (body.nickname.startsWith(POLICY.reservedNicknamePrefix))
            E.fail(400, 'RESERVED_NICKNAME');
          const school = ctx.db.universities.find((u) => u.name === body.university && u.isActive);
          if (!school) E.fail(400, 'UNSUPPORTED_UNIVERSITY');
          if (email.split('@')[1] !== school.emailDomain) E.fail(400, 'EMAIL_DOMAIN_MISMATCH');
          if (!BANKS.some((b) => b.code === body.bankCode))
            E.fail(400, 'INVALID_INPUT', '지원하지 않는 은행');
          const account = body.accountNumber.replace(/\D/g, '');
          if (account.length < 10 || account.length > 14)
            E.fail(400, 'INVALID_INPUT', '계좌번호 오류');
          if (body.accountHolder.trim() !== body.name.trim())
            E.fail(400, 'ACCOUNT_HOLDER_MISMATCH');
          const active = ctx.db.users.filter((u) => u.status !== 'WITHDRAWN');
          if (active.some((u) => u.email === email)) E.fail(409, 'DUPLICATE_EMAIL');
          if (ctx.db.users.some((u) => u.nickname === body.nickname.trim()))
            E.fail(409, 'DUPLICATE_NICKNAME');
          if (
            active.some(
              (u) => u.university === body.university && u.studentNo === body.studentNo.trim(),
            )
          )
            E.fail(409, 'DUPLICATE_STUDENT_NO');

          const user: UserRow = {
            id: nextId(ctx.db),
            email,
            password: body.password,
            name: body.name.trim(),
            nickname: body.nickname.trim(),
            phone: body.phone.replace(/\D/g, ''),
            gender: body.gender,
            university: body.university,
            studentNo: body.studentNo.trim(),
            isVerified: false,
            ratingAvg: 5,
            noShowCount: 0,
            reportCount: 0,
            cleanStreak: 0,
            role: 'USER',
            status: 'ACTIVE',
            suspendedUntil: null,
            withdrawnAt: null,
            tokenVersion: 0,
            bankCode: body.bankCode,
            accountNo: account,
            accountHolder: body.accountHolder.trim(),
            fcmToken: null,
            agreeMarketing: Boolean(body.agreeMarketing),
            createdAt: ctx.now,
            updatedAt: ctx.now,
          };
          ctx.db.users.push(user);
          ctx.db.wallets.push({
            id: nextId(ctx.db),
            memberId: user.id,
            balance: 0,
            heldBalance: 0,
            updatedAt: ctx.now,
          });
          const verificationId = nextId(ctx.db);
          ctx.db.verifications.push({
            id: verificationId,
            memberId: user.id,
            studentNo: user.studentNo,
            emailCode: '',
            emailCodeExpiresAt: ctx.now,
            emailCodeAttempts: 0,
            emailStatus: 'PENDING',
            captureImage: null,
            reviewStatus: 'NOT_SUBMITTED',
            rejectReason: null,
            reviewedAt: null,
            createdAt: ctx.now,
          });
          sendEmailCode(ctx, user, verificationId);
          return { ...E.issueTokens(user), user: E.toProfile(user) };
        },
        { auth: false },
      ),

    checkNickname: (nickname) =>
      run(
        'auth.checkNickname',
        (ctx) => {
          if (nickname.startsWith(POLICY.reservedNicknamePrefix))
            return { available: false, reason: 'RESERVED' as const };
          const taken = ctx.db.users.some((u) => u.nickname === nickname.trim());
          return { available: !taken, reason: taken ? ('DUPLICATE' as const) : null };
        },
        { auth: false },
      ),

    universities: () =>
      run(
        'auth.universities',
        (ctx) =>
          ctx.db.universities
            .filter((u) => u.isActive)
            .sort((a, b) => a.name.localeCompare(b.name, 'ko'))
            .map(({ id, name, emailDomain }) => ({ id, name, emailDomain })),
        { auth: false },
      ),

    banks: () =>
      run(
        'auth.banks',
        () => [...BANKS].sort((a, b) => a.name.localeCompare(b.name, 'ko')).map((b) => ({ ...b })),
        { auth: false },
      ),

    login: (body) =>
      run(
        'auth.login',
        (ctx) => {
          const user = ctx.db.users.find(
            (u) => u.email === body.email.trim().toLowerCase() && u.status !== 'WITHDRAWN',
          );
          const withdrawn = ctx.db.users.find(
            (u) => u.email === body.email.trim().toLowerCase() && u.status === 'WITHDRAWN',
          );
          if (!user && withdrawn) E.fail(403, 'WITHDRAWN_USER');
          if (!user || user.password !== body.password) E.fail(401, 'INVALID_CREDENTIALS');
          if (body.fcmToken) user.fcmToken = body.fcmToken;
          return { ...E.issueTokens(user), user: E.toProfile(user) };
        },
        { auth: false },
      ),

    logout: () =>
      run('auth.logout', (ctx) => {
        me(ctx).fcmToken = null;
      }),
  },

  verification: {
    resendEmailCode: () =>
      run('verification.resend', (ctx) => {
        const user = me(ctx);
        if (
          ctx.db.verifications.some((v) => v.memberId === user.id && v.emailStatus === 'VERIFIED')
        )
          E.fail(409, 'ALREADY_VERIFIED');
        const row = E.latestVerification(ctx, user.id)!;
        const lastSent = row.emailCodeExpiresAt - POLICY.emailCodeTtlSeconds * 1000;
        if (ctx.now - lastSent < POLICY.emailResendIntervalSeconds * 1000)
          E.fail(429, 'TOO_MANY_REQUESTS');
        sendEmailCode(ctx, user, row.id);
        return {
          verificationId: row.id,
          email: user.email,
          expiresAt: E.iso(row.emailCodeExpiresAt),
        };
      }),

    confirmEmailCode: (body) =>
      run('verification.confirm', (ctx) => {
        const user = me(ctx);
        if (
          ctx.db.verifications.some((v) => v.memberId === user.id && v.emailStatus === 'VERIFIED')
        )
          E.fail(409, 'ALREADY_VERIFIED');
        const row = E.latestVerification(ctx, user.id)!;
        if (row.emailCodeAttempts >= POLICY.emailCodeMaxAttempts)
          E.fail(409, 'EMAIL_CODE_ATTEMPTS_EXCEEDED');
        if (row.emailCodeExpiresAt <= ctx.now) E.fail(400, 'EXPIRED_EMAIL_CODE');
        if (row.emailCode !== body.emailCode.trim()) {
          row.emailCodeAttempts += 1;
          E.fail(400, 'INVALID_EMAIL_CODE', '인증코드 불일치', {
            remainingAttempts: POLICY.emailCodeMaxAttempts - row.emailCodeAttempts,
          });
        }
        row.emailStatus = 'VERIFIED';
        return toVerification(row);
      }),

    submitCapture: async (file, studentNo) => {
      const image = await storeImage(file);
      return run('verification.capture', (ctx) => {
        const user = me(ctx);
        if (
          !ctx.db.verifications.some((v) => v.memberId === user.id && v.emailStatus === 'VERIFIED')
        )
          E.fail(403, 'EMAIL_NOT_VERIFIED');
        if (studentNo.trim() !== user.studentNo) E.fail(400, 'STUDENT_NO_MISMATCH');
        const latest = E.latestVerification(ctx, user.id)!;
        if (latest.reviewStatus === 'PENDING') E.fail(409, 'REVIEW_IN_PROGRESS');
        if (latest.reviewStatus === 'APPROVED') E.fail(409, 'ALREADY_VERIFIED');
        if (latest.reviewStatus === 'NOT_SUBMITTED') {
          latest.captureImage = image;
          latest.reviewStatus = 'PENDING';
          E.notifyAdmins(ctx, '학생 인증 심사 요청', `${user.name} (${user.university})`, null);
          return toVerification(latest);
        }
        const row = {
          ...latest,
          id: nextId(ctx.db),
          studentNo: studentNo.trim(),
          emailStatus: 'VERIFIED' as const,
          captureImage: image,
          reviewStatus: 'PENDING' as const,
          rejectReason: null,
          reviewedAt: null,
          createdAt: ctx.now,
        };
        ctx.db.verifications.push(row);
        E.notifyAdmins(ctx, '학생 인증 재심사 요청', `${user.name} (${user.university})`, null);
        return toVerification(row);
      });
    },

    me: () =>
      run('verification.me', (ctx) => {
        const user = me(ctx);
        const row = E.latestVerification(ctx, user.id) ?? E.fail(404, 'NOT_FOUND');
        const emailVerified = ctx.db.verifications.some(
          (v) => v.memberId === user.id && v.emailStatus === 'VERIFIED',
        );
        return {
          ...toVerification(row),
          emailStatus: emailVerified ? 'VERIFIED' : row.emailStatus,
        };
      }),
  },

  users: {
    me: () => run('users.me', (ctx) => E.toProfile(me(ctx))),

    update: (body) =>
      run('users.update', (ctx) => {
        const user = me(ctx);
        if (body.nickname !== undefined) {
          const nickname = body.nickname.trim();
          if (nickname.startsWith(POLICY.reservedNicknamePrefix)) E.fail(400, 'RESERVED_NICKNAME');
          if (nickname.length < 2 || nickname.length > 30) E.fail(400, 'INVALID_INPUT');
          if (ctx.db.users.some((u) => u.id !== user.id && u.nickname === nickname))
            E.fail(409, 'DUPLICATE_NICKNAME');
          user.nickname = nickname;
        }
        if (body.phone !== undefined) {
          if (!/^01[016789]-?\d{3,4}-?\d{4}$/.test(body.phone)) E.fail(400, 'INVALID_INPUT');
          user.phone = body.phone.replace(/\D/g, '');
        }
        if (body.agreeMarketing !== undefined) user.agreeMarketing = body.agreeMarketing;
        user.updatedAt = ctx.now;
        return E.toProfile(user);
      }),

    withdraw: (body) =>
      run('users.withdraw', (ctx) => {
        const user = me(ctx);
        if (user.password !== body.password) E.fail(401, 'INVALID_CREDENTIALS');
        if (!body.agreeBalanceForfeit) E.fail(400, 'BALANCE_FORFEIT_NOT_AGREED');
        const active = E.activePotOf(ctx, user.id);
        const held = ctx.db.settlements.some((s) => s.memberId === user.id && s.status === 'HELD');
        if (active || held)
          E.fail(409, 'ACTIVE_POT_EXISTS', '진행 중인 참여가 있습니다.', {
            activePotId: active?.id ?? null,
          });
        const wallet = E.walletOf(ctx, user.id);
        if (wallet.balance > 0) {
          const amount = wallet.balance;
          wallet.balance = 0;
          E.ledger(ctx, wallet, 'BALANCE_EXPIRE', -amount);
        }
        user.status = 'WITHDRAWN';
        user.withdrawnAt = ctx.now;
        user.fcmToken = null;
        user.tokenVersion += 1;
      }),

    changePassword: (body) =>
      run('users.changePassword', (ctx) => {
        const user = me(ctx);
        if (user.password !== body.currentPassword) E.fail(401, 'INVALID_CREDENTIALS');
        if (body.newPassword.length < 8) E.fail(400, 'INVALID_INPUT');
        user.password = body.newPassword;
        user.tokenVersion += 1;
        return E.issueTokens(user);
      }),

    account: () =>
      run('users.account', (ctx) => {
        const user = me(ctx);
        if (!user.bankCode || !user.accountNo || !user.accountHolder) E.fail(404, 'NOT_FOUND');
        return {
          bankCode: user.bankCode,
          bankName: E.bankName(user.bankCode)!,
          maskedAccountNumber: E.maskAccount(user.accountNo)!,
          accountHolder: user.accountHolder,
        };
      }),

    updateAccount: (body) =>
      run('users.updateAccount', (ctx) => {
        const user = me(ctx);
        if (user.password !== body.password) E.fail(401, 'INVALID_CREDENTIALS');
        if (!BANKS.some((b) => b.code === body.bankCode)) E.fail(400, 'INVALID_INPUT');
        const digits = body.accountNumber.replace(/\D/g, '');
        if (digits.length < 10 || digits.length > 14) E.fail(400, 'INVALID_INPUT');
        if (body.accountHolder.trim() !== user.name) E.fail(400, 'ACCOUNT_HOLDER_MISMATCH');
        user.bankCode = body.bankCode;
        user.accountNo = digits;
        user.accountHolder = body.accountHolder.trim();
        return {
          bankCode: user.bankCode,
          bankName: E.bankName(user.bankCode)!,
          maskedAccountNumber: E.maskAccount(digits)!,
          accountHolder: user.accountHolder,
        };
      }),

    updateFcmToken: (body) =>
      run('users.updateFcmToken', (ctx) => {
        me(ctx).fcmToken = body.fcmToken;
      }),

    myPots: (query = {}) =>
      run('users.myPots', (ctx) =>
        E.paginate(historyOf(ctx, me(ctx).id, query), query.page, query.size),
      ),

    myReports: (query = {}) =>
      run('users.myReports', (ctx) => {
        const user = me(ctx);
        const rows = ctx.db.reports
          .filter((r) => r.reporterId === user.id)
          .sort((a, b) => b.id - a.id)
          .map((r) => ({
            id: r.id,
            reportedId: r.reportedId,
            reportedNickname: E.userById(ctx, r.reportedId)!.nickname,
            potId: r.potId,
            type: r.type,
            reason: r.reason,
            status: r.status,
            processedAt: E.iso(r.processedAt),
            createdAt: E.iso(r.createdAt),
          }));
        return E.paginate(rows, query.page, query.size);
      }),

    publicProfile: (userId) =>
      run('users.publicProfile', (ctx) => {
        me(ctx);
        const user = E.userById(ctx, userId) ?? E.fail(404, 'NOT_FOUND');
        return {
          id: user.id,
          nickname: user.nickname,
          university: user.university,
          ratingAvg: user.ratingAvg,
          isWithdrawn: user.status === 'WITHDRAWN',
        };
      }),
  },

  wallet: {
    get: () => run('wallet.get', (ctx) => E.toWallet(ctx, me(ctx).id)),

    history: (query = {}) =>
      run('wallet.history', (ctx) => {
        const user = me(ctx);
        const rows = ctx.db.points
          .filter((p) => p.memberId === user.id && (!query.type || p.type === query.type))
          .sort((a, b) => b.id - a.id)
          .map((p) => ({
            id: p.id,
            potId: p.potId,
            potTitle: p.potId ? E.potById(ctx, p.potId).title : null,
            paymentId: p.paymentId,
            type: p.type,
            amount: p.amount,
            balanceAfter: p.balanceAfter,
            createdAt: E.iso(p.createdAt),
          }));
        return E.paginate(rows, query.page, query.size);
      }),

    debts: () =>
      run('wallet.debts', (ctx) =>
        E.openDebts(ctx, me(ctx).id).map((s) => ({
          settlementId: s.id,
          potId: s.potId,
          potTitle: E.potById(ctx, s.potId).title,
          settledAt: E.iso(s.settledAt ?? s.createdAt),
          uncoveredAmount: s.uncoveredAmount,
          debtStatus: s.debtStatus,
          debtAmount: s.debtAmount,
          debtDueAt: E.iso(s.debtDueAt ?? ctx.now),
        })),
      ),

    payDebt: (settlementId) =>
      run('wallet.payDebt', (ctx) => {
        const user = me(ctx);
        const debt =
          ctx.db.settlements.find((s) => s.id === settlementId && s.memberId === user.id) ??
          E.fail(404, 'NOT_FOUND');
        if (debt.debtStatus !== 'UNPAID' && debt.debtStatus !== 'OVERDUE') E.fail(409, 'NO_DEBT');
        const wallet = E.walletOf(ctx, user.id);
        if (wallet.balance <= 0)
          E.fail(409, 'INSUFFICIENT_BALANCE', '잔액 부족', {
            requiredAmount: debt.debtAmount,
            balance: wallet.balance,
            shortageAmount: debt.debtAmount - wallet.balance,
          });
        const paid = E.payDebtRow(ctx, wallet, debt);
        return {
          settlementId: debt.id,
          paidAmount: paid,
          debtStatus: debt.debtStatus,
          debtAmount: debt.debtAmount,
          balanceAfter: wallet.balance,
        };
      }),

    withdraw: (body) =>
      run('wallet.withdraw', (ctx) => {
        const user = me(ctx);
        if (!user.bankCode || !user.accountNo) E.fail(409, 'ACCOUNT_NOT_REGISTERED');
        if (
          !Number.isInteger(body.amount) ||
          body.amount < POLICY.minWithdrawal ||
          body.amount > POLICY.maxWithdrawal
        )
          E.fail(400, 'INVALID_INPUT');
        const wallet = E.walletOf(ctx, user.id);
        if (body.amount > wallet.balance)
          E.fail(409, 'INSUFFICIENT_BALANCE', '잔액 부족', {
            requiredAmount: body.amount,
            balance: wallet.balance,
            shortageAmount: body.amount - wallet.balance,
          });
        const row = {
          id: nextId(ctx.db),
          memberId: user.id,
          amount: body.amount,
          bankCode: user.bankCode,
          accountNo: user.accountNo,
          accountHolder: user.accountHolder,
          transferProvider: 'DUMMY',
          transferTid: null as string | null,
          status: 'REQUESTED' as T.WithdrawalStatus,
          failReason: null as string | null,
          balanceAfter: null as number | null,
          requestedAt: ctx.now,
          completedAt: null as number | null,
        };
        ctx.db.withdrawals.push(row);
        wallet.balance -= body.amount;
        E.ledger(ctx, wallet, 'WITHDRAW', -body.amount, { withdrawalId: row.id });
        row.completedAt = ctx.now;
        if (body.amount === DUMMY_FAIL_AMOUNT) {
          row.status = 'FAILED';
          row.failReason = '수취 은행 점검 시간 (시연용 실패)';
          wallet.balance += body.amount;
          E.ledger(ctx, wallet, 'WITHDRAW_REFUND', body.amount, { withdrawalId: row.id });
          E.notify(
            ctx,
            user.id,
            'PAYMENT',
            '출금에 실패했어요',
            `${body.amount.toLocaleString()}원을 지갑에 돌려드렸어요.`,
          );
        } else {
          row.status = 'COMPLETED';
          row.transferTid = `DUMMY-${crypto.randomUUID()}`;
          E.notify(
            ctx,
            user.id,
            'PAYMENT',
            '출금이 완료됐어요',
            `${body.amount.toLocaleString()}원이 ${E.bankName(user.bankCode)} ****${user.accountNo.slice(-4)} 계좌로 입금되었습니다.`,
          );
        }
        row.balanceAfter = wallet.balance;
        return toWithdrawal(row);
      }),

    withdrawals: (query = {}) =>
      run('wallet.withdrawals', (ctx) => {
        const user = me(ctx);
        return E.paginate(
          ctx.db.withdrawals
            .filter((w) => w.memberId === user.id)
            .sort((a, b) => b.id - a.id)
            .map(toWithdrawal),
          query.page,
          query.size,
        );
      }),

    payments: (query = {}) =>
      run(
        'wallet.payments',
        (ctx) => (me(ctx), E.paginate<T.PaymentResponse>([], query.page, query.size)),
      ),
  },

  pots: {
    list: (query = {}) =>
      run('pots.list', (ctx) => {
        const user = me(ctx);
        const origin =
          query.lat !== undefined && query.lng !== undefined
            ? { lat: query.lat, lng: query.lng }
            : null;
        const radius = query.radius ?? 1000;
        const from = query.from ? E.parseTime(query.from, 'from') : null;
        const to = query.to ? E.parseTime(query.to, 'to') : null;
        const genderOk = (option: T.GenderOption) =>
          option === 'ALL' || (option === 'MALE') === (user.gender === 'M');
        const rows = ctx.db.pots
          .filter((p) => p.status === 'RECRUITING' && genderOk(p.genderOption))
          .filter((p) => !query.genderOption || p.genderOption === query.genderOption)
          .filter(
            (p) => !query.departureName || p.departureName.includes(query.departureName.trim()),
          )
          .filter(
            (p) =>
              !query.destinationName || p.destinationName.includes(query.destinationName.trim()),
          )
          .filter((p) => from === null || p.departureTime >= from)
          .filter((p) => to === null || p.departureTime <= to)
          .filter(
            (p) =>
              !query.minHostRating || E.userById(ctx, p.hostId)!.ratingAvg >= query.minHostRating,
          )
          .map((p) => ({
            p,
            d: origin ? distanceMeters(origin, { lat: p.departureLat, lng: p.departureLng }) : null,
          }))
          .filter(({ d }) => d === null || d <= radius);
        const sort =
          query.sort === 'DISTANCE' && !origin
            ? 'DEPARTURE_TIME'
            : (query.sort ?? 'DEPARTURE_TIME');
        rows.sort((a, b) => {
          if (a.p.hasCanceled !== b.p.hasCanceled) return a.p.hasCanceled ? -1 : 1;
          if (sort === 'DISTANCE') return (a.d ?? 0) - (b.d ?? 0);
          if (sort === 'HOST_RATING')
            return E.userById(ctx, b.p.hostId)!.ratingAvg - E.userById(ctx, a.p.hostId)!.ratingAvg;
          return a.p.departureTime - b.p.departureTime;
        });
        return E.paginate(
          rows.map(({ p, d }) => E.toSummary(ctx, p, d)),
          query.page,
          query.size,
        );
      }),

    create: (body) =>
      run('pots.create', (ctx) => {
        const user = me(ctx);
        const departure = E.parseTime(body.departureTime, 'departureTime');
        const title = body.title.trim();
        if (!title || title.length > 100 || ![3, 4].includes(body.maxMembers))
          E.fail(400, 'INVALID_INPUT');
        if (
          !Number.isInteger(body.expectedFare) ||
          body.expectedFare < 0 ||
          body.expectedFare > POLICY.maxFare
        )
          E.fail(400, 'INVALID_INPUT');
        const min = ctx.now + POLICY.minLeadMinutes * MIN;
        const max = ctx.now + POLICY.maxAdvanceHours * HOUR;
        if (departure < min)
          E.fail(400, 'DEPARTURE_TIME_TOO_SOON', '출발 시각이 너무 이릅니다.', {
            minDepartureTime: E.iso(min),
          });
        if (departure > max)
          E.fail(400, 'DEPARTURE_TIME_TOO_FAR', '출발 시각이 너무 늦습니다.', {
            maxDepartureTime: E.iso(max),
          });
        const genderOption = body.genderOption ?? 'ALL';
        const hold = holdAmountOf(body.expectedFare, body.maxMembers);
        E.assertEligible(ctx, user, { genderOption, holdAmount: hold });
        const pot = {
          id: nextId(ctx.db),
          hostId: user.id,
          title,
          departureName: body.departureName.trim(),
          departureLat: body.departureLat,
          departureLng: body.departureLng,
          destinationName: body.destinationName.trim(),
          destinationLat: body.destinationLat,
          destinationLng: body.destinationLng,
          departureTime: departure,
          arrivalDeadline: departure - POLICY.arrivalDeadlineMinutes * MIN,
          maxMembers: body.maxMembers,
          currentMembers: 1,
          genderOption,
          expectedFare: body.expectedFare,
          actualFare: null,
          receiptImage: null,
          startedAt: null,
          startRemindedAt: null,
          fareClaimStatus: 'NONE' as const,
          fareClaimedAt: null,
          fareReviewedAt: null,
          fareRejectReason: null,
          status: 'RECRUITING' as const,
          hasCanceled: false,
          openChatUrl: body.openChatUrl?.trim() || null,
          createdAt: ctx.now,
          updatedAt: ctx.now,
          botJoinAt: ctx.now + 8000,
        };
        ctx.db.pots.push(pot);
        ctx.db.members.push({
          id: nextId(ctx.db),
          potId: pot.id,
          memberId: user.id,
          role: 'HOST',
          preferredSeat: assertSeat(body.preferredSeat),
          status: 'JOINED',
          arrivedAt: null,
          joinedAt: ctx.now,
          canceledAt: null,
        });
        E.holdDeposit(ctx, pot, user.id);
        return E.toDetail(ctx, pot, user.id);
      }),

    detail: (potId) =>
      run('pots.detail', (ctx) => E.toDetail(ctx, E.potById(ctx, potId), me(ctx).id)),

    update: (potId, body) =>
      run('pots.update', (ctx) => {
        const { user, pot } = hostPot(ctx, potId);
        if (pot.status !== 'RECRUITING' && pot.status !== 'CLOSED')
          E.fail(409, 'INVALID_POT_STATUS');
        if (body.title !== undefined) {
          if (!body.title.trim() || body.title.length > 100) E.fail(400, 'INVALID_INPUT');
          pot.title = body.title.trim();
        }
        if (body.openChatUrl !== undefined) pot.openChatUrl = body.openChatUrl.trim() || null;
        pot.updatedAt = ctx.now;
        E.touch(ctx, pot.id);
        return E.toDetail(ctx, pot, user.id);
      }),

    cancel: (potId) =>
      run('pots.cancel', (ctx) => {
        const { pot } = hostPot(ctx, potId);
        if (pot.status !== 'RECRUITING' && pot.status !== 'CLOSED')
          E.fail(409, 'INVALID_POT_STATUS');
        const deadline = pot.departureTime - POLICY.cancelDeadlineMinutes * MIN;
        if (ctx.now >= deadline)
          E.fail(409, 'CANCEL_TIME_EXPIRED', '취소 가능 시간이 지났습니다.', {
            cancelDeadline: E.iso(deadline),
          });
        E.cancelPot(ctx, pot, '방장이 방을 취소했어요.');
      }),

    start: (potId) =>
      run('pots.start', (ctx) => {
        const { user, pot } = hostPot(ctx, potId);
        if (pot.status !== 'RECRUITING' && pot.status !== 'CLOSED')
          E.fail(409, 'INVALID_POT_STATUS');
        const joined = ctx.db.members.filter((m) => m.potId === pot.id && m.status === 'JOINED');
        if (joined.some((m) => m.arrivedAt === null || m.arrivedAt > ctx.now))
          E.fail(409, 'NOT_ALL_ARRIVED');
        if (joined.length < 2) E.fail(409, 'NOT_ENOUGH_MEMBERS');
        pot.status = 'RUNNING';
        pot.startedAt = ctx.now;
        pot.updatedAt = ctx.now;
        joined.forEach((m) => (m.status = 'BOARDED'));
        ctx.db.members
          .filter((m) => m.potId === pot.id && m.status === 'REQUESTED')
          .forEach((m) => {
            m.status = 'CANCELED';
            m.canceledAt = ctx.now;
            E.notify(
              ctx,
              m.memberId,
              'POT',
              '입장 요청이 마감됐어요',
              `${pot.title} · 택시가 출발했어요.`,
              pot.id,
            );
          });
        E.touch(ctx, pot.id);
        return E.toDetail(ctx, pot, user.id);
      }),

    join: (potId, body = {}) =>
      run('pots.join', (ctx) => {
        const user = me(ctx);
        const pot = E.potById(ctx, potId);
        const existing = E.memberOf(ctx, pot.id, user.id);
        if (existing?.status === 'KICKED' || existing?.status === 'NO_SHOW')
          E.fail(403, 'KICKED_FROM_POT');
        if (existing?.status === 'REJECTED') E.fail(403, 'JOIN_REQUEST_REJECTED');
        if (existing?.status === 'JOINED' || existing?.status === 'BOARDED')
          E.fail(409, 'ALREADY_JOINED');
        if (pot.status !== 'RECRUITING')
          E.fail(
            pot.status === 'CLOSED' ? 409 : 409,
            pot.status === 'CLOSED' ? 'POT_FULL' : 'INVALID_POT_STATUS',
            '',
            pot.status === 'CLOSED'
              ? { maxMembers: pot.maxMembers, currentMembers: pot.currentMembers }
              : null,
          );
        if (ctx.now >= pot.arrivalDeadline)
          E.fail(409, 'JOIN_DEADLINE_PASSED', '참여 마감', {
            joinDeadline: E.iso(pot.arrivalDeadline),
          });
        const hold = holdAmountOf(pot.expectedFare, pot.maxMembers);
        E.assertEligible(ctx, user, { genderOption: pot.genderOption, pot, holdAmount: hold });
        const seat = assertSeat(body.preferredSeat);
        const member = existing ?? {
          id: nextId(ctx.db),
          potId: pot.id,
          memberId: user.id,
          role: 'GUEST' as const,
          preferredSeat: seat,
          status: 'JOINED' as const,
          arrivedAt: null,
          joinedAt: ctx.now,
          canceledAt: null,
        };
        Object.assign(member, {
          status: 'JOINED',
          joinedAt: ctx.now,
          arrivedAt: null,
          canceledAt: null,
          preferredSeat: seat,
        });
        if (!existing) ctx.db.members.push(member);
        pot.currentMembers += 1;
        const heldAmount = E.holdDeposit(ctx, pot, user.id);
        if (pot.currentMembers >= pot.maxMembers) {
          pot.status = 'CLOSED';
          E.activeMembers(ctx, pot.id).forEach((m) =>
            E.notify(
              ctx,
              m.memberId,
              'POT',
              '모집이 완료됐어요',
              `${pot.title} · 출발 5분 전까지 출발지에서 도착 확인을 해 주세요.`,
              pot.id,
            ),
          );
        } else {
          E.notify(
            ctx,
            pot.hostId,
            'POT',
            '새 동승자가 참여했어요',
            `${user.nickname}님이 ${pot.title}에 참여했어요.`,
            pot.id,
          );
        }
        pot.updatedAt = ctx.now;
        E.touch(ctx, pot.id);
        return {
          potId: pot.id,
          member: E.toMember(ctx, member),
          heldAmount,
          balanceAfter: E.walletOf(ctx, user.id).balance,
          potStatus: pot.status,
        };
      }),

    leave: (potId) =>
      run('pots.leave', (ctx) => {
        const user = me(ctx);
        const pot = E.potById(ctx, potId);
        const member = E.memberOf(ctx, pot.id, user.id);
        if (member?.role === 'HOST') E.fail(403, 'HOST_CANNOT_LEAVE');
        if (!member || member.status !== 'JOINED') E.fail(403, 'NOT_POT_MEMBER');
        const deadline = pot.departureTime - POLICY.cancelDeadlineMinutes * MIN;
        if (ctx.now >= deadline)
          E.fail(409, 'CANCEL_TIME_EXPIRED', '취소 가능 시간이 지났습니다.', {
            cancelDeadline: E.iso(deadline),
          });
        E.removeMember(ctx, pot, member, 'CANCELED');
        E.notify(
          ctx,
          pot.hostId,
          'POT',
          '동승자가 참여를 취소했어요',
          `${user.nickname}님이 ${pot.title}에서 나갔어요.`,
          pot.id,
        );
      }),

    changeSeat: (potId, body) =>
      run('pots.changeSeat', (ctx) => {
        const { pot, member } = participant(ctx, potId, ['JOINED']);
        if (pot.status !== 'RECRUITING' && pot.status !== 'CLOSED')
          E.fail(409, 'INVALID_POT_STATUS');
        member.preferredSeat = assertSeat(body.preferredSeat);
        E.touch(ctx, pot.id);
        return E.toMember(ctx, member);
      }),

    arrive: (potId, body) =>
      run('pots.arrive', (ctx) => {
        const { pot, member } = participant(ctx, potId, ['JOINED']);
        if (pot.status !== 'RECRUITING' && pot.status !== 'CLOSED')
          E.fail(409, 'INVALID_POT_STATUS');
        if (ctx.now >= pot.arrivalDeadline)
          E.fail(409, 'ARRIVAL_DEADLINE_PASSED', '집결 기한 경과', {
            arrivalDeadline: E.iso(pot.arrivalDeadline),
          });
        if (member.arrivedAt !== null && member.arrivedAt <= ctx.now)
          E.fail(409, 'ALREADY_ARRIVED');
        const meters = E.withinArrivalRange(pot, body.lat, body.lng);
        member.arrivedAt = ctx.now;
        const joined = ctx.db.members.filter((m) => m.potId === pot.id && m.status === 'JOINED');
        const arrived = joined.filter((m) => m.arrivedAt !== null && m.arrivedAt <= ctx.now).length;
        if (arrived === joined.length) {
          joined.forEach((m) =>
            E.notify(
              ctx,
              m.memberId,
              'POT',
              '모두 도착했어요',
              `${pot.title} · 방장이 탑승 시작을 누르면 출발해요.`,
              pot.id,
            ),
          );
        }
        E.touch(ctx, pot.id);
        return {
          potId: pot.id,
          arrivedAt: E.iso(ctx.now),
          distanceMeters: meters,
          arrivedCount: arrived,
          totalMembers: joined.length,
          allArrived: arrived === joined.length,
        };
      }),

    kick: (potId, userId) =>
      run('pots.kick', (ctx) => {
        const { pot } = hostPot(ctx, potId);
        if (pot.status !== 'RECRUITING' && pot.status !== 'CLOSED')
          E.fail(409, 'INVALID_POT_STATUS');
        const member = E.memberOf(ctx, pot.id, userId);
        if (!member || member.status !== 'JOINED' || member.role === 'HOST')
          E.fail(409, 'NOT_POT_MEMBER');
        if (member.arrivedAt !== null && member.arrivedAt <= ctx.now)
          E.fail(409, 'MEMBER_ALREADY_ARRIVED');
        const target = E.userById(ctx, userId)!;
        const afterDeadline = ctx.now >= pot.arrivalDeadline;
        E.removeMember(ctx, pot, member, afterDeadline ? 'NO_SHOW' : 'KICKED');
        if (afterDeadline) E.markNoShow(ctx, target);
        E.notify(
          ctx,
          userId,
          'KICKED',
          '택시팟에서 내보내졌어요',
          `${pot.title} · 예치금은 전액 돌려드렸어요.${afterDeadline ? ' 집결 기한이 지나 15분 동안 이용이 제한돼요.' : ''}`,
          pot.id,
        );
      }),

    requestJoin: (potId, body) =>
      run('pots.requestJoin', (ctx) => {
        const user = me(ctx);
        const pot = E.potById(ctx, potId);
        const existing = E.memberOf(ctx, pot.id, user.id);
        if (pot.status !== 'RECRUITING')
          E.fail(409, pot.status === 'CLOSED' ? 'POT_FULL' : 'INVALID_POT_STATUS');
        if (ctx.now < pot.arrivalDeadline) E.fail(409, 'JOIN_REQUEST_NOT_AVAILABLE');
        E.withinArrivalRange(pot, body.lat, body.lng);
        if (existing?.status === 'KICKED' || existing?.status === 'NO_SHOW')
          E.fail(403, 'KICKED_FROM_POT');
        if (existing?.status === 'REJECTED') E.fail(403, 'JOIN_REQUEST_REJECTED');
        if (existing?.status === 'REQUESTED') E.fail(409, 'ALREADY_REQUESTED');
        if (existing?.status === 'JOINED') E.fail(409, 'ALREADY_JOINED');
        E.assertEligible(ctx, user, {
          genderOption: pot.genderOption,
          pot,
          holdAmount: holdAmountOf(pot.expectedFare, pot.maxMembers),
        });
        const seat = assertSeat(body.preferredSeat);
        const member = existing ?? {
          id: nextId(ctx.db),
          potId: pot.id,
          memberId: user.id,
          role: 'GUEST' as const,
          preferredSeat: seat,
          status: 'REQUESTED' as const,
          arrivedAt: null,
          joinedAt: ctx.now,
          canceledAt: null,
        };
        Object.assign(member, {
          status: 'REQUESTED',
          joinedAt: ctx.now,
          preferredSeat: seat,
          canceledAt: null,
          arrivedAt: null,
        });
        if (!existing) ctx.db.members.push(member);
        E.notify(
          ctx,
          pot.hostId,
          'POT',
          '입장 요청이 왔어요',
          `${user.nickname}님이 출발지 근처에서 입장을 요청했어요.`,
          pot.id,
        );
        E.touch(ctx, pot.id);
        return {
          potId: pot.id,
          memberId: user.id,
          nickname: user.nickname,
          ratingAvg: user.ratingAvg,
          preferredSeat: seat,
          status: 'REQUESTED' as const,
          requestedAt: E.iso(ctx.now),
        };
      }),

    joinRequests: (potId) =>
      run('pots.joinRequests', (ctx) => {
        const { pot } = hostPot(ctx, potId);
        return ctx.db.members
          .filter((m) => m.potId === pot.id && m.status === 'REQUESTED')
          .sort((a, b) => a.joinedAt - b.joinedAt)
          .map((m) => {
            const u = E.userById(ctx, m.memberId)!;
            return {
              potId: pot.id,
              memberId: u.id,
              nickname: u.nickname,
              ratingAvg: u.ratingAvg,
              preferredSeat: m.preferredSeat,
              status: m.status,
              requestedAt: E.iso(m.joinedAt),
            };
          });
      }),

    withdrawJoinRequest: (potId) =>
      run('pots.withdrawJoinRequest', (ctx) => {
        const user = me(ctx);
        const member = E.memberOf(ctx, potId, user.id);
        if (!member || member.status !== 'REQUESTED') E.fail(409, 'JOIN_REQUEST_NOT_FOUND');
        member.status = 'CANCELED';
        member.canceledAt = ctx.now;
        E.touch(ctx, potId);
      }),

    acceptJoinRequest: (potId, userId) =>
      run('pots.acceptJoinRequest', (ctx) => {
        const { pot } = hostPot(ctx, potId);
        const member = E.memberOf(ctx, pot.id, userId);
        if (!member || member.status !== 'REQUESTED') E.fail(409, 'JOIN_REQUEST_NOT_FOUND');
        if (pot.status !== 'RECRUITING') E.fail(409, 'INVALID_POT_STATUS');
        const requester = E.userById(ctx, userId)!;
        E.assertEligible(ctx, requester, {
          genderOption: pot.genderOption,
          pot,
          holdAmount: holdAmountOf(pot.expectedFare, pot.maxMembers),
        });
        member.status = 'JOINED';
        member.arrivedAt = ctx.now;
        pot.currentMembers += 1;
        const heldAmount = E.holdDeposit(ctx, pot, userId);
        if (pot.currentMembers >= pot.maxMembers) {
          pot.status = 'CLOSED';
          ctx.db.members
            .filter((m) => m.potId === pot.id && m.status === 'REQUESTED')
            .forEach((m) => {
              m.status = 'CANCELED';
              m.canceledAt = ctx.now;
              E.notify(
                ctx,
                m.memberId,
                'POT',
                '자리가 마감됐어요',
                `${pot.title} · 다른 택시팟을 찾아보세요.`,
                pot.id,
              );
            });
        }
        E.notify(
          ctx,
          userId,
          'POT',
          '입장 요청이 수락됐어요',
          `${pot.title} · 바로 탑승할 수 있어요.`,
          pot.id,
        );
        E.touch(ctx, pot.id);
        return {
          potId: pot.id,
          member: E.toMember(ctx, member),
          heldAmount,
          balanceAfter: E.walletOf(ctx, userId).balance,
          potStatus: pot.status,
        };
      }),

    rejectJoinRequest: (potId, userId) =>
      run('pots.rejectJoinRequest', (ctx) => {
        const { pot } = hostPot(ctx, potId);
        const member = E.memberOf(ctx, pot.id, userId);
        if (!member || member.status !== 'REQUESTED') E.fail(409, 'JOIN_REQUEST_NOT_FOUND');
        member.status = 'REJECTED';
        member.canceledAt = ctx.now;
        E.notify(
          ctx,
          userId,
          'POT',
          '입장 요청이 거절됐어요',
          `${pot.title} · 다른 택시팟을 찾아보세요.`,
          pot.id,
        );
        E.touch(ctx, pot.id);
      }),

    claimFare: async (potId, actualFare, file) => {
      const image = file && file.size > 0 ? await storeImage(file) : null;
      return run('pots.claimFare', (ctx) => {
        const { pot } = hostPot(ctx, potId);
        if (!image) E.fail(400, 'RECEIPT_REQUIRED');
        if (!Number.isInteger(actualFare) || actualFare < 0 || actualFare > POLICY.maxFare)
          E.fail(400, 'INVALID_INPUT');
        if (pot.status !== 'RUNNING')
          E.fail(
            409,
            pot.fareClaimStatus === 'APPROVED' ? 'ALREADY_SETTLED' : 'INVALID_POT_STATUS',
          );
        if (pot.fareClaimStatus === 'PENDING') E.fail(409, 'FARE_CLAIM_IN_REVIEW');
        Object.assign(pot, {
          actualFare,
          receiptImage: image,
          fareClaimStatus: 'PENDING',
          fareClaimedAt: ctx.now,
          fareRejectReason: null,
          updatedAt: ctx.now,
        });
        E.notifyAdmins(
          ctx,
          '정산 청구 확인 요청',
          `${pot.title} · 실요금 ${actualFare.toLocaleString()}원`,
          pot.id,
        );
        E.touch(ctx, pot.id);
        return E.toFareClaim(ctx, pot);
      });
    },

    settlement: (potId) =>
      run('pots.settlement', (ctx) => {
        const user = me(ctx);
        const pot = E.potById(ctx, potId);
        if (!E.memberOf(ctx, pot.id, user.id)) E.fail(403, 'NOT_POT_MEMBER');
        const rows = ctx.db.settlements.filter((s) => s.potId === pot.id);
        return {
          potId: pot.id,
          expectedFare: pot.expectedFare,
          actualFare: pot.status === 'COMPLETED' ? pot.actualFare : null,
          boardedCount: ctx.db.members.filter((m) => m.potId === pot.id && m.status === 'BOARDED')
            .length,
          hostPayoutAmount: pot.status === 'COMPLETED' ? pot.actualFare : null,
          receiptUrl: pot.receiptImage ? `/api/pots/${pot.id}/receipt` : null,
          settlements: rows.map((s) => E.toSettlement(ctx, s)),
        };
      }),

    receipt: async (potId) => {
      const stored = await run('pots.receipt', (ctx) => {
        const { pot } = participant(ctx, potId, ['BOARDED']);
        return pot.receiptImage ?? E.fail(404, 'NOT_FOUND');
      });
      return blobFromStored(stored, '결제내역');
    },

    ratingTargets: (potId) =>
      run('pots.ratingTargets', (ctx) => {
        const { user, pot } = participant(ctx, potId, ['BOARDED']);
        return ctx.db.members
          .filter((m) => m.potId === pot.id && m.status === 'BOARDED' && m.memberId !== user.id)
          .map((m) => ({
            memberId: m.memberId,
            nickname: E.userById(ctx, m.memberId)!.nickname,
            role: m.role,
            isRated: ctx.db.ratings.some(
              (r) => r.potId === pot.id && r.reviewerId === user.id && r.revieweeId === m.memberId,
            ),
          }));
      }),

    rate: (potId, body) =>
      run('pots.rate', (ctx) => {
        const { user, pot } = participant(ctx, potId, ['BOARDED']);
        if (pot.status !== 'COMPLETED') E.fail(409, 'INVALID_POT_STATUS');
        if ((pot.fareReviewedAt ?? 0) + POLICY.ratingPeriodHours * HOUR <= ctx.now)
          E.fail(409, 'RATING_PERIOD_EXPIRED');
        const created = body.ratings.map((item) => {
          if (item.revieweeId === user.id) E.fail(400, 'SELF_RATING_NOT_ALLOWED');
          const scores = [
            item.noshowScore,
            item.mannerScore,
            item.communicationScore,
            item.paymentScore,
          ];
          if (scores.some((s) => !Number.isInteger(s) || s < 1 || s > 5))
            E.fail(400, 'INVALID_INPUT');
          const avg = scores.reduce((a, b) => a + b, 0) / 4;
          if (avg < 3 && !item.badReason?.trim()) E.fail(400, 'BAD_REASON_REQUIRED');
          const target = E.memberOf(ctx, pot.id, item.revieweeId);
          if (!target || target.status !== 'BOARDED') E.fail(403, 'NOT_POT_MEMBER');
          if (
            ctx.db.ratings.some(
              (r) =>
                r.potId === pot.id && r.reviewerId === user.id && r.revieweeId === item.revieweeId,
            )
          )
            E.fail(409, 'ALREADY_RATED');
          return { item, avg };
        });
        return created.map(({ item, avg }) => {
          const row = {
            id: nextId(ctx.db),
            potId: pot.id,
            reviewerId: user.id,
            revieweeId: item.revieweeId,
            noshowScore: item.noshowScore,
            mannerScore: item.mannerScore,
            communicationScore: item.communicationScore,
            paymentScore: item.paymentScore,
            badReason: item.badReason?.trim() || null,
            isDefault: false,
            createdAt: ctx.now,
          };
          ctx.db.ratings.push(row);
          const reviewee = E.userById(ctx, item.revieweeId)!;
          const delta = avg >= 4 ? 0.2 : avg < 3 ? -0.2 : 0;
          reviewee.ratingAvg = Math.min(
            10,
            Math.max(1, Math.round((reviewee.ratingAvg + delta) * 100) / 100),
          );
          return { ...row, avgScore: Math.round(avg * 100) / 100, createdAt: E.iso(row.createdAt) };
        });
      }),
  },

  reports: {
    create: (body) =>
      run('reports.create', (ctx) => {
        const user = me(ctx);
        if (body.reportedId === user.id) E.fail(400, 'SELF_REPORT_NOT_ALLOWED');
        if (!body.reason.trim() || body.reason.length > 255) E.fail(400, 'INVALID_INPUT');
        const pot = E.potById(ctx, body.potId);
        const mine = E.memberOf(ctx, pot.id, user.id);
        const target = E.memberOf(ctx, pot.id, body.reportedId);
        const bothBoarded = mine?.status === 'BOARDED' && target?.status === 'BOARDED';
        const noShowVictim =
          target?.status === 'NO_SHOW' && (mine?.status === 'JOINED' || mine?.status === 'BOARDED');
        if (!bothBoarded && !noShowVictim) E.fail(403, 'REPORT_NOT_ELIGIBLE');
        if (!bothBoarded && body.type !== 'NO_SHOW')
          E.fail(400, 'INVALID_INPUT', '노쇼 신고만 가능합니다.');
        if (
          ctx.db.reports.some(
            (r) =>
              r.potId === pot.id && r.reporterId === user.id && r.reportedId === body.reportedId,
          )
        )
          E.fail(409, 'DUPLICATE_REPORT');
        const row = {
          id: nextId(ctx.db),
          potId: pot.id,
          reporterId: user.id,
          reportedId: body.reportedId,
          type: body.type,
          reason: body.reason.trim(),
          status: 'PENDING' as const,
          processedAt: null,
          createdAt: ctx.now,
        };
        ctx.db.reports.push(row);
        E.notifyAdmins(ctx, '새 신고가 접수됐어요', `${pot.title}`, pot.id);
        return {
          id: row.id,
          reportedId: row.reportedId,
          reportedNickname: E.userById(ctx, row.reportedId)!.nickname,
          potId: row.potId,
          type: row.type,
          reason: row.reason,
          status: row.status,
          processedAt: null,
          createdAt: E.iso(row.createdAt),
        };
      }),
  },

  chat: {
    messages: (potId, cursor, size = 30) =>
      run('chat.messages', (ctx) => {
        participant(ctx, potId);
        const all = ctx.db.messages
          .filter((m) => m.potId === potId && (!cursor || m.id < cursor))
          .sort((a, b) => b.id - a.id);
        const page = all.slice(0, size);
        return {
          messages: page.map((m) => E.toChat(ctx, m)),
          nextCursor: all.length > size ? page[page.length - 1].id : null,
          hasNext: all.length > size,
        };
      }),

    send: (potId, body) =>
      run('chat.send', (ctx) => {
        const { user, pot } = participant(ctx, potId);
        if (pot.status === 'COMPLETED' || pot.status === 'CANCELED')
          E.fail(409, 'INVALID_POT_STATUS');
        const msgType = body.msgType ?? 'TEXT';
        const content = body.content.trim();
        if (!content || content.length > 1000) E.fail(400, 'INVALID_INPUT');
        if (msgType === 'QUICK' && !QUICK_BLOCKS.some((q) => q.content === content))
          E.fail(400, 'INVALID_QUICK_MESSAGE');
        const row = {
          id: nextId(ctx.db),
          potId: pot.id,
          senderId: user.id,
          msgType,
          content,
          sentAt: ctx.now,
        };
        ctx.db.messages.push(row);
        const chat = E.toChat(ctx, row);
        ctx.chats.push(chat);
        return chat;
      }),

    quickBlocks: () => run('chat.quickBlocks', () => QUICK_BLOCKS.map((q) => ({ ...q }))),
  },

  notifications: {
    list: (query = {}) =>
      run('notifications.list', (ctx) => {
        const user = me(ctx);
        const rows = ctx.db.notifications
          .filter((n) => n.memberId === user.id && (!query.unreadOnly || !n.isRead))
          .sort((a, b) => b.id - a.id)
          .map((n) => ({
            id: n.id,
            potId: n.potId,
            type: n.type,
            title: n.title,
            content: n.content,
            isRead: n.isRead,
            createdAt: E.iso(n.createdAt),
          }));
        return E.paginate(rows, query.page, query.size);
      }),
    unreadCount: () =>
      run('notifications.unread', (ctx) => {
        const user = me(ctx);
        return {
          unreadCount: ctx.db.notifications.filter((n) => n.memberId === user.id && !n.isRead)
            .length,
        };
      }),
    read: (id) =>
      run('notifications.read', (ctx) => {
        const user = me(ctx);
        const row =
          ctx.db.notifications.find((n) => n.id === id && n.memberId === user.id) ??
          E.fail(404, 'NOT_FOUND');
        row.isRead = true;
      }),
    readAll: () =>
      run('notifications.readAll', (ctx) => {
        const user = me(ctx);
        ctx.db.notifications
          .filter((n) => n.memberId === user.id)
          .forEach((n) => (n.isRead = true));
      }),
  },

  admin: {
    verifications: (query = {}) =>
      run('admin.verifications', (ctx) => {
        E.requireAdmin(ctx);
        const status = query.reviewStatus ?? 'PENDING';
        const latestIds = new Set(ctx.db.users.map((u) => E.latestVerification(ctx, u.id)?.id));
        const rows = ctx.db.verifications
          .filter((v) => v.reviewStatus === status && latestIds.has(v.id))
          .sort((a, b) => a.id - b.id);
        return E.paginate(
          rows.map((v) => toAdminVerification(ctx, v)),
          query.page,
          query.size,
        );
      }),
    verification: (id) =>
      run('admin.verification', (ctx) => {
        E.requireAdmin(ctx);
        return toAdminVerification(
          ctx,
          ctx.db.verifications.find((v) => v.id === id) ?? E.fail(404, 'NOT_FOUND'),
        );
      }),
    reviewVerification: (id, body) =>
      run('admin.reviewVerification', (ctx) => {
        E.requireAdmin(ctx);
        const row = ctx.db.verifications.find((v) => v.id === id) ?? E.fail(404, 'NOT_FOUND');
        if (row.reviewStatus === 'NOT_SUBMITTED') E.fail(409, 'CAPTURE_NOT_SUBMITTED');
        if (row.reviewStatus !== 'PENDING') E.fail(409, 'ALREADY_REVIEWED');
        const user = E.userById(ctx, row.memberId)!;
        if (body.reviewStatus === 'REJECTED') {
          if (!body.rejectReason?.trim()) E.fail(400, 'REJECT_REASON_REQUIRED');
          row.reviewStatus = 'REJECTED';
          row.rejectReason = body.rejectReason.trim();
          E.notify(
            ctx,
            user.id,
            'SYSTEM',
            '학생 인증이 반려됐어요',
            `사유: ${row.rejectReason} · 캡처본을 다시 제출해 주세요.`,
          );
        } else {
          if (row.studentNo !== user.studentNo) E.fail(400, 'STUDENT_NO_MISMATCH');
          row.reviewStatus = 'APPROVED';
          user.isVerified = true;
          E.notify(
            ctx,
            user.id,
            'SYSTEM',
            '학생 인증이 완료됐어요',
            '이제 택시팟을 만들고 참여할 수 있어요.',
          );
        }
        row.reviewedAt = ctx.now;
        return toAdminVerification(ctx, row);
      }),
    verificationCapture: async (id) => {
      const stored = await run('admin.capture', (ctx) => {
        E.requireAdmin(ctx);
        const row = ctx.db.verifications.find((v) => v.id === id);
        return row?.captureImage ?? E.fail(404, 'NOT_FOUND');
      });
      return blobFromStored(stored, '학생 정보 캡처');
    },
    users: (query = {}) =>
      run('admin.users', (ctx) => {
        E.requireAdmin(ctx);
        const keyword = query.keyword?.trim().toLowerCase() ?? '';
        const rows = ctx.db.users
          .filter((u) => !query.status || u.status === query.status)
          .filter(
            (u) =>
              !keyword ||
              [u.name, u.nickname, u.email, u.studentNo].some((v) =>
                v.toLowerCase().includes(keyword),
              ),
          )
          .sort((a, b) => b.id - a.id)
          .map(E.toAdminUser);
        return E.paginate(rows, query.page, query.size);
      }),
    user: (userId) =>
      run('admin.user', (ctx) => {
        E.requireAdmin(ctx);
        const user = E.userById(ctx, userId) ?? E.fail(404, 'NOT_FOUND');
        const wallet = E.toWallet(ctx, user.id);
        return {
          ...E.toAdminUser(user),
          cleanStreak: user.cleanStreak,
          walletBalance: wallet.balance,
          heldBalance: wallet.heldBalance,
          debtAmount: wallet.debtAmount,
          verifications: ctx.db.verifications
            .filter((v) => v.memberId === user.id)
            .map((v) => toAdminVerification(ctx, v)),
          receivedReports: ctx.db.reports
            .filter((r) => r.reportedId === user.id)
            .map((r) => toAdminReport(ctx, r)),
          phone: user.phone,
          gender: user.gender,
          potHistory: historyOf(ctx, user.id).slice(0, 10),
        };
      }),
    userPots: (userId, query = {}) =>
      run('admin.userPots', (ctx) => {
        E.requireAdmin(ctx);
        E.userById(ctx, userId) ?? E.fail(404, 'NOT_FOUND');
        return E.paginate(historyOf(ctx, userId), query.page, query.size);
      }),
    updateUserStatus: (userId, body) =>
      run('admin.updateUserStatus', (ctx) => {
        E.requireAdmin(ctx);
        const user = E.userById(ctx, userId) ?? E.fail(404, 'NOT_FOUND');
        if (user.status === 'WITHDRAWN') E.fail(403, 'WITHDRAWN_USER');
        if (body.status === 'ACTIVE') {
          user.status = 'ACTIVE';
          user.suspendedUntil = null;
        } else {
          E.suspend(
            user,
            body.suspendedUntil ? E.parseTime(body.suspendedUntil, 'suspendedUntil') : null,
            ctx.now,
          );
        }
        return E.toAdminUser(user);
      }),
    adjustWallet: (userId, body) =>
      run('admin.adjustWallet', (ctx) => {
        E.requireAdmin(ctx);
        const user = E.userById(ctx, userId) ?? E.fail(404, 'NOT_FOUND');
        if (
          !Number.isInteger(body.amount) ||
          body.amount === 0 ||
          Math.abs(body.amount) > POLICY.walletMaxBalance
        )
          E.fail(400, 'INVALID_INPUT');
        const wallet = E.walletOf(ctx, user.id);
        if (wallet.balance + body.amount < 0)
          E.fail(409, 'INSUFFICIENT_BALANCE', '잔액 부족', {
            requiredAmount: -body.amount,
            balance: wallet.balance,
            shortageAmount: -body.amount - wallet.balance,
          });
        if (
          body.amount > 0 &&
          wallet.balance + wallet.heldBalance + body.amount > POLICY.walletMaxBalance
        ) {
          E.fail(409, 'WALLET_LIMIT_EXCEEDED', '지갑 한도 초과', {
            maxBalance: POLICY.walletMaxBalance,
            availableAmount: Math.max(
              0,
              POLICY.walletMaxBalance - wallet.balance - wallet.heldBalance,
            ),
          });
        }
        wallet.balance += body.amount;
        E.ledger(ctx, wallet, 'ADMIN_ADJUST', body.amount);
        if (body.amount > 0) {
          E.autoPayDebts(ctx, user.id);
          E.notify(
            ctx,
            user.id,
            'PAYMENT',
            '지갑에 포인트가 들어왔어요',
            `${body.amount.toLocaleString()}원이 충전됐어요.`,
          );
        }
        return E.toWallet(ctx, user.id);
      }),
    reports: (query = {}) =>
      run('admin.reports', (ctx) => {
        E.requireAdmin(ctx);
        const rows = ctx.db.reports
          .filter(
            (r) =>
              (!query.status || r.status === query.status) &&
              (!query.type || r.type === query.type),
          )
          .sort((a, b) => b.id - a.id)
          .map((r) => toAdminReport(ctx, r));
        return E.paginate(rows, query.page, query.size);
      }),
    processReport: (reportId, body) =>
      run('admin.processReport', (ctx) => {
        E.requireAdmin(ctx);
        const report = ctx.db.reports.find((r) => r.id === reportId) ?? E.fail(404, 'NOT_FOUND');
        if (report.status !== 'PENDING') E.fail(409, 'ALREADY_PROCESSED');
        report.status = body.status;
        report.processedAt = ctx.now;
        if (body.status === 'APPROVED') {
          const reported = E.userById(ctx, report.reportedId)!;
          reported.reportCount += 1;
          reported.cleanStreak = 0;
          if (reported.reportCount >= 10) E.suspend(reported, null, ctx.now);
          else if (reported.reportCount >= 6) E.suspend(reported, ctx.now + 7 * 24 * HOUR, ctx.now);
          else if (reported.reportCount >= 3) E.suspend(reported, ctx.now + 3 * 24 * HOUR, ctx.now);
        }
        const result = body.status === 'APPROVED' ? '승인' : '반려';
        E.notify(
          ctx,
          report.reporterId,
          'REPORT_RESULT',
          `신고가 ${result}됐어요`,
          '접수해 주셔서 감사합니다.',
          report.potId,
        );
        if (body.status === 'APPROVED')
          E.notify(
            ctx,
            report.reportedId,
            'REPORT_RESULT',
            '신고가 접수되어 반영됐어요',
            '누적 신고가 쌓이면 이용이 정지될 수 있어요.',
            report.potId,
          );
        return toAdminReport(ctx, report);
      }),
    pots: (query = {}) =>
      run('admin.pots', (ctx) => {
        E.requireAdmin(ctx);
        const rows = ctx.db.pots
          .filter((p) => !query.status || p.status === query.status)
          .filter((p) => !query.from || toKstDate(new Date(p.departureTime)) >= query.from)
          .filter((p) => !query.to || toKstDate(new Date(p.departureTime)) <= query.to)
          .sort((a, b) => b.departureTime - a.departureTime)
          .map((p) => E.toSummary(ctx, p));
        return E.paginate(rows, query.page, query.size);
      }),
    fareClaims: (query = {}) =>
      run('admin.fareClaims', (ctx) => {
        E.requireAdmin(ctx);
        const status = query.fareClaimStatus ?? 'PENDING';
        const rows = ctx.db.pots
          .filter((p) => p.fareClaimStatus === status)
          .sort((a, b) => (a.fareClaimedAt ?? a.updatedAt) - (b.fareClaimedAt ?? b.updatedAt))
          .map((p) => E.toFareClaim(ctx, p, true));
        return E.paginate(rows, query.page, query.size);
      }),
    reviewFareClaim: (potId, body) =>
      run('admin.reviewFareClaim', (ctx) => {
        E.requireAdmin(ctx);
        const pot = E.potById(ctx, potId);
        if (pot.fareClaimStatus !== 'PENDING') E.fail(409, 'FARE_CLAIM_NOT_PENDING');
        if (pot.status !== 'RUNNING') E.fail(409, 'INVALID_POT_STATUS');
        if (body.decision === 'REJECTED') {
          if (!body.rejectReason?.trim()) E.fail(400, 'REJECT_REASON_REQUIRED');
          Object.assign(pot, {
            fareClaimStatus: 'REJECTED',
            fareRejectReason: body.rejectReason.trim(),
            fareReviewedAt: ctx.now,
            updatedAt: ctx.now,
          });
          E.notify(
            ctx,
            pot.hostId,
            'PAYMENT',
            '정산 청구가 반려됐어요',
            `사유: ${pot.fareRejectReason} · 결제내역을 확인해 다시 청구해 주세요.`,
            pot.id,
          );
          E.touch(ctx, pot.id);
        } else {
          E.settlePot(ctx, pot, pot.actualFare ?? 0);
        }
        return E.toFareClaim(ctx, pot, true);
      }),
    receipt: async (potId) => {
      const stored = await run('admin.receipt', (ctx) => {
        E.requireAdmin(ctx);
        return E.potById(ctx, potId).receiptImage ?? E.fail(404, 'NOT_FOUND');
      });
      return blobFromStored(stored, '결제내역');
    },
    statistics: (query = {}) =>
      run('admin.statistics', (ctx) => {
        E.requireAdmin(ctx);
        const from = query.from ?? toKstDate(new Date(ctx.now - 30 * 24 * HOUR));
        const to = query.to ?? toKstDate(new Date(ctx.now + 24 * HOUR));
        const inRange = ctx.db.pots.filter((p) => {
          const day = toKstDate(new Date(p.departureTime));
          return day >= from && day <= to;
        });
        const counted = inRange.filter((p) => p.status !== 'CANCELED');
        const rank = (key: 'departureName' | 'destinationName') => {
          const counts = new Map<string, number>();
          counted.forEach((p) => counts.set(p[key], (counts.get(p[key]) ?? 0) + 1));
          return [...counts.entries()]
            .map(([name, count]) => ({ name, count }))
            .sort((a, b) => b.count - a.count)
            .slice(0, query.limit ?? 10);
        };
        const hourly = Array.from({ length: 24 }, (_, hour) => ({
          hour,
          potCount: counted.filter((p) => kstHour(new Date(p.departureTime)) === hour).length,
        }));
        return {
          totalPots: inRange.length,
          completedPots: inRange.filter((p) => p.status === 'COMPLETED').length,
          canceledPots: inRange.filter((p) => p.status === 'CANCELED').length,
          topDepartures: rank('departureName'),
          topDestinations: rank('destinationName'),
          hourlyTraffic: hourly,
        };
      }),
  },
};

/* ───────────────────────── 실시간 / 시연 도구 ───────────────────────── */

export const mockRealtime: RealtimeClient = {
  subscribePot(potId, handler) {
    const set = potListeners.get(potId) ?? new Set();
    set.add(handler);
    potListeners.set(potId, set);
    return () => set.delete(handler);
  },
  disconnect() {
    potListeners.clear();
  },
};

export const mockTools = {
  /** 시연용 메일함에서 마지막 인증코드를 꺼냅니다. */
  lastEmailCode(email: string): string | null {
    return inbox.get(email.trim().toLowerCase()) ?? null;
  },
  /** 시연 데이터를 처음 상태로 되돌립니다. */
  reset() {
    db = resetDb();
    inbox.clear();
  },
};
