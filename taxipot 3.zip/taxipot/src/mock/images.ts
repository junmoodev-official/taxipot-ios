/** Mock 서버의 업로드 이미지 보관 (서버 로컬 폴더 저장을 대신해 축소한 data URL 로 보관). */

const MAX_SIDE = 960;

export async function storeImage(file: File): Promise<string> {
  const source = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('이미지를 읽지 못했어요.'));
    reader.readAsDataURL(file);
  });
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = source;
    });
    const scale = Math.min(1, MAX_SIDE / Math.max(image.width, image.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(image.width * scale);
    canvas.height = Math.round(image.height * scale);
    canvas.getContext('2d')?.drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.78);
  } catch {
    return source;
  }
}

function placeholderSvg(label: string): Blob {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="800" viewBox="0 0 600 800">
  <rect width="600" height="800" fill="#F4F6FA"/>
  <rect x="60" y="80" width="480" height="640" rx="24" fill="#fff" stroke="#E3E8F0" stroke-width="4"/>
  <text x="300" y="380" font-family="sans-serif" font-size="34" font-weight="700" fill="#14213D" text-anchor="middle">${label}</text>
  <text x="300" y="430" font-family="sans-serif" font-size="22" fill="#6B7894" text-anchor="middle">시연용 예시 이미지</text>
</svg>`;
  return new Blob([svg], { type: 'image/svg+xml' });
}

export async function blobFromStored(stored: string, label: string): Promise<Blob> {
  if (!stored.startsWith('data:')) return placeholderSvg(label);
  const response = await fetch(stored);
  return response.blob();
}
