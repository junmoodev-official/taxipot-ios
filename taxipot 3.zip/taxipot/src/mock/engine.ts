/**
 * Mock 서버의 업무 규칙.
 * API 명세 3.10.0 '핵심 정책', '포인트 원장 기록 규칙', '서버 배치(스케줄러) 작업'을 그대로 따릅니다.
 */
import { ApiError } from '@/api/errors';
import { tokenStore } from '@/api/tokenStore';
import type * as T from '@/api/types';
import { POLICY, holdAmountOf } from '@/config/policy';
import { distanceMeters } from '@/lib/geo';
import { toKstIso } from '@/lib/time';
import {
  BANKS,
  BOT_POT_TEMPLATES,
  addRecruitingPot,
  nextId,
  type MemberRow,
  type MockDb,
  type PotRow,
  type SettlementRow,
  type UserRow,
  type WalletRow,
} from './db';

const MIN = 60_000;
const HOUR = 60 * MIN;
const DAY = 24 * HOUR;

/* ───────────────────────── 기본 도구 ───────────────────────── */

export function fail(
  status: number,
  code: string,
  message = code,
  detail: Record<string, unknown> | null = null,
): never {
  throw new ApiError(status, { code, message, detail, timestamp: toKstIso(new Date()) });
}

export function iso(ms: number): string;
export function iso(ms: number | null): string | null;
export function iso(ms: number | null): string | null {
  return ms === null ? null : toKstIso(new Date(ms));
}

export function parseTime(value: string, field: string): number {
  if (!/[+-]\d{2}:\d{2}$/.test(value)) {
    fail(400, 'INVALID_DATETIME_FORMAT', '일시 형식 오류', { field, value });
  }
  const ms = Date.parse(value);
  if (Number.isNaN(ms)) fail(400, 'INVALID_DATETIME_FORMAT', '일시 형식 오류', { field, value });
  return ms;
}

export function paginate<Item>(items: Item[], page = 0, size = 20): T.Page<Item> {
  const safeSize = Math.max(1, Math.min(size, 100));
  const start = page * safeSize;
  return {
    content: items.slice(start, start + safeSize),
    page: {
      page,
      size: safeSize,
      totalElements: items.length,
      totalPages: Math.ceil(items.length / safeSize),
    },
  };
}

export function maskAccount(accountNo: string | null): string | null {
  if (!accountNo) return null;
  const digits = accountNo.replace(/\D/g, '');
  return `${digits.slice(0, 3)}-****-${digits.slice(-4)}`;
}

export const bankName = (code: string | null) =>
  BANKS.find((bank) => bank.code === code)?.name ?? null;

/* ───────────────────────── 실행 문맥 ───────────────────────── */

export interface Ctx {
  db: MockDb;
  now: number;
  /** 이번 요청에서 바뀐 방 — STOMP POT_UPDATED 전송 대상 */
  touched: Set<number>;
  chats: T.ChatMessageResponse[];
}

export function touch(ctx: Ctx, potId: number) {
  ctx.touched.add(potId);
}

export function notify(
  ctx: Ctx,
  memberId: number,
  type: T.NotificationType,
  title: string,
  content: string,
  potId: number | null = null,
) {
  ctx.db.notifications.push({
    id: nextId(ctx.db),
    memberId,
    potId,
    type,
    title,
    content,
    isRead: false,
    createdAt: ctx.now,
  });
}

export function notifyAdmins(ctx: Ctx, title: string, content: string, potId: number | null) {
  ctx.db.users
    .filter((u) => u.role === 'ADMIN')
    .forEach((admin) => notify(ctx, admin.id, 'SYSTEM', title, content, potId));
}

/* ───────────────────────── 조회 도구 ───────────────────────── */

export const userById = (ctx: Ctx, id: number) => ctx.db.users.find((u) => u.id === id);
export const walletOf = (ctx: Ctx, memberId: number) =>
  ctx.db.wallets.find((w) => w.memberId === memberId)!;
export const potById = (ctx: Ctx, id: number) =>
  ctx.db.pots.find((p) => p.id === id) ?? fail(404, 'NOT_FOUND', '택시팟을 찾을 수 없습니다.');
export const memberOf = (ctx: Ctx, potId: number, memberId: number) =>
  ctx.db.members.find((m) => m.potId === potId && m.memberId === memberId);
export const settlementOf = (ctx: Ctx, potId: number, memberId: number) =>
  ctx.db.settlements.find((s) => s.potId === potId && s.memberId === memberId);
export const activeMembers = (ctx: Ctx, potId: number) =>
  ctx.db.members.filter(
    (m) => m.potId === potId && (m.status === 'JOINED' || m.status === 'BOARDED'),
  );
export const latestVerification = (ctx: Ctx, memberId: number) =>
  ctx.db.verifications.filter((v) => v.memberId === memberId).sort((a, b) => b.id - a.id)[0];

/* ───────────────────────── 인증 ───────────────────────── */

export function issueTokens(user: UserRow): T.TokenResponse {
  const random = Math.random().toString(36).slice(2, 10);
  return {
    accessToken: `mock.${user.id}.${user.tokenVersion}.${random}`,
    refreshToken: `mock-refresh.${user.id}.${user.tokenVersion}.${random}`,
    tokenType: 'Bearer',
    expiresIn: 3600,
  };
}

export function currentUser(ctx: Ctx): UserRow {
  const token = tokenStore.access;
  const match = token?.match(/^mock\.(\d+)\.(\d+)\./);
  if (!match) fail(401, 'UNAUTHORIZED', '로그인이 필요합니다.');
  const user = userById(ctx, Number(match[1]));
  if (!user || user.status === 'WITHDRAWN' || user.tokenVersion !== Number(match[2])) {
    fail(401, 'TOKEN_REVOKED', '토큰이 무효화되었습니다.');
  }
  return user;
}

export function requireAdmin(ctx: Ctx): UserRow {
  const user = currentUser(ctx);
  if (user.role !== 'ADMIN') fail(403, 'FORBIDDEN', '운영자 전용입니다.');
  return user;
}

/* ───────────────────────── 정지·미수금 ───────────────────────── */

export function isSuspended(user: UserRow, now: number): boolean {
  return user.status === 'SUSPENDED' && (user.suspendedUntil === null || user.suspendedUntil > now);
}

/** 정지 규칙 통일: 기존 정지와 새 정지 중 더 긴 쪽 유지 (until=null 은 영구) */
export function suspend(user: UserRow, until: number | null, now: number) {
  if (user.status === 'SUSPENDED' && user.suspendedUntil === null) return;
  if (until === null) {
    user.suspendedUntil = null;
  } else if (user.status === 'SUSPENDED' && user.suspendedUntil !== null) {
    user.suspendedUntil = Math.max(user.suspendedUntil, until);
  } else {
    user.suspendedUntil = until;
  }
  user.status = 'SUSPENDED';
  user.updatedAt = now;
}

export function openDebts(ctx: Ctx, memberId: number): SettlementRow[] {
  return ctx.db.settlements
    .filter(
      (s) => s.memberId === memberId && (s.debtStatus === 'UNPAID' || s.debtStatus === 'OVERDUE'),
    )
    .sort((a, b) => (a.debtDueAt ?? 0) - (b.debtDueAt ?? 0));
}

export function assertNoDebt(ctx: Ctx, memberId: number) {
  const debts = openDebts(ctx, memberId);
  if (debts.length === 0) return;
  const unpaid = debts.filter((d) => d.debtStatus === 'UNPAID');
  fail(409, 'UNPAID_DEBT_EXISTS', '미수금이 있습니다.', {
    debtAmount: debts.reduce((sum, d) => sum + d.debtAmount, 0),
    debtDueAt: unpaid.length ? iso(unpaid[0].debtDueAt) : null,
  });
}

/* ───────────────────────── 지갑 원장 ───────────────────────── */

export function ledger(
  ctx: Ctx,
  wallet: WalletRow,
  type: T.PointType,
  amount: number,
  refs: { potId?: number | null; withdrawalId?: number | null } = {},
) {
  if (amount === 0) return;
  wallet.updatedAt = ctx.now;
  ctx.db.points.push({
    id: nextId(ctx.db),
    memberId: wallet.memberId,
    potId: refs.potId ?? null,
    paymentId: null,
    withdrawalId: refs.withdrawalId ?? null,
    type,
    amount,
    balanceAfter: wallet.balance,
    createdAt: ctx.now,
  });
}

/** 예치: balance → held_balance, SETTLEMENT HELD, FARE_HOLD 1행 */
export function holdDeposit(ctx: Ctx, pot: PotRow, memberId: number): number {
  const amount = holdAmountOf(pot.expectedFare, pot.maxMembers);
  const wallet = walletOf(ctx, memberId);
  wallet.balance -= amount;
  wallet.heldBalance += amount;
  ledger(ctx, wallet, 'FARE_HOLD', -amount, { potId: pot.id });

  const existing = settlementOf(ctx, pot.id, memberId);
  const row: SettlementRow = existing ?? {
    id: nextId(ctx.db),
    potId: pot.id,
    memberId,
    heldAmount: amount,
    fareShare: null,
    feeAmount: null,
    diffAmount: null,
    uncoveredAmount: 0,
    debtStatus: 'NONE',
    debtAmount: 0,
    debtDueAt: null,
    debtPaidAt: null,
    status: 'HELD',
    settledAt: null,
    createdAt: ctx.now,
  };
  Object.assign(row, {
    heldAmount: amount,
    fareShare: null,
    feeAmount: null,
    diffAmount: null,
    uncoveredAmount: 0,
    debtStatus: 'NONE',
    debtAmount: 0,
    debtDueAt: null,
    status: 'HELD',
    settledAt: null,
  });
  if (!existing) ctx.db.settlements.push(row);
  return amount;
}

/** 환불: 예치금 전액 반환, SETTLEMENT REFUNDED, FARE_REFUND */
export function refundDeposit(ctx: Ctx, potId: number, memberId: number) {
  const settlement = settlementOf(ctx, potId, memberId);
  if (!settlement || settlement.status !== 'HELD') return;
  const wallet = walletOf(ctx, memberId);
  wallet.heldBalance -= settlement.heldAmount;
  wallet.balance += settlement.heldAmount;
  ledger(ctx, wallet, 'FARE_REFUND', settlement.heldAmount, { potId });
  settlement.status = 'REFUNDED';
}

/** 입금(충전·운영자 조정) 직후 미수금 자동 납부 */
export function autoPayDebts(ctx: Ctx, memberId: number) {
  const wallet = walletOf(ctx, memberId);
  for (const debt of openDebts(ctx, memberId)) {
    if (wallet.balance <= 0) break;
    payDebtRow(ctx, wallet, debt);
  }
}

export function payDebtRow(ctx: Ctx, wallet: WalletRow, debt: SettlementRow): number {
  const paid = Math.min(wallet.balance, debt.debtAmount);
  if (paid <= 0) return 0;
  wallet.balance -= paid;
  ledger(ctx, wallet, 'DEBT_PAY', -paid, { potId: debt.potId });
  debt.debtAmount -= paid;
  if (debt.debtAmount === 0) {
    debt.debtStatus = 'PAID';
    debt.debtPaidAt = ctx.now;
    debt.debtDueAt = debt.debtDueAt ?? ctx.now;
  }
  return paid;
}

/* ───────────────────────── 택시팟 규칙 ───────────────────────── */

/** '진행 중인 다른 방' (청구 접수 이후·OVERDUE 방 제외) */
export function activePotOf(ctx: Ctx, memberId: number, exceptPotId?: number): PotRow | undefined {
  return ctx.db.members
    .filter(
      (m) =>
        m.memberId === memberId &&
        m.potId !== exceptPotId &&
        (m.status === 'JOINED' || m.status === 'BOARDED' || m.status === 'REQUESTED'),
    )
    .map((m) => potById(ctx, m.potId))
    .find(
      (p) =>
        p.status === 'RECRUITING' ||
        p.status === 'CLOSED' ||
        (p.status === 'RUNNING' && p.fareClaimStatus === 'NONE'),
    );
}

/** 이용 조건 검증 순서: 학생 인증 → 정지 → 미수금 → 성별 → 진행 중인 다른 방 → 인원 → 잔액 */
export function assertEligible(
  ctx: Ctx,
  user: UserRow,
  options: { genderOption: T.GenderOption; pot?: PotRow; holdAmount: number },
) {
  if (!user.isVerified) {
    const v = latestVerification(ctx, user.id);
    fail(403, 'NOT_VERIFIED', '학생 인증이 필요합니다.', {
      emailStatus: v?.emailStatus ?? null,
      reviewStatus: v?.reviewStatus ?? null,
    });
  }
  if (isSuspended(user, ctx.now)) {
    fail(403, 'SUSPENDED_USER', '이용 정지 중입니다.', {
      suspendedUntil: iso(user.suspendedUntil),
    });
  }
  assertNoDebt(ctx, user.id);
  const genderOk =
    options.genderOption === 'ALL' ||
    (options.genderOption === 'MALE' && user.gender === 'M') ||
    (options.genderOption === 'FEMALE' && user.gender === 'F');
  if (!genderOk) {
    fail(403, 'GENDER_RESTRICTED', '성별 제한 방입니다.', { genderOption: options.genderOption });
  }
  const active = activePotOf(ctx, user.id, options.pot?.id);
  if (active) {
    fail(409, 'ACTIVE_POT_EXISTS', '진행 중인 다른 방이 있습니다.', { activePotId: active.id });
  }
  if (options.pot && options.pot.currentMembers >= options.pot.maxMembers) {
    fail(409, 'POT_FULL', '정원이 찼습니다.', {
      maxMembers: options.pot.maxMembers,
      currentMembers: options.pot.currentMembers,
    });
  }
  const wallet = walletOf(ctx, user.id);
  if (wallet.balance < options.holdAmount) {
    fail(409, 'INSUFFICIENT_BALANCE', '잔액이 부족합니다.', {
      requiredAmount: options.holdAmount,
      balance: wallet.balance,
      shortageAmount: options.holdAmount - wallet.balance,
    });
  }
}

/** 방 전체 취소: 전원 환불 + 대기 요청 취소 + 알림 */
export function cancelPot(ctx: Ctx, pot: PotRow, reason: string) {
  pot.status = 'CANCELED';
  pot.updatedAt = ctx.now;
  ctx.db.members
    .filter((m) => m.potId === pot.id)
    .forEach((m) => {
      if (m.status === 'JOINED' || m.status === 'BOARDED') {
        refundDeposit(ctx, pot.id, m.memberId);
        notify(
          ctx,
          m.memberId,
          'POT',
          '택시팟이 취소됐어요',
          `${pot.title} · ${reason} 예치금은 전액 돌려드렸어요.`,
          pot.id,
        );
      }
      if (m.status === 'REQUESTED') {
        m.status = 'CANCELED';
        m.canceledAt = ctx.now;
        notify(
          ctx,
          m.memberId,
          'POT',
          '입장 요청이 취소됐어요',
          `${pot.title} · ${reason}`,
          pot.id,
        );
      }
    });
  touch(ctx, pot.id);
}

/** 참여자 이탈 공통 처리 (취소·내보내기·노쇼) */
export function removeMember(ctx: Ctx, pot: PotRow, member: MemberRow, status: T.PotMemberStatus) {
  member.status = status;
  member.canceledAt = ctx.now;
  pot.currentMembers -= 1;
  pot.hasCanceled = true;
  if (pot.status === 'CLOSED') pot.status = 'RECRUITING';
  pot.updatedAt = ctx.now;
  refundDeposit(ctx, pot.id, member.memberId);
  touch(ctx, pot.id);
}

export function markNoShow(ctx: Ctx, user: UserRow) {
  user.noShowCount += 1;
  suspend(user, ctx.now + POLICY.noShowSuspendMinutes * MIN, ctx.now);
}

/** 정산 실행 (운영자 청구 승인·일괄 입력 공통) */
export function settlePot(ctx: Ctx, pot: PotRow, actualFare: number) {
  pot.actualFare = actualFare;
  pot.fareClaimStatus = 'APPROVED';
  pot.fareReviewedAt = ctx.now;
  const boarded = ctx.db.members
    .filter((m) => m.potId === pot.id && m.status === 'BOARDED')
    .sort((a, b) => a.memberId - b.memberId);
  const n = Math.max(boarded.length, 1);
  const share = Math.floor(actualFare / n);

  const hostWallet = walletOf(ctx, pot.hostId);
  hostWallet.balance += actualFare;
  ledger(ctx, hostWallet, 'HOST_PAYOUT', actualFare, { potId: pot.id });

  boarded.forEach((member) => {
    const settlement = settlementOf(ctx, pot.id, member.memberId)!;
    const wallet = walletOf(ctx, member.memberId);
    wallet.heldBalance -= settlement.heldAmount;
    wallet.balance += settlement.heldAmount;
    ledger(ctx, wallet, 'FARE_REFUND', settlement.heldAmount, { potId: pot.id });

    const farePaid = Math.min(wallet.balance, share);
    wallet.balance -= farePaid;
    ledger(ctx, wallet, 'FARE_PAY', -farePaid, { potId: pot.id });
    const feePaid = Math.min(wallet.balance, POLICY.feeAmount);
    wallet.balance -= feePaid;
    ledger(ctx, wallet, 'FEE', -feePaid, { potId: pot.id });

    const charged = share + POLICY.feeAmount;
    const uncovered = charged - (farePaid + feePaid);
    Object.assign(settlement, {
      fareShare: share,
      feeAmount: POLICY.feeAmount,
      diffAmount: settlement.heldAmount - charged,
      uncoveredAmount: uncovered,
      status: 'SETTLED',
      settledAt: ctx.now,
    });
    if (uncovered > 0) {
      settlement.debtStatus = 'UNPAID';
      settlement.debtAmount = uncovered;
      settlement.debtDueAt = ctx.now + POLICY.debtDueDays * DAY;
      notify(
        ctx,
        member.memberId,
        'PAYMENT',
        `미수금 ${uncovered.toLocaleString()}원이 생겼어요`,
        '3일 안에 지갑에서 납부해 주세요. 미납 시 이용이 제한돼요.',
        pot.id,
      );
    }

    const user = userById(ctx, member.memberId)!;
    if (user.reportCount >= 1) {
      user.cleanStreak += 1;
      if (user.cleanStreak >= 3) {
        user.reportCount -= 1;
        user.cleanStreak = 0;
      }
    }
    notify(
      ctx,
      member.memberId,
      'PAYMENT',
      '정산이 끝났어요',
      `${pot.title} · 1인 분담금 ${share.toLocaleString()}원 + 수수료 1,000원`,
      pot.id,
    );
    notify(
      ctx,
      member.memberId,
      'RATING_REQUEST',
      '함께 탄 동승자를 평가해 주세요',
      '정산 후 24시간 안에 평가할 수 있어요.',
      pot.id,
    );
  });

  pot.status = 'COMPLETED';
  pot.updatedAt = ctx.now;
  touch(ctx, pot.id);
}

/* ───────────────────────── 스케줄러 (요청마다 + 주기적으로 실행) ───────────────────────── */

export function runSchedulers(ctx: Ctx) {
  const { db, now } = ctx;

  for (const pot of db.pots) {
    if (pot.status !== 'RECRUITING' && pot.status !== 'CLOSED') continue;
    const joined = db.members.filter((m) => m.potId === pot.id && m.status === 'JOINED');

    // 1. 미도착 자동 퇴장 / 방장 미도착 자동 해산
    if (pot.arrivalDeadline <= now && pot.departureTime > now - 30 * MIN) {
      const host = joined.find((m) => m.role === 'HOST');
      if (host && host.arrivedAt === null && pot.currentMembers > 1) {
        host.status = 'NO_SHOW';
        host.canceledAt = now;
        markNoShow(ctx, userById(ctx, host.memberId)!);
        cancelPot(ctx, pot, '방장이 집결 기한까지 도착하지 않았어요.');
        continue;
      }
      joined
        .filter((m) => m.role === 'GUEST' && m.arrivedAt === null)
        .forEach((m) => {
          removeMember(ctx, pot, m, 'NO_SHOW');
          markNoShow(ctx, userById(ctx, m.memberId)!);
          notify(
            ctx,
            m.memberId,
            'KICKED',
            '집결 기한이 지나 퇴장 처리됐어요',
            '예치금은 전액 돌려드렸고 15분 동안 방 생성·참여가 제한돼요.',
            pot.id,
          );
        });
    }

    // 2. 방장 단독 방 자동 해산
    if (pot.departureTime <= now && pot.status === 'RECRUITING' && pot.currentMembers === 1) {
      cancelPot(ctx, pot, '함께 탈 동승자가 없어 자동 해산됐어요.');
      continue;
    }

    // 3. 출발 30분 후 미출발 방 자동 취소
    if (pot.departureTime + 30 * MIN <= now) {
      cancelPot(ctx, pot, '출발 30분이 지나도 탑승 시작이 없어 자동 취소됐어요.');
      continue;
    }

    // 11. 전원 도착 3분 후 출발 확인 알림
    const remaining = db.members.filter((m) => m.potId === pot.id && m.status === 'JOINED');
    if (
      pot.startRemindedAt === null &&
      remaining.length >= 2 &&
      remaining.every((m) => m.arrivedAt !== null) &&
      Math.max(...remaining.map((m) => m.arrivedAt ?? 0)) + 3 * MIN <= now
    ) {
      pot.startRemindedAt = now;
      notify(
        ctx,
        pot.hostId,
        'POT',
        '모두 모였어요',
        '출발했다면 탑승 시작 버튼을 눌러 주세요.',
        pot.id,
      );
    }
  }

  // 5. 정지 만료 해제
  db.users.forEach((user) => {
    if (user.status === 'SUSPENDED' && user.suspendedUntil !== null && user.suspendedUntil <= now) {
      user.status = 'ACTIVE';
      user.suspendedUntil = null;
    }
  });

  // 7. 평가 미제출 기본값
  db.pots
    .filter((p) => p.status === 'COMPLETED' && (p.fareReviewedAt ?? now) + DAY <= now)
    .forEach((pot) => {
      const boarded = db.members.filter((m) => m.potId === pot.id && m.status === 'BOARDED');
      boarded.forEach((reviewer) =>
        boarded
          .filter((reviewee) => reviewee.memberId !== reviewer.memberId)
          .forEach((reviewee) => {
            const exists = db.ratings.some(
              (r) =>
                r.potId === pot.id &&
                r.reviewerId === reviewer.memberId &&
                r.revieweeId === reviewee.memberId,
            );
            if (exists) return;
            db.ratings.push({
              id: nextId(db),
              potId: pot.id,
              reviewerId: reviewer.memberId,
              revieweeId: reviewee.memberId,
              noshowScore: 3,
              mannerScore: 3,
              communicationScore: 3,
              paymentScore: 3,
              badReason: null,
              isDefault: true,
              createdAt: now,
            });
          }),
      );
    });

  // 8. 미수금 연체 표시
  db.settlements
    .filter((s) => s.debtStatus === 'UNPAID' && (s.debtDueAt ?? Infinity) <= now)
    .forEach((s) => {
      s.debtStatus = 'OVERDUE';
      notify(
        ctx,
        s.memberId,
        'PAYMENT',
        '미수금 납부 기한이 지났어요',
        '가입 약관에 따라 법적 조치가 진행될 수 있어요. 지금 납부해 주세요.',
        s.potId,
      );
    });

  // 9. 실요금 청구 기한 경과
  db.pots
    .filter(
      (p) =>
        p.status === 'RUNNING' &&
        p.fareClaimStatus === 'NONE' &&
        (p.startedAt ?? now) + POLICY.fareClaimDeadlineHours * HOUR <= now,
    )
    .forEach((pot) => {
      pot.fareClaimStatus = 'OVERDUE';
      notifyAdmins(ctx, '정산 청구 없음 — 확인 필요', pot.title, pot.id);
      notify(
        ctx,
        pot.hostId,
        'PAYMENT',
        '정산을 청구해 주세요',
        '결제내역을 올려 정산을 청구해 주세요.',
        pot.id,
      );
      touch(ctx, pot.id);
    });

  runBots(ctx);
}

/* ───────────────────────── 시연 동승자(봇) ───────────────────────── */

function runBots(ctx: Ctx) {
  const { db, now } = ctx;
  const bots = db.users.filter((u) => u.isBot);

  // 사용자가 만든 방에 시연 동승자가 참여하고, 잠시 뒤 도착 확인합니다.
  db.pots
    .filter(
      (p) =>
        p.botJoinAt && p.botJoinAt <= now && p.status === 'RECRUITING' && p.arrivalDeadline > now,
    )
    .forEach((pot) => {
      pot.botJoinAt = null;
      const bot = bots.find(
        (b) =>
          !activePotOf(ctx, b.id) &&
          !memberOf(ctx, pot.id, b.id) &&
          (pot.genderOption === 'ALL' || (pot.genderOption === 'MALE') === (b.gender === 'M')),
      );
      if (!bot || walletOf(ctx, bot.id).balance < holdAmountOf(pot.expectedFare, pot.maxMembers))
        return;
      db.members.push({
        id: nextId(db),
        potId: pot.id,
        memberId: bot.id,
        role: 'GUEST',
        preferredSeat: 'BACK_RIGHT',
        status: 'JOINED',
        arrivedAt: now + 20_000,
        joinedAt: now,
        canceledAt: null,
      });
      pot.currentMembers += 1;
      if (pot.currentMembers >= pot.maxMembers) pot.status = 'CLOSED';
      holdDeposit(ctx, pot, bot.id);
      notify(
        ctx,
        pot.hostId,
        'POT',
        '새 동승자가 참여했어요',
        `${bot.nickname}님이 ${pot.title}에 참여했어요.`,
        pot.id,
      );
      const message = {
        id: nextId(db),
        potId: pot.id,
        senderId: bot.id,
        msgType: 'TEXT' as const,
        content: '안녕하세요! 출발지에서 봬요 🙂',
        sentAt: now,
      };
      db.messages.push(message);
      ctx.chats.push({ ...toChat(ctx, message) });
      touch(ctx, pot.id);
    });

  // 봇의 예약 도착 시각(미래 값)이 지나면 실제 도착으로 확정
  db.members
    .filter((m) => m.arrivedAt !== null && m.arrivedAt > now && m.status === 'JOINED')
    .forEach((m) => {
      if (m.arrivedAt! - now > 60_000) m.arrivedAt = now;
    });

  // 모집 중인 시연 방이 부족하면 새로 만듭니다.
  const upcoming = db.pots.filter(
    (p) =>
      p.status === 'RECRUITING' &&
      p.departureTime > now + 20 * MIN &&
      bots.some((b) => b.id === p.hostId),
  );
  if (upcoming.length < 3) {
    BOT_POT_TEMPLATES.slice(0, 4 - upcoming.length).forEach((template, index) => {
      const host = bots.find(
        (b) => !activePotOf(ctx, b.id) && (template.genderOption !== 'FEMALE' || b.gender === 'F'),
      );
      if (!host || walletOf(ctx, host.id).balance < 20_000) return;
      addRecruitingPot(db, { ...template, host, minutes: template.minutes + index * 15 });
    });
  }
}

/* ───────────────────────── 응답 변환 ───────────────────────── */

export function nextSuspensionIn(reportCount: number): number | null {
  const next = [3, 6, 10].find((threshold) => threshold > reportCount);
  return next === undefined ? null : next - reportCount;
}

export function toProfile(user: UserRow): T.MyProfileResponse {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    nickname: user.nickname,
    phone: user.phone,
    gender: user.gender,
    university: user.university,
    studentNo: user.studentNo,
    isVerified: user.isVerified,
    ratingAvg: user.ratingAvg,
    noShowCount: user.noShowCount,
    reportCount: user.reportCount,
    cleanStreak: user.cleanStreak,
    role: user.role,
    status: user.status,
    suspendedUntil: iso(user.suspendedUntil),
    agreeMarketing: user.agreeMarketing,
    createdAt: iso(user.createdAt),
    updatedAt: iso(user.updatedAt),
    nextSuspensionIn:
      user.status === 'SUSPENDED' && user.suspendedUntil === null
        ? null
        : nextSuspensionIn(user.reportCount),
  };
}

export function toWallet(ctx: Ctx, memberId: number): T.WalletResponse {
  const wallet = walletOf(ctx, memberId);
  return {
    id: wallet.id,
    memberId,
    balance: wallet.balance,
    heldBalance: wallet.heldBalance,
    debtAmount: openDebts(ctx, memberId).reduce((sum, d) => sum + d.debtAmount, 0),
    updatedAt: iso(wallet.updatedAt),
  };
}

export function toMember(ctx: Ctx, m: MemberRow): T.PotMemberResponse {
  const user = userById(ctx, m.memberId)!;
  return {
    id: m.id,
    memberId: m.memberId,
    nickname: user.nickname,
    ratingAvg: user.ratingAvg,
    role: m.role,
    preferredSeat: m.preferredSeat,
    status: m.status,
    arrivedAt: m.arrivedAt !== null && m.arrivedAt <= ctx.now ? iso(m.arrivedAt) : null,
    joinedAt: iso(m.joinedAt),
    canceledAt: iso(m.canceledAt),
  };
}

export function toSummary(
  ctx: Ctx,
  pot: PotRow,
  distance: number | null = null,
): T.PotSummaryResponse {
  const host = userById(ctx, pot.hostId)!;
  return {
    id: pot.id,
    title: pot.title,
    hostId: pot.hostId,
    hostNickname: host.nickname,
    hostRatingAvg: host.ratingAvg,
    departureName: pot.departureName,
    departureLat: pot.departureLat,
    departureLng: pot.departureLng,
    destinationName: pot.destinationName,
    departureTime: iso(pot.departureTime),
    maxMembers: pot.maxMembers,
    currentMembers: pot.currentMembers,
    genderOption: pot.genderOption,
    expectedFare: pot.expectedFare,
    holdAmount: holdAmountOf(pot.expectedFare, pot.maxMembers),
    joinDeadline: iso(pot.arrivalDeadline),
    status: pot.status,
    hasCanceled: pot.hasCanceled,
    createdAt: iso(pot.createdAt),
    distanceMeters: distance === null ? null : Math.round(distance),
  };
}

export function toDetail(ctx: Ctx, pot: PotRow, viewerId: number): T.PotDetailResponse {
  const host = userById(ctx, pot.hostId)!;
  const mine = memberOf(ctx, pot.id, viewerId);
  const isJoined = mine?.status === 'JOINED' || mine?.status === 'BOARDED';
  return {
    id: pot.id,
    title: pot.title,
    hostId: pot.hostId,
    hostNickname: host.nickname,
    hostRatingAvg: host.ratingAvg,
    departureName: pot.departureName,
    departureLat: pot.departureLat,
    departureLng: pot.departureLng,
    destinationName: pot.destinationName,
    destinationLat: pot.destinationLat,
    destinationLng: pot.destinationLng,
    departureTime: iso(pot.departureTime),
    arrivalDeadline: iso(pot.arrivalDeadline),
    cancelDeadline: iso(pot.departureTime - POLICY.cancelDeadlineMinutes * MIN),
    maxMembers: pot.maxMembers,
    currentMembers: pot.currentMembers,
    genderOption: pot.genderOption,
    expectedFare: pot.expectedFare,
    holdAmount: holdAmountOf(pot.expectedFare, pot.maxMembers),
    actualFare: pot.actualFare,
    status: pot.status,
    hasCanceled: pot.hasCanceled,
    openChatUrl: isJoined ? pot.openChatUrl : null,
    isJoined,
    myMemberStatus: mine?.status ?? null,
    hasReceipt: pot.receiptImage !== null,
    fareClaimStatus: pot.fareClaimStatus,
    fareRejectReason: pot.fareRejectReason,
    members: activeMembers(ctx, pot.id)
      .sort((a, b) => (a.role === 'HOST' ? -1 : b.role === 'HOST' ? 1 : a.joinedAt - b.joinedAt))
      .map((m) => toMember(ctx, m)),
    createdAt: iso(pot.createdAt),
    updatedAt: iso(pot.updatedAt),
  };
}

export function toSettlement(ctx: Ctx, s: SettlementRow): T.SettlementResponse {
  return {
    id: s.id,
    potId: s.potId,
    memberId: s.memberId,
    nickname: userById(ctx, s.memberId)!.nickname,
    heldAmount: s.heldAmount,
    fareShare: s.fareShare,
    feeAmount: s.feeAmount,
    diffAmount: s.diffAmount,
    uncoveredAmount: s.uncoveredAmount,
    debtStatus: s.debtStatus,
    debtAmount: s.debtAmount,
    debtDueAt: iso(s.debtDueAt),
    status: s.status,
    settledAt: iso(s.settledAt),
    createdAt: iso(s.createdAt),
  };
}

export function toHistory(ctx: Ctx, m: MemberRow): T.MyPotHistoryResponse | null {
  const pot = potById(ctx, m.potId);
  const s = settlementOf(ctx, m.potId, m.memberId);
  if (!s || m.status === 'REQUESTED' || m.status === 'REJECTED') return null;
  return {
    potId: pot.id,
    title: pot.title,
    departureName: pot.departureName,
    destinationName: pot.destinationName,
    departureTime: iso(pot.departureTime),
    potStatus: pot.status,
    actualFare: pot.actualFare,
    myRole: m.role,
    myStatus: m.status,
    heldAmount: s.heldAmount,
    fareShare: s.fareShare,
    feeAmount: s.feeAmount,
    diffAmount: s.diffAmount,
    uncoveredAmount: s.uncoveredAmount,
    debtStatus: s.debtStatus,
    debtAmount: s.debtAmount,
    settlementStatus: s.status,
    isRated:
      pot.status === 'COMPLETED' &&
      ctx.db.members
        .filter((x) => x.potId === pot.id && x.status === 'BOARDED' && x.memberId !== m.memberId)
        .every((x) =>
          ctx.db.ratings.some(
            (r) => r.potId === pot.id && r.reviewerId === m.memberId && r.revieweeId === x.memberId,
          ),
        ),
  };
}

export function toChat(
  ctx: Ctx,
  m: {
    id: number;
    potId: number;
    senderId: number;
    msgType: T.MsgType;
    content: string;
    sentAt: number;
  },
): T.ChatMessageResponse {
  return {
    id: m.id,
    potId: m.potId,
    senderId: m.senderId,
    senderNickname: userById(ctx, m.senderId)?.nickname ?? '알 수 없음',
    msgType: m.msgType,
    content: m.content,
    sentAt: iso(m.sentAt),
  };
}

export function toFareClaim(ctx: Ctx, pot: PotRow, admin = false): T.FareClaimResponse {
  return {
    potId: pot.id,
    title: pot.title,
    hostId: pot.hostId,
    hostNickname: userById(ctx, pot.hostId)!.nickname,
    potStatus: pot.status,
    fareClaimStatus: pot.fareClaimStatus,
    expectedFare: pot.expectedFare,
    actualFare: pot.actualFare,
    fareRatio:
      pot.actualFare !== null && pot.expectedFare > 0
        ? Math.round((pot.actualFare / pot.expectedFare) * 100) / 100
        : null,
    boardedCount: ctx.db.members.filter((m) => m.potId === pot.id && m.status === 'BOARDED').length,
    receiptUrl: pot.receiptImage
      ? admin
        ? `/api/admin/pots/${pot.id}/receipt`
        : `/api/pots/${pot.id}/receipt`
      : null,
    startedAt: iso(pot.startedAt),
    claimDeadline:
      pot.startedAt === null ? null : iso(pot.startedAt + POLICY.fareClaimDeadlineHours * HOUR),
    fareClaimedAt: iso(pot.fareClaimedAt),
    fareReviewedAt: iso(pot.fareReviewedAt),
    fareRejectReason: pot.fareRejectReason,
  };
}

export function toAdminUser(user: UserRow): T.AdminUserResponse {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    nickname: user.nickname,
    university: user.university,
    studentNo: user.studentNo,
    isVerified: user.isVerified,
    ratingAvg: user.ratingAvg,
    noShowCount: user.noShowCount,
    reportCount: user.reportCount,
    role: user.role,
    status: user.status,
    suspendedUntil: iso(user.suspendedUntil),
    withdrawnAt: iso(user.withdrawnAt),
    createdAt: iso(user.createdAt),
  };
}

export function withinArrivalRange(pot: PotRow, lat: number, lng: number) {
  const meters = distanceMeters({ lat, lng }, { lat: pot.departureLat, lng: pot.departureLng });
  if (meters > POLICY.arrivalRadiusMeters) {
    fail(400, 'OUT_OF_ARRIVAL_RANGE', '도착 인정 반경 밖입니다.', {
      distanceMeters: Math.round(meters),
      allowedRadiusMeters: POLICY.arrivalRadiusMeters,
    });
  }
  return Math.round(meters);
}
