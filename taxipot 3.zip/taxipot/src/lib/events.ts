/** 화면 밖(API 계층)에서 발생한 사건을 UI 로 알리는 작은 이벤트 버스. */

export interface AppEvents {
  /** 토큰 무효(TOKEN_REVOKED)·재발급 실패 → 로그인 화면으로 */
  'session-expired': { message: string };
  /** 409 UNPAID_DEBT_EXISTS → 미수금 화면으로 */
  'unpaid-debt': { debtAmount?: number };
  /** 지갑 잔액이 바뀌었을 수 있는 작업 이후 */
  'wallet-changed': undefined;
}

type Handler<T> = (payload: T) => void;

const handlers = new Map<keyof AppEvents, Set<Handler<never>>>();

export const appEvents = {
  on<K extends keyof AppEvents>(event: K, handler: Handler<AppEvents[K]>): () => void {
    const set = handlers.get(event) ?? new Set<Handler<never>>();
    set.add(handler as Handler<never>);
    handlers.set(event, set);
    return () => {
      set.delete(handler as Handler<never>);
    };
  },
  emit<K extends keyof AppEvents>(event: K, payload: AppEvents[K]): void {
    handlers.get(event)?.forEach((handler) => (handler as Handler<AppEvents[K]>)(payload));
  },
};
