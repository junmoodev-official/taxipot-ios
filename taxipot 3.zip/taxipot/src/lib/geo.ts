/** 좌표 계산과 기본 장소 목록 (카카오맵 키가 없을 때 사용). */

export interface LatLng {
  lat: number;
  lng: number;
}

export interface Place extends LatLng {
  name: string;
  address?: string;
}

/** 하버사인 공식 거리(m) — 서버의 도착 인정 판정과 같은 공식 */
export function distanceMeters(a: LatLng, b: LatLng): number {
  const rad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const h =
    Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 6_371_000 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

/** 기준 좌표에서 동서남북으로 몇 m 떨어진 좌표 (시연용 위치 보정) */
export function offsetMeters(origin: LatLng, northMeters: number, eastMeters: number): LatLng {
  const dLat = northMeters / 111_320;
  const dLng = eastMeters / (111_320 * Math.cos((origin.lat * Math.PI) / 180));
  return { lat: origin.lat + dLat, lng: origin.lng + dLng };
}

/**
 * 천안·아산 캠퍼스 주변 기본 장소.
 * 카카오맵 키가 설정되면 장소 검색 결과를 대신 사용합니다.
 */
export const PLACE_PRESETS: Place[] = [
  { name: '백석대학교 정문', lat: 36.8408, lng: 127.1837, address: '충남 천안시 동남구 문암로 76' },
  { name: '백석대학교 본부동', lat: 36.8392, lng: 127.1828 },
  { name: '단국대학교 천안캠퍼스', lat: 36.8335, lng: 127.1704 },
  { name: '상명대학교 천안캠퍼스', lat: 36.8338, lng: 127.1792 },
  { name: '호서대학교 아산캠퍼스', lat: 36.7369, lng: 127.0749 },
  { name: '한국기술교육대학교', lat: 36.7637, lng: 127.2819 },
  { name: '천안아산역 (KTX)', lat: 36.7945, lng: 127.1046 },
  { name: '천안역', lat: 36.8102, lng: 127.1465 },
  { name: '천안종합버스터미널', lat: 36.8196, lng: 127.1563 },
  { name: '두정역', lat: 36.8337, lng: 127.1493 },
  { name: '불당동 카페거리', lat: 36.8067, lng: 127.1095 },
  { name: '신세계백화점 천안아산점', lat: 36.8191, lng: 127.1555 },
  { name: '독립기념관', lat: 36.7839, lng: 127.2247 },
];

export const DEFAULT_CENTER: LatLng = { lat: 36.8205, lng: 127.1515 };

export function searchPresets(keyword: string): Place[] {
  const needle = keyword.replace(/\s+/g, '').toLowerCase();
  if (!needle) return PLACE_PRESETS;
  return PLACE_PRESETS.filter((place) =>
    place.name.replace(/\s+/g, '').toLowerCase().includes(needle),
  );
}

/**
 * 외부 택시 앱 딥링크 (명세: 상세 응답의 이름·좌표로 앱에서 생성).
 * - 카카오 T: 앱 스킴. 설치되지 않은 기기에서는 동작하지 않습니다.
 * - Uber: 유니버설 링크 (앱이 없으면 모바일 웹으로 열림).
 */
export function kakaoTaxiLink(origin: LatLng, dest: LatLng): string {
  const q = new URLSearchParams({
    origin_lat: String(origin.lat),
    origin_lng: String(origin.lng),
    dest_lat: String(dest.lat),
    dest_lng: String(dest.lng),
  });
  return `kakaot://taxi?${q.toString()}`;
}

export function uberLink(origin: Place, dest: Place): string {
  const q = new URLSearchParams({
    action: 'setPickup',
    'pickup[latitude]': String(origin.lat),
    'pickup[longitude]': String(origin.lng),
    'pickup[nickname]': origin.name,
    'dropoff[latitude]': String(dest.lat),
    'dropoff[longitude]': String(dest.lng),
    'dropoff[nickname]': dest.name,
  });
  return `https://m.uber.com/ul/?${q.toString()}`;
}
