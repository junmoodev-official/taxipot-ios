/**
 * 코드값 → 화면 표시 문구.
 * 명세 '코드값 확장 정책': 모르는 코드값은 '기타'로 표시합니다.
 */
import type {
  DebtStatus,
  FareClaimStatus,
  GenderOption,
  NotificationType,
  PointType,
  PotMemberStatus,
  PotStatus,
  PreferredSeat,
  ReportStatus,
  ReportType,
  ReviewStatus,
  SettlementStatus,
  UserStatus,
  WithdrawalStatus,
} from '@/api/types';

const UNKNOWN = '기타';

function lookup<K extends string>(table: Record<K, string>) {
  return (code: K | string | null | undefined): string =>
    code && code in table ? table[code as K] : UNKNOWN;
}

export const potStatusLabel = lookup<PotStatus>({
  RECRUITING: '모집 중',
  CLOSED: '모집 완료',
  RUNNING: '이동 중',
  COMPLETED: '정산 완료',
  CANCELED: '취소됨',
});

export const memberStatusLabel = lookup<PotMemberStatus>({
  JOINED: '참여 중',
  CANCELED: '참여 취소',
  BOARDED: '탑승',
  NO_SHOW: '미도착 퇴장',
  KICKED: '내보내짐',
  REQUESTED: '입장 요청 중',
  REJECTED: '입장 거절',
});

export const seatLabel = lookup<PreferredSeat>({
  FRONT: '조수석',
  BACK_LEFT: '뒷좌석 왼쪽',
  BACK_MID: '뒷좌석 가운데',
  BACK_RIGHT: '뒷좌석 오른쪽',
  NONE: '상관없음',
});

export const genderOptionLabel = lookup<GenderOption>({
  ALL: '누구나',
  MALE: '남성만',
  FEMALE: '여성만',
});

export const pointTypeLabel = lookup<PointType>({
  CHARGE: '충전',
  CHARGE_REFUND: '충전 환불',
  ADMIN_ADJUST: '운영자 조정',
  FARE_HOLD: '예치',
  FARE_REFUND: '예치 해제',
  FARE_ADJUST: '추가 차감',
  FARE_PAY: '택시비 분담',
  FEE: '서비스 수수료',
  HOST_PAYOUT: '방장 정산금',
  DEBT_PAY: '미수금 납부',
  BALANCE_EXPIRE: '잔액 소멸',
  WITHDRAW: '출금',
  WITHDRAW_REFUND: '출금 실패 복구',
});

export const fareClaimLabel = lookup<FareClaimStatus>({
  NONE: '청구 전',
  PENDING: '운영자 확인 중',
  APPROVED: '승인',
  REJECTED: '반려',
  OVERDUE: '청구 기한 지남',
});

export const settlementStatusLabel = lookup<SettlementStatus>({
  HELD: '예치 중',
  SETTLED: '정산 완료',
  REFUNDED: '환불',
});

export const debtStatusLabel = lookup<DebtStatus>({
  NONE: '없음',
  UNPAID: '미납',
  OVERDUE: '기한 지남',
  PAID: '납부 완료',
});

export const withdrawalStatusLabel = lookup<WithdrawalStatus>({
  REQUESTED: '처리 중',
  COMPLETED: '입금 완료',
  FAILED: '실패',
});

export const reportTypeLabel = lookup<ReportType>({
  NO_SHOW: '노쇼',
  ABUSIVE: '불쾌한 언행',
  ETC: '기타',
});

export const reportStatusLabel = lookup<ReportStatus>({
  PENDING: '검토 중',
  APPROVED: '승인',
  REJECTED: '반려',
});

export const reviewStatusLabel = lookup<ReviewStatus>({
  NOT_SUBMITTED: '캡처 미제출',
  PENDING: '심사 대기',
  APPROVED: '승인',
  REJECTED: '반려',
});

export const userStatusLabel = lookup<UserStatus>({
  ACTIVE: '정상',
  SUSPENDED: '이용 정지',
  WITHDRAWN: '탈퇴',
});

export const notificationTypeLabel = lookup<NotificationType>({
  POT: '택시팟',
  PAYMENT: '지갑',
  LATE_WARNING: '지각 경고',
  KICKED: '퇴장',
  RATING_REQUEST: '평가 요청',
  REPORT_RESULT: '신고 결과',
  SYSTEM: '안내',
});

export const SEATS: PreferredSeat[] = ['NONE', 'FRONT', 'BACK_LEFT', 'BACK_MID', 'BACK_RIGHT'];
