/**
 * KST(UTC+09:00) 일시 유틸.
 * 명세: Request·Response 모두 ISO-8601 + `+09:00` 오프셋 필수, `Z` 표기 금지.
 */

const KST_OFFSET_MS = 9 * 60 * 60 * 1000;
const pad = (n: number) => String(n).padStart(2, '0');

/** Date → `2026-10-16T23:30:00+09:00` */
export function toKstIso(date: Date): string {
  const k = new Date(date.getTime() + KST_OFFSET_MS);
  return (
    `${k.getUTCFullYear()}-${pad(k.getUTCMonth() + 1)}-${pad(k.getUTCDate())}` +
    `T${pad(k.getUTCHours())}:${pad(k.getUTCMinutes())}:${pad(k.getUTCSeconds())}+09:00`
  );
}

/** Date → `<input type="datetime-local">` 값 (KST 기준) */
export function toKstLocalInput(date: Date): string {
  return toKstIso(date).slice(0, 16);
}

/** `<input type="datetime-local">` 값(KST) → Date */
export function fromKstLocalInput(value: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)) return null;
  const date = new Date(`${value}:00+09:00`);
  return Number.isNaN(date.getTime()) ? null : date;
}

/** KST 날짜 문자열 `YYYY-MM-DD` */
export function toKstDate(date: Date): string {
  return toKstIso(date).slice(0, 10);
}

/** KST 기준 시(0~23) */
export function kstHour(date: Date): number {
  return new Date(date.getTime() + KST_OFFSET_MS).getUTCHours();
}

export function parseIso(iso: string | null | undefined): Date | null {
  if (!iso) return null;
  const date = new Date(iso);
  return Number.isNaN(date.getTime()) ? null : date;
}

export const addMinutes = (date: Date, minutes: number) =>
  new Date(date.getTime() + minutes * 60_000);

export const addHours = (date: Date, hours: number) => addMinutes(date, hours * 60);

export const addDays = (date: Date, days: number) => addHours(date, days * 24);

/**
 * 서버 시각 보정.
 * 명세: 참여 마감 비교는 응답 헤더 `Date`(서버 시각) 기준 — 폰 시계 오차 대비.
 */
let serverOffsetMs = 0;

export const serverClock = {
  sync(dateHeader: string | null) {
    if (!dateHeader) return;
    const server = Date.parse(dateHeader);
    // Date 헤더는 초 단위라 1초 미만 차이는 무시합니다.
    if (!Number.isNaN(server) && Math.abs(server - Date.now()) > 1500) {
      serverOffsetMs = server - Date.now();
    }
  },
  now(): Date {
    return new Date(Date.now() + serverOffsetMs);
  },
  isPast(iso: string | null | undefined): boolean {
    const date = parseIso(iso);
    return date ? date.getTime() <= this.now().getTime() : false;
  },
};
