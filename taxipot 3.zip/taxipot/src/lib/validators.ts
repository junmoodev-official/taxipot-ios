/** 입력 형식 사전 검증 (명세 Request 스키마 제약과 동일). 실패 시 안내 문구, 통과 시 null. */
import { POLICY } from '@/config/policy';

export const PHONE_PATTERN = /^01[016789]-?[0-9]{3,4}-?[0-9]{4}$/;

export function digitsOnly(value: string): string {
  return value.replace(/\D/g, '');
}

export function validateEmail(value: string): string | null {
  const email = value.trim();
  if (!email) return '이메일을 입력해 주세요.';
  if (email.length > 100 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return '이메일 형식을 확인해 주세요.';
  }
  return null;
}

export function validateSchoolEmail(value: string, domain: string | undefined): string | null {
  const basic = validateEmail(value);
  if (basic) return basic;
  if (!domain) return '학교를 먼저 선택해 주세요.';
  const [, host = ''] = value.trim().toLowerCase().split('@');
  return host === domain ? null : `학교 이메일(@${domain})만 사용할 수 있어요.`;
}

export function validatePassword(value: string): string | null {
  if (value.length < 8) return '비밀번호는 8자 이상이어야 해요.';
  if (!/[A-Za-z]/.test(value) || !/\d/.test(value)) return '영문과 숫자를 함께 사용해 주세요.';
  return null;
}

export function validateNickname(value: string): string | null {
  const nickname = value.trim();
  if (nickname.length < 2 || nickname.length > 30) return '닉네임은 2~30자로 입력해 주세요.';
  if (nickname.startsWith(POLICY.reservedNicknamePrefix))
    return '이후 사용할 수 없는 닉네임입니다.';
  return null;
}

export function validateName(value: string): string | null {
  const name = value.trim();
  return name.length >= 2 && name.length <= 50 ? null : '이름을 2~50자로 입력해 주세요.';
}

export function validatePhone(value: string): string | null {
  return PHONE_PATTERN.test(value.trim())
    ? null
    : '휴대폰 번호 형식을 확인해 주세요. (예: 010-1234-5678)';
}

export function validateStudentNo(value: string): string | null {
  const studentNo = value.trim();
  return studentNo.length >= 4 && studentNo.length <= 20 ? null : '학번을 정확히 입력해 주세요.';
}

export function validateAccountNumber(value: string): string | null {
  const digits = digitsOnly(value);
  return digits.length >= 10 && digits.length <= 14 ? null : '계좌번호는 숫자 10~14자리예요.';
}

export function validateOpenChatUrl(value: string): string | null {
  const url = value.trim();
  if (!url) return null;
  if (url.length > 500) return '링크가 너무 길어요.';
  return /^https:\/\/open\.kakao\.com\//.test(url)
    ? null
    : '카카오톡 오픈채팅 링크(https://open.kakao.com/...)만 입력할 수 있어요.';
}

export function validateImage(file: File | null): string | null {
  if (!file) return '사진을 선택해 주세요.';
  if (!['image/jpeg', 'image/png'].includes(file.type))
    return 'jpg 또는 png 사진만 올릴 수 있어요.';
  if (file.size > POLICY.maxUploadBytes) return '사진은 10MB 이하만 올릴 수 있어요.';
  return null;
}
