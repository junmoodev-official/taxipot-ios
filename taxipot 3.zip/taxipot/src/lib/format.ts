import { parseIso, serverClock } from './time';

const TZ = 'Asia/Seoul';

const timeFormatter = new Intl.DateTimeFormat('ko-KR', {
  timeZone: TZ,
  hour: '2-digit',
  minute: '2-digit',
  hour12: false,
});

const dateFormatter = new Intl.DateTimeFormat('ko-KR', {
  timeZone: TZ,
  month: 'long',
  day: 'numeric',
  weekday: 'short',
});

const fullFormatter = new Intl.DateTimeFormat('ko-KR', {
  timeZone: TZ,
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  hour12: false,
});

const dayKey = new Intl.DateTimeFormat('en-CA', { timeZone: TZ });

/** 12,300원 */
export function won(amount: number | null | undefined): string {
  if (amount === null || amount === undefined) return '-';
  return `${Math.round(amount).toLocaleString('ko-KR')}원`;
}

/** +12,300원 / −1,000원 (원장 금액 표시) */
export function signedWon(amount: number): string {
  const sign = amount > 0 ? '+' : amount < 0 ? '−' : '';
  return `${sign}${Math.abs(amount).toLocaleString('ko-KR')}원`;
}

/** 23:30 */
export function clock(iso: string | null | undefined): string {
  const date = parseIso(iso);
  return date ? timeFormatter.format(date) : '-';
}

/** 오늘 23:30 / 내일 08:10 / 10월 18일 (토) 09:00 */
export function dayAndTime(iso: string | null | undefined): string {
  const date = parseIso(iso);
  if (!date) return '-';
  const now = serverClock.now();
  const tomorrow = new Date(now.getTime() + 86_400_000);
  const key = dayKey.format(date);
  let label = dateFormatter.format(date);
  if (key === dayKey.format(now)) label = '오늘';
  else if (key === dayKey.format(tomorrow)) label = '내일';
  return `${label} ${timeFormatter.format(date)}`;
}

/** 2026. 10. 16. 23:30 */
export function fullDateTime(iso: string | null | undefined): string {
  const date = parseIso(iso);
  return date ? fullFormatter.format(date) : '-';
}

/** 방금 / 3분 전 / 2시간 전 / 10월 16일 (금) */
export function relativeTime(iso: string | null | undefined): string {
  const date = parseIso(iso);
  if (!date) return '-';
  const diff = (serverClock.now().getTime() - date.getTime()) / 1000;
  if (diff < 60) return '방금';
  if (diff < 3600) return `${Math.floor(diff / 60)}분 전`;
  if (diff < 86_400) return `${Math.floor(diff / 3600)}시간 전`;
  return dateFormatter.format(date);
}

/** 남은 시간 "12분 30초" / "1시간 5분" (지났으면 null) */
export function remaining(iso: string | null | undefined): string | null {
  const date = parseIso(iso);
  if (!date) return null;
  const seconds = Math.floor((date.getTime() - serverClock.now().getTime()) / 1000);
  if (seconds <= 0) return null;
  if (seconds < 60) return `${seconds}초`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}분 ${seconds % 60}초`;
  return `${Math.floor(minutes / 60)}시간 ${minutes % 60}분`;
}

/** 450m / 1.2km */
export function distance(meters: number | null | undefined): string {
  if (meters === null || meters === undefined) return '';
  return meters < 1000 ? `${Math.round(meters)}m` : `${(meters / 1000).toFixed(1)}km`;
}

/** 평점 7.40 → "7.4" */
export function rating(value: number): string {
  return value.toFixed(1);
}

/** 01012345678 → 010-1234-5678 */
export function phone(value: string): string {
  const digits = value.replace(/\D/g, '');
  if (digits.length === 11) return `${digits.slice(0, 3)}-${digits.slice(3, 7)}-${digits.slice(7)}`;
  if (digits.length === 10) return `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
  return value;
}

export function initial(name: string): string {
  return name.trim().slice(0, 1) || '?';
}
