/**
 * 화면 틀.
 * - 휴대폰·태블릿(폭 960px 미만): 앱을 전체 화면으로 표시 (실제 서비스 형태)
 * - 데스크톱: 서비스 소개 + iPhone 프레임 안에 앱을 표시 (발표·시연용)
 */
import { BatteryFull, Signal, Wifi } from 'lucide-react';
import { useEffect, useState, type ReactNode } from 'react';
import { env } from '@/config/env';
import { Brand } from './Brand';

function useIsDesktop() {
  const query = '(min-width: 960px)';
  const [desktop, setDesktop] = useState(() => window.matchMedia(query).matches);
  useEffect(() => {
    const media = window.matchMedia(query);
    const handler = () => setDesktop(media.matches);
    media.addEventListener('change', handler);
    return () => media.removeEventListener('change', handler);
  }, []);
  return desktop;
}

function StatusBar() {
  const [time, setTime] = useState(() =>
    new Date().toLocaleTimeString('ko-KR', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
      timeZone: 'Asia/Seoul',
    }),
  );
  useEffect(() => {
    const timer = window.setInterval(
      () =>
        setTime(
          new Date().toLocaleTimeString('ko-KR', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: false,
            timeZone: 'Asia/Seoul',
          }),
        ),
      20_000,
    );
    return () => window.clearInterval(timer);
  }, []);
  return (
    <div className="status-bar" aria-hidden="true">
      <span>{time}</span>
      <span className="status-bar__island" />
      <span className="status-bar__icons">
        <Signal size={13} />
        <Wifi size={14} />
        <BatteryFull size={18} />
      </span>
    </div>
  );
}

export function DeviceFrame({ children }: { children: ReactNode }) {
  const desktop = useIsDesktop();

  if (!desktop) {
    return (
      <div className="app-root">
        <div className="phone-screen phone-screen--native">
          {children}
          <div id="phone-overlay" />
        </div>
      </div>
    );
  }

  return (
    <div className="showcase">
      <aside className="showcase__intro">
        <Brand size="lg" />
        <h1>
          같은 방향이면
          <br />
          같이 타요.
        </h1>
        <p>
          출발지와 시간이 비슷한 학생끼리 택시를 나눠 타고,
          <br />
          요금은 지갑 예치금으로 자동 정산해요.
        </p>
        <ol className="showcase__steps">
          <li>
            <strong>모이기</strong>
            <span>학교 이메일과 학생증 캡처로 인증한 학생만 참여해요.</span>
          </li>
          <li>
            <strong>도착 확인</strong>
            <span>출발 5분 전까지 출발지 50m 안에서 도착을 확인해요.</span>
          </li>
          <li>
            <strong>정산</strong>
            <span>방장이 결제내역을 올리면 운영자 확인 후 1/N로 나눠요.</span>
          </li>
        </ol>
        <p className="showcase__mode">
          {env.isMock ? '시연 모드 · 브라우저 안 Mock 서버로 동작 중' : `API ${env.apiBaseUrl}`}
        </p>
      </aside>
      <div className="showcase__device">
        <div className="device">
          <div className="phone-screen">
            <StatusBar />
            {children}
            <div id="phone-overlay" />
            <span className="home-indicator" aria-hidden="true" />
          </div>
          <img className="device__frame" src="/iphone-frame.png" alt="" draggable={false} />
        </div>
      </div>
    </div>
  );
}
