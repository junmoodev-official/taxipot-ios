import { CarTaxiFront, House, UserRound, Wallet } from 'lucide-react';
import { NavLink, Outlet } from 'react-router-dom';

const TABS = [
  { to: '/home', label: '홈', icon: House },
  { to: '/pots', label: '이용 기록', icon: CarTaxiFront },
  { to: '/wallet', label: '지갑', icon: Wallet },
  { to: '/me', label: '마이', icon: UserRound },
];

export function TabLayout() {
  return (
    <>
      <Outlet />
      <nav className="tabbar" aria-label="주 메뉴">
        {TABS.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) => `tabbar__item ${isActive ? 'is-active' : ''}`}
          >
            <Icon size={22} strokeWidth={2} />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>
    </>
  );
}
