export function Brand({ size = 'md' }: { size?: 'md' | 'lg' }) {
  return (
    <span className={`brand brand--${size}`}>
      <span className="brand__mark" aria-hidden="true">
        <svg viewBox="0 0 64 64" width="100%" height="100%">
          <rect width="64" height="64" rx="18" fill="currentColor" />
          <rect x="25" y="10" width="14" height="7" rx="2.5" fill="#FFB020" />
          <path
            d="M15 36h34l-5-13a7 7 0 0 0-7-5H27a7 7 0 0 0-7 5z"
            fill="none"
            stroke="#fff"
            strokeWidth="4"
            strokeLinejoin="round"
          />
          <path
            d="M13 34v11m38-11v11M13 41h38"
            stroke="#fff"
            strokeWidth="4"
            strokeLinecap="round"
          />
        </svg>
      </span>
      <span className="brand__word">택시팟</span>
    </span>
  );
}
