import { ChevronLeft } from 'lucide-react';
import type { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';

interface PageHeaderProps {
  title: string;
  /** 뒤로 갈 경로. 생략하면 브라우저 히스토리 뒤로 */
  backTo?: string;
  right?: ReactNode;
}

export function PageHeader({ title, backTo, right }: PageHeaderProps) {
  const navigate = useNavigate();
  const goBack = () => {
    if (backTo) navigate(backTo, { replace: true });
    else if (window.history.length > 1) navigate(-1);
    else navigate('/home', { replace: true });
  };
  return (
    <header className="page-header">
      <button type="button" className="icon-btn" aria-label="뒤로 가기" onClick={goBack}>
        <ChevronLeft size={24} />
      </button>
      <h1>{title}</h1>
      <div className="page-header__right">{right}</div>
    </header>
  );
}
