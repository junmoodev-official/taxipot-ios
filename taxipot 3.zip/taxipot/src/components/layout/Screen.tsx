import type { ReactNode } from 'react';

interface ScreenProps {
  header?: ReactNode;
  footer?: ReactNode;
  children: ReactNode;
  className?: string;
  /** 하단 탭바가 있는 화면 */
  withTabs?: boolean;
}

/** 헤더 고정 + 본문 스크롤 + 하단 고정 버튼 영역 */
export function Screen({
  header,
  footer,
  children,
  className = '',
  withTabs = false,
}: ScreenProps) {
  return (
    <div className={`screen ${withTabs ? 'screen--tabs' : ''} ${className}`}>
      {header}
      <main className="screen__body">{children}</main>
      {footer && <div className="screen__footer">{footer}</div>}
    </div>
  );
}
