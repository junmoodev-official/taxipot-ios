import type { PotStatus } from '@/api/types';
import { Badge } from '@/components/ui/Feedback';
import { potStatusLabel } from '@/lib/labels';

const TONE: Record<PotStatus, 'brand' | 'amber' | 'neutral' | 'success' | 'danger'> = {
  RECRUITING: 'brand',
  CLOSED: 'amber',
  RUNNING: 'success',
  COMPLETED: 'neutral',
  CANCELED: 'danger',
};

export function PotStatusBadge({ status }: { status: PotStatus }) {
  return <Badge tone={TONE[status] ?? 'neutral'}>{potStatusLabel(status)}</Badge>;
}
