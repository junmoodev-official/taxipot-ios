interface RouteLineProps {
  from: string;
  to: string;
  size?: 'md' | 'lg';
}

/** 출발지 → 도착지 세로 경로 표시 */
export function RouteLine({ from, to, size = 'md' }: RouteLineProps) {
  return (
    <div className={`route route--${size}`}>
      <span className="route__track" aria-hidden="true">
        <i className="route__dot route__dot--from" />
        <i className="route__bar" />
        <i className="route__dot route__dot--to" />
      </span>
      <span className="route__names">
        <span>
          <span className="visually-hidden">출발지 </span>
          {from}
        </span>
        <span>
          <span className="visually-hidden">도착지 </span>
          {to}
        </span>
      </span>
    </div>
  );
}
