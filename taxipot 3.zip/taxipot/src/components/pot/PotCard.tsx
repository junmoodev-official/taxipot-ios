import { ChevronRight, Star, UsersRound } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { PotSummaryResponse } from '@/api/types';
import { clock, dayAndTime, distance, rating, won } from '@/lib/format';
import { genderOptionLabel } from '@/lib/labels';
import { serverClock } from '@/lib/time';
import { RouteLine } from './RouteLine';

/**
 * 택시팟 카드 — 왼쪽은 미터기처럼 출발 시각을 크게, 오른쪽은 경로·인원·예치액.
 * 이탈로 빈자리가 생긴 방(hasCanceled)은 지붕등 색으로 구분해 상단에 노출됩니다.
 */
export function PotCard({ pot }: { pot: PotSummaryResponse }) {
  const deadlinePassed = serverClock.isPast(pot.joinDeadline);
  const seatsLeft = pot.maxMembers - pot.currentMembers;
  return (
    <Link
      to={`/pots/${pot.id}`}
      className={`pot-card ${pot.hasCanceled ? 'pot-card--reopened' : ''}`}
    >
      <div className="pot-card__meter">
        <span className="pot-card__time">{clock(pot.departureTime)}</span>
        <span className="pot-card__day">{dayAndTime(pot.departureTime).split(' ')[0]}</span>
        {pot.distanceMeters !== null && (
          <span className="pot-card__distance">{distance(pot.distanceMeters)}</span>
        )}
      </div>
      <div className="pot-card__main">
        <div className="pot-card__top">
          {pot.hasCanceled && <span className="roof-tag">빈자리 생김</span>}
          {pot.genderOption !== 'ALL' && (
            <span className="mini-tag">{genderOptionLabel(pot.genderOption)}</span>
          )}
          {deadlinePassed && <span className="mini-tag mini-tag--warn">입장 요청만 가능</span>}
        </div>
        <RouteLine from={pot.departureName} to={pot.destinationName} />
        <div className="pot-card__meta">
          <span>
            <UsersRound size={14} /> {pot.currentMembers}/{pot.maxMembers}명 · {seatsLeft}자리
          </span>
          <span>
            <Star size={13} /> {pot.hostNickname} {rating(pot.hostRatingAvg)}
          </span>
        </div>
        <div className="pot-card__fare">
          예치 <strong>{won(pot.holdAmount)}</strong>
          <small>예상 {won(pot.expectedFare)}</small>
        </div>
      </div>
      <ChevronRight className="pot-card__chevron" size={18} aria-hidden="true" />
    </Link>
  );
}
