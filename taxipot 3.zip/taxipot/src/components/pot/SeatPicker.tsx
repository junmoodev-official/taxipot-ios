import type { PreferredSeat } from '@/api/types';
import { seatLabel } from '@/lib/labels';

const LAYOUT: { seat: PreferredSeat; className: string }[] = [
  { seat: 'FRONT', className: 'seat--front' },
  { seat: 'BACK_LEFT', className: 'seat--bl' },
  { seat: 'BACK_MID', className: 'seat--bm' },
  { seat: 'BACK_RIGHT', className: 'seat--br' },
];

interface SeatPickerProps {
  value: PreferredSeat;
  onChange: (seat: PreferredSeat) => void;
  /** 다른 참여자가 고른 좌석 (참고 표시, 중복 선택은 허용) */
  taken?: PreferredSeat[];
}

/** 택시 평면도 위에서 희망 좌석 선택 */
export function SeatPicker({ value, onChange, taken = [] }: SeatPickerProps) {
  return (
    <div className="seat-picker">
      <div className="seat-picker__car" role="radiogroup" aria-label="희망 좌석">
        <span className="seat seat--driver" aria-hidden="true">
          기사
        </span>
        {LAYOUT.map(({ seat, className }) => (
          <button
            key={seat}
            type="button"
            role="radio"
            aria-checked={value === seat}
            className={`seat ${className} ${value === seat ? 'is-active' : ''} ${taken.includes(seat) ? 'is-taken' : ''}`}
            onClick={() => onChange(seat)}
          >
            {seatLabel(seat).replace('뒷좌석 ', '')}
          </button>
        ))}
      </div>
      <button
        type="button"
        className={`seat-picker__any ${value === 'NONE' ? 'is-active' : ''}`}
        onClick={() => onChange('NONE')}
      >
        자리 상관없음
      </button>
    </div>
  );
}
