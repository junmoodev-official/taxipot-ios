import { CheckCircle2, Clock3, Crown } from 'lucide-react';
import type { ReactNode } from 'react';
import type { PotMemberResponse } from '@/api/types';
import { Avatar } from '@/components/ui/Feedback';
import { clock, rating } from '@/lib/format';
import { memberStatusLabel, seatLabel } from '@/lib/labels';

interface MemberListProps {
  members: PotMemberResponse[];
  myId: number;
  /** 참여자별 오른쪽 동작 (방장의 내보내기 등) */
  action?: (member: PotMemberResponse) => ReactNode;
}

export function MemberList({ members, myId, action }: MemberListProps) {
  return (
    <ul className="member-list">
      {members.map((member) => (
        <li key={member.id} className="member">
          <Avatar name={member.nickname} />
          <div className="member__body">
            <strong>
              {member.nickname}
              {member.memberId === myId && <span className="member__me">나</span>}
              {member.role === 'HOST' && (
                <Crown size={13} className="member__crown" aria-label="방장" />
              )}
            </strong>
            <small>
              평점 {rating(member.ratingAvg)} · {seatLabel(member.preferredSeat)}
              {member.status === 'BOARDED' && ` · ${memberStatusLabel(member.status)}`}
            </small>
          </div>
          {member.status === 'JOINED' &&
            (member.arrivedAt ? (
              <span className="member__state member__state--ok">
                <CheckCircle2 size={14} /> {clock(member.arrivedAt)} 도착
              </span>
            ) : (
              <span className="member__state">
                <Clock3 size={14} /> 이동 중
              </span>
            ))}
          {action?.(member)}
        </li>
      ))}
    </ul>
  );
}
