import {
  useId,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from 'react';

interface FieldShellProps {
  id: string;
  label?: string;
  hint?: ReactNode;
  error?: string | null;
  children: ReactNode;
}

function FieldShell({ id, label, hint, error, children }: FieldShellProps) {
  return (
    <div className={`field ${error ? 'field--error' : ''}`}>
      {label && (
        <label className="field__label" htmlFor={id}>
          {label}
        </label>
      )}
      {children}
      {error ? (
        <p className="field__message field__message--error" id={`${id}-msg`}>
          {error}
        </p>
      ) : (
        hint && (
          <p className="field__message" id={`${id}-msg`}>
            {hint}
          </p>
        )
      )}
    </div>
  );
}

interface TextFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'prefix'> {
  label?: string;
  hint?: ReactNode;
  error?: string | null;
  icon?: ReactNode;
  suffix?: ReactNode;
}

export function TextField({
  label,
  hint,
  error,
  icon,
  suffix,
  id,
  className = '',
  ...rest
}: TextFieldProps) {
  const autoId = useId();
  const fieldId = id ?? autoId;
  return (
    <FieldShell id={fieldId} label={label} hint={hint} error={error}>
      <div className={`input ${className}`}>
        {icon && <span className="input__icon">{icon}</span>}
        <input
          id={fieldId}
          aria-invalid={Boolean(error)}
          aria-describedby={`${fieldId}-msg`}
          {...rest}
        />
        {suffix && <span className="input__suffix">{suffix}</span>}
      </div>
    </FieldShell>
  );
}

interface SelectFieldProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  hint?: ReactNode;
  error?: string | null;
  icon?: ReactNode;
}

export function SelectField({ label, hint, error, icon, id, children, ...rest }: SelectFieldProps) {
  const autoId = useId();
  const fieldId = id ?? autoId;
  return (
    <FieldShell id={fieldId} label={label} hint={hint} error={error}>
      <div className="input input--select">
        {icon && <span className="input__icon">{icon}</span>}
        <select id={fieldId} aria-invalid={Boolean(error)} {...rest}>
          {children}
        </select>
      </div>
    </FieldShell>
  );
}

interface TextAreaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  hint?: ReactNode;
  error?: string | null;
}

export function TextArea({ label, hint, error, id, maxLength, value, ...rest }: TextAreaProps) {
  const autoId = useId();
  const fieldId = id ?? autoId;
  const length = typeof value === 'string' ? value.length : 0;
  return (
    <FieldShell
      id={fieldId}
      label={label}
      error={error}
      hint={
        maxLength ? (
          <span className="field__count">
            {hint} {length}/{maxLength}
          </span>
        ) : (
          hint
        )
      }
    >
      <textarea id={fieldId} className="textarea" maxLength={maxLength} value={value} {...rest} />
    </FieldShell>
  );
}

interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  children: ReactNode;
}

export function Checkbox({ children, className = '', ...rest }: CheckboxProps) {
  return (
    <label className={`checkbox ${className}`}>
      <input type="checkbox" {...rest} />
      <span className="checkbox__box" aria-hidden="true" />
      <span className="checkbox__label">{children}</span>
    </label>
  );
}
