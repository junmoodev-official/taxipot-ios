interface Option<V extends string | number> {
  value: V;
  label: string;
  disabled?: boolean;
}

interface SegmentedProps<V extends string | number> {
  options: Option<V>[];
  value: V;
  onChange: (value: V) => void;
  label?: string;
  scroll?: boolean;
}

/** 칩 형태의 단일 선택 */
export function Segmented<V extends string | number>({
  options,
  value,
  onChange,
  label,
  scroll = false,
}: SegmentedProps<V>) {
  return (
    <div
      className={`segmented ${scroll ? 'segmented--scroll' : ''}`}
      role="radiogroup"
      aria-label={label}
    >
      {options.map((option) => (
        <button
          key={String(option.value)}
          type="button"
          role="radio"
          aria-checked={option.value === value}
          disabled={option.disabled}
          className={`segmented__item ${option.value === value ? 'is-active' : ''}`}
          onClick={() => onChange(option.value)}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}
