import { ImagePlus, RefreshCw } from 'lucide-react';
import { useEffect, useId, useState } from 'react';
import { validateImage } from '@/lib/validators';

interface ImagePickerProps {
  label: string;
  hint: string;
  file: File | null;
  onChange: (file: File | null, error: string | null) => void;
  error?: string | null;
}

/** jpg·png 10MB 이하 사진 선택 + 미리보기 */
export function ImagePicker({ label, hint, file, onChange, error }: ImagePickerProps) {
  const id = useId();
  const [preview, setPreview] = useState<string | null>(null);

  useEffect(() => {
    if (!file) {
      setPreview(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  return (
    <div className={`field ${error ? 'field--error' : ''}`}>
      <span className="field__label">{label}</span>
      <label htmlFor={id} className={`image-picker ${preview ? 'has-image' : ''}`}>
        {preview ? (
          <>
            <img src={preview} alt="선택한 사진 미리보기" />
            <span className="image-picker__change">
              <RefreshCw size={14} /> 다시 선택
            </span>
          </>
        ) : (
          <span className="image-picker__empty">
            <ImagePlus size={28} />
            <strong>사진 선택</strong>
            <small>{hint}</small>
          </span>
        )}
      </label>
      <input
        id={id}
        className="visually-hidden"
        type="file"
        accept="image/jpeg,image/png"
        onChange={(event) => {
          const next = event.target.files?.[0] ?? null;
          onChange(next, next ? validateImage(next) : null);
          event.target.value = '';
        }}
      />
      {error && <p className="field__message field__message--error">{error}</p>}
    </div>
  );
}
