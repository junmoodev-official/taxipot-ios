import { Star } from 'lucide-react';

interface StarRatingProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
}

export function StarRating({ label, value, onChange }: StarRatingProps) {
  return (
    <div className="stars">
      <span className="stars__label">{label}</span>
      <div className="stars__row" role="radiogroup" aria-label={label}>
        {[1, 2, 3, 4, 5].map((score) => (
          <button
            key={score}
            type="button"
            role="radio"
            aria-checked={value === score}
            aria-label={`${score}점`}
            className={`stars__star ${score <= value ? 'is-on' : ''}`}
            onClick={() => onChange(score)}
          >
            <Star size={24} fill={score <= value ? 'currentColor' : 'none'} />
          </button>
        ))}
      </div>
    </div>
  );
}
