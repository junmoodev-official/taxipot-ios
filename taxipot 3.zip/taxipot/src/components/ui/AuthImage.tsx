import { useCallback } from 'react';
import { errorMessage } from '@/api/errors';
import { useBlobUrl } from '@/hooks/useBlobUrl';
import { Loader } from './Feedback';

/** Bearer 토큰이 필요한 이미지 API 를 표시합니다. */
export function AuthImage({ load, alt }: { load: () => Promise<Blob>; alt: string }) {
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const stable = useCallback(load, []);
  const { url, error } = useBlobUrl(stable);
  if (error) return <p className="auth-image__error">{errorMessage(error)}</p>;
  if (!url) return <Loader label="사진 불러오는 중" />;
  return <img className="auth-image" src={url} alt={alt} />;
}
