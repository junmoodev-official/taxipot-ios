/**
 * 지도.
 * - 카카오맵 키가 있으면 실제 지도 + 마커
 * - 없으면 좌표를 투영한 캠퍼스 약도(SVG). 실제 도로·경로 정보가 아님을 표시합니다.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { env } from '@/config/env';
import { DEFAULT_CENTER, PLACE_PRESETS, type LatLng } from '@/lib/geo';
import { loadKakao } from './kakao';

export interface MapMarker extends LatLng {
  id: string | number;
  label: string;
  tone?: 'brand' | 'amber' | 'ink';
  onClick?: () => void;
}

interface MapViewProps {
  markers: MapMarker[];
  /** 출발지→도착지 선 */
  route?: [LatLng, LatLng];
  me?: LatLng | null;
  height?: number;
}

export function MapView(props: MapViewProps) {
  const [kakaoReady, setKakaoReady] = useState<boolean | null>(env.kakaoMapKey ? null : false);
  useEffect(() => {
    if (!env.kakaoMapKey) return;
    void loadKakao().then((maps) => setKakaoReady(Boolean(maps)));
  }, []);
  if (kakaoReady) return <KakaoMapView {...props} />;
  return <SchematicMap {...props} />;
}

function KakaoMapView({ markers, route, me, height = 200 }: MapViewProps) {
  const container = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const maps = window.kakao?.maps;
    if (!maps || !container.current) return;
    const center = markers[0] ?? me ?? DEFAULT_CENTER;
    const map = new maps.Map(container.current, {
      center: new maps.LatLng(center.lat, center.lng),
      level: 6,
    });
    const bounds = new maps.LatLngBounds();
    const points = [...markers, ...(me ? [{ ...me, id: 'me', label: '내 위치' }] : [])];
    points.forEach((point) => {
      const position = new maps.LatLng(point.lat, point.lng);
      const marker = new maps.Marker({ position, map, title: point.label });
      bounds.extend(position);
      if ('onClick' in point && point.onClick)
        maps.event.addListener(marker, 'click', point.onClick);
    });
    if (route) {
      const path = route.map((p) => new maps.LatLng(p.lat, p.lng));
      path.forEach((p) => bounds.extend(p));
      new maps.Polyline({
        path,
        strokeWeight: 5,
        strokeColor: '#2D6BFF',
        strokeOpacity: 0.85,
        map,
      });
    }
    if (points.length + (route ? 2 : 0) > 1) map.setBounds(bounds);
  }, [markers, route, me]);
  return (
    <div
      ref={container}
      className="map map--kakao"
      style={{ height }}
      role="img"
      aria-label="택시팟 위치 지도"
    />
  );
}

const W = 340;

function SchematicMap({ markers, route, me, height = 200 }: MapViewProps) {
  const H = Math.round((height / 200) * 200);
  const project = useMemo(() => {
    const points: LatLng[] = [...markers, ...(route ?? []), ...(me ? [me] : [])];
    const base = points.length ? points : PLACE_PRESETS;
    const lats = base.map((p) => p.lat);
    const lngs = base.map((p) => p.lng);
    const pad = 0.012;
    const minLat = Math.min(...lats) - pad;
    const maxLat = Math.max(...lats) + pad;
    const minLng = Math.min(...lngs) - pad;
    const maxLng = Math.max(...lngs) + pad;
    return (p: LatLng) => ({
      x: 24 + ((p.lng - minLng) / (maxLng - minLng || 1)) * (W - 48),
      y: 24 + ((maxLat - p.lat) / (maxLat - minLat || 1)) * (H - 48),
    });
  }, [markers, route, me, H]);

  const routePath = route
    ? (() => {
        const a = project(route[0]);
        const b = project(route[1]);
        const mx = (a.x + b.x) / 2 + (b.y - a.y) * 0.18;
        const my = (a.y + b.y) / 2 - (b.x - a.x) * 0.18;
        return { a, b, d: `M${a.x} ${a.y} Q${mx} ${my} ${b.x} ${b.y}` };
      })()
    : null;

  return (
    <div className="map map--schematic" style={{ height }}>
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label="택시팟 위치 약도 (실제 도로 정보 아님)">
        <rect width={W} height={H} className="map__ground" />
        <path
          d={`M-10 ${H * 0.3} C ${W * 0.3} ${H * 0.2}, ${W * 0.6} ${H * 0.45}, ${W + 10} ${H * 0.35}`}
          className="map__river"
        />
        <path
          d={`M${W * 0.18} -10 L${W * 0.32} ${H + 10} M${W * 0.72} -10 L${W * 0.6} ${H + 10} M-10 ${H * 0.72} L${W + 10} ${H * 0.62}`}
          className="map__road"
        />
        <path
          d={`M${W * 0.18} -10 L${W * 0.32} ${H + 10} M${W * 0.72} -10 L${W * 0.6} ${H + 10} M-10 ${H * 0.72} L${W + 10} ${H * 0.62}`}
          className="map__road-line"
        />
        {routePath && (
          <>
            <path d={routePath.d} className="map__route-glow" />
            <path d={routePath.d} className="map__route" />
            <circle
              cx={routePath.a.x}
              cy={routePath.a.y}
              r="7"
              className="map__pin map__pin--from"
            />
            <circle cx={routePath.b.x} cy={routePath.b.y} r="7" className="map__pin map__pin--to" />
          </>
        )}
        {markers.map((marker) => {
          const { x, y } = project(marker);
          return (
            <g
              key={marker.id}
              transform={`translate(${x} ${y})`}
              className={`map__marker map__marker--${marker.tone ?? 'brand'} ${marker.onClick ? 'is-clickable' : ''}`}
              onClick={marker.onClick}
              role={marker.onClick ? 'button' : undefined}
              tabIndex={marker.onClick ? 0 : undefined}
              aria-label={marker.label}
              onKeyDown={(e) => e.key === 'Enter' && marker.onClick?.()}
            >
              <path d="M0 0 C-9 -10 -11 -15 -11 -20 A11 11 0 1 1 11 -20 C11 -15 9 -10 0 0Z" />
              <circle cy="-20" r="4.5" fill="#fff" />
            </g>
          );
        })}
        {me && (
          <g transform={`translate(${project(me).x} ${project(me).y})`}>
            <circle r="14" className="map__me-halo" />
            <circle r="6" className="map__me" />
          </g>
        )}
      </svg>
      <span className="map__caption">약도 · 실제 도로와 다를 수 있어요</span>
    </div>
  );
}
