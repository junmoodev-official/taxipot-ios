/** 장소 선택 시트 — 카카오 장소 검색, 키가 없으면 기본 장소 목록에서 검색 */
import { MapPin, Search } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Sheet } from '@/components/ui/Sheet';
import { searchPresets, type Place } from '@/lib/geo';
import { searchKakaoPlaces } from './kakao';

interface PlacePickerProps {
  open: boolean;
  title: string;
  onClose: () => void;
  onSelect: (place: Place) => void;
}

export function PlacePicker({ open, title, onClose, onSelect }: PlacePickerProps) {
  const [keyword, setKeyword] = useState('');
  const [results, setResults] = useState<Place[]>(searchPresets(''));

  useEffect(() => {
    if (!open) return;
    let alive = true;
    const timer = window.setTimeout(async () => {
      const kakao = keyword.trim().length >= 2 ? await searchKakaoPlaces(keyword.trim()) : null;
      if (alive) setResults(kakao ?? searchPresets(keyword));
    }, 250);
    return () => {
      alive = false;
      window.clearTimeout(timer);
    };
  }, [keyword, open]);

  return (
    <Sheet open={open} title={title} onClose={onClose}>
      <div className="input place-search">
        <span className="input__icon">
          <Search size={18} />
        </span>
        <input
          autoFocus
          value={keyword}
          onChange={(event) => setKeyword(event.target.value)}
          placeholder="역, 학교, 건물 이름으로 검색"
          aria-label="장소 검색"
        />
      </div>
      <ul className="place-list">
        {results.map((place) => (
          <li key={`${place.name}-${place.lat}`}>
            <button
              type="button"
              onClick={() => {
                onSelect(place);
                onClose();
              }}
            >
              <MapPin size={18} />
              <span>
                <strong>{place.name}</strong>
                {place.address && <small>{place.address}</small>}
              </span>
            </button>
          </li>
        ))}
        {results.length === 0 && (
          <li className="place-list__empty">검색 결과가 없어요. 다른 이름으로 찾아보세요.</li>
        )}
      </ul>
    </Sheet>
  );
}
