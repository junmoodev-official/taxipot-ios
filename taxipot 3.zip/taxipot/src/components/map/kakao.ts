/**
 * 카카오맵 JavaScript SDK 로더 (VITE_KAKAO_MAP_KEY 가 있을 때만 사용).
 * 키가 없으면 앱은 내장 캠퍼스 지도와 기본 장소 목록으로 동작합니다.
 */
import { env } from '@/config/env';
import type { Place } from '@/lib/geo';

/* 사용하는 SDK 기능만 최소한으로 선언합니다. */
interface KakaoLatLng {
  getLat(): number;
  getLng(): number;
}

export interface KakaoMaps {
  load(callback: () => void): void;
  LatLng: new (lat: number, lng: number) => KakaoLatLng;
  LatLngBounds: new () => { extend(latlng: KakaoLatLng): void };
  Map: new (
    container: HTMLElement,
    options: { center: KakaoLatLng; level: number },
  ) => { setBounds(bounds: unknown): void; setCenter(latlng: KakaoLatLng): void; relayout(): void };
  Marker: new (options: { position: KakaoLatLng; map?: unknown; title?: string }) => {
    setMap(map: unknown): void;
  };
  Polyline: new (options: {
    path: KakaoLatLng[];
    strokeWeight: number;
    strokeColor: string;
    strokeOpacity: number;
    map?: unknown;
  }) => { setMap(map: unknown): void };
  event: { addListener(target: unknown, type: string, handler: () => void): void };
  services: {
    Places: new () => {
      keywordSearch(
        keyword: string,
        callback: (
          result: {
            place_name: string;
            road_address_name: string;
            address_name: string;
            x: string;
            y: string;
          }[],
          status: string,
        ) => void,
      ): void;
    };
    Status: { OK: string };
  };
}

declare global {
  interface Window {
    kakao?: { maps: KakaoMaps };
  }
}

let loading: Promise<KakaoMaps | null> | null = null;

export function loadKakao(): Promise<KakaoMaps | null> {
  if (!env.kakaoMapKey) return Promise.resolve(null);
  if (window.kakao?.maps?.services) return Promise.resolve(window.kakao.maps);
  loading ??= new Promise((resolve) => {
    const script = document.createElement('script');
    script.src = `https://dapi.kakao.com/v2/maps/sdk.js?appkey=${encodeURIComponent(env.kakaoMapKey)}&libraries=services&autoload=false`;
    script.async = true;
    script.onload = () => window.kakao?.maps.load(() => resolve(window.kakao!.maps));
    script.onerror = () => {
      loading = null;
      resolve(null);
    };
    document.head.appendChild(script);
  });
  return loading;
}

/** 카카오 장소 검색 → Place 목록 */
export async function searchKakaoPlaces(keyword: string): Promise<Place[] | null> {
  const maps = await loadKakao();
  if (!maps) return null;
  return new Promise((resolve) => {
    new maps.services.Places().keywordSearch(keyword, (result, status) => {
      if (status !== maps.services.Status.OK) return resolve([]);
      resolve(
        result.slice(0, 12).map((item) => ({
          name: item.place_name,
          address: item.road_address_name || item.address_name,
          lat: Number(item.y),
          lng: Number(item.x),
        })),
      );
    });
  });
}
