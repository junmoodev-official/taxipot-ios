/**
 * 현재 위치 조회.
 * - 실제 모드: navigator.geolocation (고정밀, 10초 제한)
 * - 시연 모드: PC에서는 50m 안 GPS 확인이 불가능하므로 기준 좌표 근처(약 12m)로 대신합니다.
 */
import { useCallback, useState } from 'react';
import { env } from '@/config/env';
import { offsetMeters, type LatLng } from '@/lib/geo';

export function useGeolocation() {
  const [locating, setLocating] = useState(false);

  const locate = useCallback(async (demoTarget?: LatLng): Promise<LatLng> => {
    if (env.isMock && demoTarget) {
      setLocating(true);
      await new Promise((resolve) => setTimeout(resolve, 600));
      setLocating(false);
      return offsetMeters(demoTarget, 8, -9);
    }
    if (!('geolocation' in navigator)) {
      throw new Error('이 기기에서는 위치 확인을 지원하지 않아요.');
    }
    setLocating(true);
    try {
      return await new Promise<LatLng>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
          (err) =>
            reject(
              new Error(
                err.code === err.PERMISSION_DENIED
                  ? '위치 권한을 허용해 주세요. 브라우저 설정에서 바꿀 수 있어요.'
                  : '위치를 확인하지 못했어요. 실외에서 다시 시도해 주세요.',
              ),
            ),
          { enableHighAccuracy: true, timeout: 10_000, maximumAge: 15_000 },
        );
      });
    } finally {
      setLocating(false);
    }
  }, []);

  return { locate, locating };
}
