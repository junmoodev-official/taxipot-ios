import { useEffect, useState } from 'react';
import { api } from '@/api';

/** 안 읽은 알림 수 (30초마다 갱신) */
export function useUnreadCount(): number {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let alive = true;
    const load = () =>
      api.notifications
        .unreadCount()
        .then((res) => alive && setCount(res.unreadCount))
        .catch(() => undefined);
    void load();
    const timer = window.setInterval(load, 30_000);
    window.addEventListener('focus', load);
    return () => {
      alive = false;
      window.clearInterval(timer);
      window.removeEventListener('focus', load);
    };
  }, []);
  return count;
}
