import { useEffect, useRef } from 'react';
import { realtime } from '@/api';
import type { Id, PotRealtimeEvent } from '@/api/types';

/** `/topic/pots/{potId}` 구독 (참여자만). enabled=false 면 구독하지 않습니다. */
export function usePotRealtime(
  potId: Id | undefined,
  enabled: boolean,
  onEvent: (event: PotRealtimeEvent) => void,
) {
  const handler = useRef(onEvent);
  handler.current = onEvent;

  useEffect(() => {
    if (!potId || !enabled) return;
    return realtime.subscribePot(potId, (event) => handler.current(event));
  }, [potId, enabled]);
}
