import { useCallback, useEffect, useRef, useState, type DependencyList } from 'react';

export interface AsyncState<T> {
  data: T | undefined;
  error: unknown;
  loading: boolean;
  reload: () => Promise<void>;
  setData: (value: T | ((prev: T | undefined) => T)) => void;
}

/** 비동기 조회 + 재조회. 언마운트·경쟁 응답을 무시합니다. */
export function useAsync<T>(task: () => Promise<T>, deps: DependencyList): AsyncState<T> {
  const [data, setDataState] = useState<T>();
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);
  const runId = useRef(0);
  const taskRef = useRef(task);
  taskRef.current = task;

  const reload = useCallback(async () => {
    runId.current += 1;
    const id = runId.current;
    setLoading(true);
    try {
      const result = await taskRef.current();
      if (id === runId.current) {
        setDataState(result);
        setError(null);
      }
    } catch (err) {
      if (id === runId.current) setError(err);
    } finally {
      if (id === runId.current) setLoading(false);
    }
  }, []);

  useEffect(() => {
    void reload();
    return () => {
      runId.current += 1;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  const setData = useCallback((value: T | ((prev: T | undefined) => T)) => {
    setDataState((prev) =>
      typeof value === 'function' ? (value as (p: T | undefined) => T)(prev) : value,
    );
  }, []);

  return { data, error, loading, reload, setData };
}
