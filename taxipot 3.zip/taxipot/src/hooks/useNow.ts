import { useEffect, useState } from 'react';
import { serverClock } from '@/lib/time';

/** 서버 시각 기준 현재 시각을 주기적으로 갱신합니다 (마감 카운트다운용). */
export function useNow(intervalMs = 1000): Date {
  const [now, setNow] = useState(() => serverClock.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(serverClock.now()), intervalMs);
    return () => window.clearInterval(timer);
  }, [intervalMs]);
  return now;
}
