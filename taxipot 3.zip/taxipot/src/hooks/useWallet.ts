import { useEffect } from 'react';
import { api } from '@/api';
import { appEvents } from '@/lib/events';
import { useAsync } from './useAsync';

/** 지갑 잔액. 잔액이 바뀌는 작업 후 `appEvents.emit('wallet-changed')` 로 모든 화면이 갱신됩니다. */
export function useWallet() {
  const state = useAsync(() => api.wallet.get(), []);
  const { reload } = state;
  useEffect(() => appEvents.on('wallet-changed', () => void reload()), [reload]);
  return state;
}

export function walletChanged() {
  appEvents.emit('wallet-changed', undefined);
}
