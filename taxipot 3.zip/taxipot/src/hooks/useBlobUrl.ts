import { useEffect, useState } from 'react';

/**
 * 인증이 필요한 이미지 API(Blob)를 <img> 로 표시하기 위한 object URL.
 * 명세: `<img src>` 는 Authorization 헤더를 못 보내므로 fetch → blob → createObjectURL.
 */
export function useBlobUrl(load: (() => Promise<Blob>) | null) {
  const [url, setUrl] = useState<string | null>(null);
  const [error, setError] = useState<unknown>(null);

  useEffect(() => {
    if (!load) return;
    let objectUrl: string | null = null;
    let alive = true;
    setUrl(null);
    setError(null);
    load()
      .then((blob) => {
        if (!alive) return;
        objectUrl = URL.createObjectURL(blob);
        setUrl(objectUrl);
      })
      .catch((err) => alive && setError(err));
    return () => {
      alive = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [load]);

  return { url, error };
}
