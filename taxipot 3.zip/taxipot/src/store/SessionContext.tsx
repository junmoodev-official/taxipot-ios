/**
 * 로그인 세션 상태.
 * - 앱 시작 시 저장된 토큰이 있으면 GET /api/users/me 로 복원
 * - 토큰 무효(TOKEN_REVOKED)·재발급 실패 시 로그아웃 상태로 전환
 */
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { api, tokenStore } from '@/api';
import type { LoginResponse, MyProfileResponse, SignupRequest, TokenResponse } from '@/api/types';
import { appEvents } from '@/lib/events';

type SessionStatus = 'loading' | 'guest' | 'authed';

interface SessionApi {
  status: SessionStatus;
  user: MyProfileResponse | null;
  login: (email: string, password: string) => Promise<MyProfileResponse>;
  signup: (body: SignupRequest) => Promise<MyProfileResponse>;
  logout: () => Promise<void>;
  /** 토큰 무효화 후(탈퇴 등) 로컬 세션만 정리 */
  clear: () => void;
  refreshUser: () => Promise<MyProfileResponse | null>;
  setUser: (user: MyProfileResponse) => void;
  applyTokens: (tokens: TokenResponse) => void;
}

const SessionContext = createContext<SessionApi | null>(null);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<SessionStatus>(
    tokenStore.hasSession() ? 'loading' : 'guest',
  );
  const [user, setUserState] = useState<MyProfileResponse | null>(null);

  const clear = useCallback(() => {
    tokenStore.clear();
    setUserState(null);
    setStatus('guest');
  }, []);

  const accept = useCallback((response: LoginResponse) => {
    tokenStore.save(response);
    setUserState(response.user);
    setStatus('authed');
    return response.user;
  }, []);

  const refreshUser = useCallback(async () => {
    if (!tokenStore.hasSession()) return null;
    try {
      const me = await api.users.me();
      setUserState(me);
      setStatus('authed');
      return me;
    } catch {
      if (!tokenStore.hasSession()) setStatus('guest');
      return null;
    }
  }, []);

  useEffect(() => {
    if (tokenStore.hasSession()) {
      void refreshUser().then((me) => {
        if (!me) clear();
      });
    }
    return appEvents.on('session-expired', () => {
      setUserState(null);
      setStatus('guest');
    });
  }, [refreshUser, clear]);

  const value = useMemo<SessionApi>(
    () => ({
      status,
      user,
      login: async (email, password) =>
        accept(await api.auth.login({ email: email.trim(), password })),
      signup: async (body) => accept(await api.auth.signup(body)),
      logout: async () => {
        try {
          await api.auth.logout();
        } finally {
          clear();
        }
      },
      clear,
      refreshUser,
      setUser: setUserState,
      applyTokens: (tokens) => tokenStore.save(tokens),
    }),
    [status, user, accept, clear, refreshUser],
  );

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession(): SessionApi {
  const context = useContext(SessionContext);
  if (!context) throw new Error('useSession must be used inside SessionProvider');
  return context;
}

/** 로그인된 화면에서만 사용 — user 가 항상 있음을 보장합니다. */
export function useUser(): MyProfileResponse {
  const { user } = useSession();
  if (!user) throw new Error('useUser requires an authenticated session');
  return user;
}
