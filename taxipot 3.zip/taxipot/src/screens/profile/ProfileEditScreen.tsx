import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/api';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { Checkbox, TextField } from '@/components/ui/Field';
import { phone as formatPhone } from '@/lib/format';
import { validateNickname, validatePhone } from '@/lib/validators';
import { useSession, useUser } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

export function ProfileEditScreen() {
  const user = useUser();
  const { setUser } = useSession();
  const toast = useToast();
  const navigate = useNavigate();
  const [nickname, setNickname] = useState(user.nickname);
  const [phone, setPhone] = useState(formatPhone(user.phone));
  const [marketing, setMarketing] = useState(user.agreeMarketing);
  const [busy, setBusy] = useState(false);

  const nicknameError = nickname !== user.nickname ? validateNickname(nickname) : null;
  const phoneError = validatePhone(phone);

  async function save() {
    if (nicknameError || phoneError) return;
    const body: { nickname?: string; phone?: string; agreeMarketing?: boolean } = {};
    if (nickname.trim() !== user.nickname) body.nickname = nickname.trim();
    if (phone.replace(/\D/g, '') !== user.phone) body.phone = phone.trim();
    if (marketing !== user.agreeMarketing) body.agreeMarketing = marketing;
    if (Object.keys(body).length === 0) return navigate(-1);
    setBusy(true);
    try {
      setUser(await api.users.update(body));
      toast.success('내 정보를 저장했어요.');
      navigate(-1);
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen
      header={<PageHeader title="내 정보 수정" />}
      footer={
        <Button
          size="lg"
          block
          loading={busy}
          onClick={() => void save()}
          disabled={Boolean(nicknameError || phoneError)}
        >
          저장
        </Button>
      }
    >
      <div className="form-stack">
        <TextField
          label="닉네임"
          maxLength={30}
          value={nickname}
          onChange={(e) => setNickname(e.target.value)}
          error={nicknameError}
        />
        <TextField
          label="휴대폰 번호"
          type="tel"
          inputMode="tel"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          error={phoneError}
        />
        <Checkbox checked={marketing} onChange={(e) => setMarketing(e.target.checked)}>
          이벤트·혜택 알림 받기
        </Checkbox>
        <TextField
          label="이름"
          value={user.name}
          readOnly
          hint="이름·성별·학번은 인증 정보라 바꿀 수 없어요."
        />
        <TextField label="학교" value={user.university} readOnly />
      </div>
    </Screen>
  );
}
