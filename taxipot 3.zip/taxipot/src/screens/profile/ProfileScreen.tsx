import {
  BadgeCheck,
  ChevronRight,
  FileWarning,
  KeyRound,
  Landmark,
  LogOut,
  ShieldAlert,
  UserPen,
  UserX,
} from 'lucide-react';
import { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Screen } from '@/components/layout/Screen';
import { Avatar, Badge, InfoRow, Notice } from '@/components/ui/Feedback';
import { env } from '@/config/env';
import { dayAndTime, phone, rating } from '@/lib/format';
import { userStatusLabel } from '@/lib/labels';
import { mockTools } from '@/mock/server';
import { useSession, useUser } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

export function ProfileScreen() {
  const user = useUser();
  const session = useSession();
  const toast = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    void session.refreshUser();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function logout() {
    await session.logout();
    toast.success('로그아웃했어요.');
    navigate('/welcome', { replace: true });
  }

  return (
    <Screen
      withTabs
      header={
        <header className="tab-header">
          <h1>마이</h1>
        </header>
      }
    >
      <section className="profile-card">
        <Avatar name={user.nickname} size="lg" />
        <div>
          <strong>{user.nickname}</strong>
          <span>
            {user.university} · {user.name}
          </span>
        </div>
        {user.isVerified ? (
          <Badge tone="success">인증 완료</Badge>
        ) : (
          <Link to="/verify">
            <Badge tone="amber">인증 필요</Badge>
          </Link>
        )}
      </section>

      <section className="stat-grid">
        <div>
          <span>평점</span>
          <strong>{rating(user.ratingAvg)}</strong>
          <small>10점 만점</small>
        </div>
        <div>
          <span>노쇼</span>
          <strong>{user.noShowCount}</strong>
          <small>누적</small>
        </div>
        <div>
          <span>신고</span>
          <strong>{user.reportCount}</strong>
          <small>
            {user.nextSuspensionIn !== null ? `정지까지 ${user.nextSuspensionIn}회` : '-'}
          </small>
        </div>
      </section>

      {user.status === 'SUSPENDED' && (
        <Notice tone="warn" icon={<ShieldAlert size={18} />}>
          {user.suspendedUntil
            ? `${dayAndTime(user.suspendedUntil)}까지`
            : '운영자가 해제할 때까지'}{' '}
          방 생성·참여가 제한돼요.
        </Notice>
      )}
      {user.reportCount > 0 && (
        <p className="screen-note">
          신고 없이 3번 탑승을 마치면 신고 누적이 1회 줄어요. (현재 {user.cleanStreak}/3)
        </p>
      )}

      <section className="panel">
        <dl>
          <InfoRow label="이메일">{user.email}</InfoRow>
          <InfoRow label="휴대폰">{phone(user.phone)}</InfoRow>
          <InfoRow label="학번">{user.studentNo}</InfoRow>
          <InfoRow label="계정 상태">{userStatusLabel(user.status)}</InfoRow>
        </dl>
      </section>

      <nav className="menu">
        {!user.isVerified && (
          <Link to="/verify" className="menu__item">
            <BadgeCheck size={20} />
            <span>학생 인증</span>
            <ChevronRight size={18} />
          </Link>
        )}
        <Link to="/me/edit" className="menu__item">
          <UserPen size={20} />
          <span>내 정보 수정</span>
          <ChevronRight size={18} />
        </Link>
        <Link to="/me/account" className="menu__item">
          <Landmark size={20} />
          <span>출금 계좌</span>
          <ChevronRight size={18} />
        </Link>
        <Link to="/me/password" className="menu__item">
          <KeyRound size={20} />
          <span>비밀번호 변경</span>
          <ChevronRight size={18} />
        </Link>
        <Link to="/me/reports" className="menu__item">
          <FileWarning size={20} />
          <span>내 신고 내역</span>
          <ChevronRight size={18} />
        </Link>
      </nav>

      <nav className="menu">
        <button type="button" className="menu__item" onClick={() => void logout()}>
          <LogOut size={20} />
          <span>로그아웃</span>
        </button>
        <Link to="/me/withdraw" className="menu__item menu__item--danger">
          <UserX size={20} />
          <span>회원 탈퇴</span>
          <ChevronRight size={18} />
        </Link>
      </nav>

      {env.isMock && (
        <button
          type="button"
          className="text-btn screen-note"
          onClick={() => {
            mockTools.reset();
            session.clear();
            navigate('/welcome', { replace: true });
          }}
        >
          시연 데이터 초기화
        </button>
      )}
      <p className="screen-note">택시팟 v3.10.0 · API 명세 3.10.0 / DB 설계서 14차</p>
    </Screen>
  );
}
