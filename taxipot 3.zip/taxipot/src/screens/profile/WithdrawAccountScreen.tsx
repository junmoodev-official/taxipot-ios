/** 회원 탈퇴 — 잔액 소멸 동의 필수, 성공 시 토큰 삭제 후 시작 화면 */
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '@/api';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { Checkbox, TextField } from '@/components/ui/Field';
import { InfoRow, Notice } from '@/components/ui/Feedback';
import { useWallet } from '@/hooks/useWallet';
import { won } from '@/lib/format';
import { useSession } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

export function WithdrawAccountScreen() {
  const session = useSession();
  const toast = useToast();
  const navigate = useNavigate();
  const wallet = useWallet();
  const [password, setPassword] = useState('');
  const [agree, setAgree] = useState(false);
  const [busy, setBusy] = useState(false);
  const balance = wallet.data?.balance ?? 0;

  async function submit() {
    if (!password || !agree) return;
    setBusy(true);
    try {
      await api.users.withdraw({ password, agreeBalanceForfeit: agree });
      session.clear();
      toast.success('탈퇴가 처리됐어요. 그동안 이용해 주셔서 고마워요.');
      navigate('/welcome', { replace: true });
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen
      header={<PageHeader title="회원 탈퇴" />}
      footer={
        <Button
          size="lg"
          block
          variant="danger"
          loading={busy}
          disabled={!password || !agree}
          onClick={() => void submit()}
        >
          탈퇴하기
        </Button>
      }
    >
      <div className="form-stack">
        <section className="panel">
          <dl>
            <InfoRow label="남은 잔액" strong>
              {won(balance)}
            </InfoRow>
            <InfoRow label="예치 중">{won(wallet.data?.heldBalance)}</InfoRow>
          </dl>
        </section>
        {balance > 0 && (
          <Notice tone="warn">
            남은 잔액은 소멸되며 환불되지 않아요. <Link to="/wallet/withdraw">먼저 출금하기</Link>
          </Notice>
        )}
        <Notice>
          진행 중인 택시팟이나 미수금이 있으면 탈퇴할 수 없어요. 개인정보는 14일 뒤 파기돼요.
        </Notice>
        <TextField
          label="비밀번호 확인"
          type="password"
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <Checkbox checked={agree} onChange={(e) => setAgree(e.target.checked)}>
          남은 잔액 {won(balance)}이 소멸되며 환불되지 않는다는 안내를 확인했어요.
        </Checkbox>
      </div>
    </Screen>
  );
}
