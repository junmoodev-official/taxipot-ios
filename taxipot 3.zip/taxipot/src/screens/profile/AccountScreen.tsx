import { useEffect, useState } from 'react';
import { api, isApiError } from '@/api';
import type { BankResponse } from '@/api/types';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { SelectField, TextField } from '@/components/ui/Field';
import { InfoRow, Loader, Notice } from '@/components/ui/Feedback';
import { useAsync } from '@/hooks/useAsync';
import { digitsOnly, validateAccountNumber } from '@/lib/validators';
import { useUser } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

export function AccountScreen() {
  const user = useUser();
  const toast = useToast();
  const account = useAsync(
    () => api.users.account().catch((e) => (isApiError(e, 'NOT_FOUND') ? null : Promise.reject(e))),
    [],
  );
  const [banks, setBanks] = useState<BankResponse[]>([]);
  const [bankCode, setBankCode] = useState('');
  const [number, setNumber] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void api.auth.banks().then(setBanks).catch(toast.error);
  }, [toast.error]);

  const numberError = number ? validateAccountNumber(number) : null;

  async function save() {
    if (!bankCode || !number || numberError || !password)
      return toast.error('은행, 계좌번호, 비밀번호를 모두 입력해 주세요.');
    setBusy(true);
    try {
      account.setData(
        await api.users.updateAccount({
          password,
          bankCode,
          accountNumber: digitsOnly(number),
          accountHolder: user.name,
        }),
      );
      setNumber('');
      setPassword('');
      toast.success('출금 계좌를 저장했어요.');
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen
      header={<PageHeader title="출금 계좌" />}
      footer={
        <Button size="lg" block loading={busy} onClick={() => void save()}>
          {account.data ? '계좌 변경' : '계좌 등록'}
        </Button>
      }
    >
      {account.loading ? (
        <Loader />
      ) : (
        <div className="form-stack">
          {account.data ? (
            <section className="panel">
              <dl>
                <InfoRow label="현재 계좌">
                  {account.data.bankName} {account.data.maskedAccountNumber}
                </InfoRow>
                <InfoRow label="예금주">{account.data.accountHolder}</InfoRow>
              </dl>
            </section>
          ) : (
            <Notice tone="warn">
              등록된 계좌가 없어요. 출금하려면 본인 명의 계좌를 등록해 주세요.
            </Notice>
          )}
          <SelectField label="은행" value={bankCode} onChange={(e) => setBankCode(e.target.value)}>
            <option value="">은행을 선택해 주세요</option>
            {banks.map((bank) => (
              <option key={bank.code} value={bank.code}>
                {bank.name}
              </option>
            ))}
          </SelectField>
          <TextField
            label="계좌번호"
            inputMode="numeric"
            value={number}
            onChange={(e) => setNumber(e.target.value)}
            error={numberError}
          />
          <TextField
            label="예금주"
            value={user.name}
            readOnly
            hint="본인 명의 계좌만 등록할 수 있어요."
          />
          <TextField
            label="비밀번호 확인"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
      )}
    </Screen>
  );
}
