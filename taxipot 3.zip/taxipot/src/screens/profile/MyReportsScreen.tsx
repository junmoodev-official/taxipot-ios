import { FileWarning } from 'lucide-react';
import { api } from '@/api';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Badge, EmptyState, ErrorState, Loader } from '@/components/ui/Feedback';
import { useAsync } from '@/hooks/useAsync';
import { fullDateTime } from '@/lib/format';
import { reportStatusLabel, reportTypeLabel } from '@/lib/labels';

export function MyReportsScreen() {
  const list = useAsync(() => api.users.myReports({ size: 50 }), []);
  return (
    <Screen header={<PageHeader title="내 신고 내역" />}>
      {list.loading && !list.data && <Loader />}
      {list.error ? <ErrorState error={list.error} onRetry={() => void list.reload()} /> : null}
      {list.data?.content.length === 0 && (
        <EmptyState icon={<FileWarning size={26} />} title="접수한 신고가 없어요" />
      )}
      <ul className="history">
        {list.data?.content.map((r) => (
          <li key={r.id} className="panel">
            <div className="panel__row">
              <strong>
                {r.reportedNickname} · {reportTypeLabel(r.type)}
              </strong>
              <Badge
                tone={
                  r.status === 'APPROVED'
                    ? 'success'
                    : r.status === 'REJECTED'
                      ? 'neutral'
                      : 'brand'
                }
              >
                {reportStatusLabel(r.status)}
              </Badge>
            </div>
            <p className="panel__desc">{r.reason}</p>
            <small className="panel__foot">{fullDateTime(r.createdAt)} 접수</small>
          </li>
        ))}
      </ul>
    </Screen>
  );
}
