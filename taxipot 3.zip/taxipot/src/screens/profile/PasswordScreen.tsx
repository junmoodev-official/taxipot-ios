import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/api';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/Field';
import { Notice } from '@/components/ui/Feedback';
import { validatePassword } from '@/lib/validators';
import { useSession } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

export function PasswordScreen() {
  const { applyTokens } = useSession();
  const toast = useToast();
  const navigate = useNavigate();
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);

  const nextError = next ? validatePassword(next) : null;
  const confirmError = confirm && confirm !== next ? '새 비밀번호가 서로 달라요.' : null;

  async function submit() {
    if (!current || !next || nextError || confirmError) return;
    setBusy(true);
    try {
      // 명세 3.3.0: 응답의 새 토큰으로 교체해 이 기기의 로그인을 유지합니다.
      applyTokens(await api.users.changePassword({ currentPassword: current, newPassword: next }));
      toast.success('비밀번호를 바꿨어요. 다른 기기에서는 다시 로그인해야 해요.');
      navigate(-1);
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen
      header={<PageHeader title="비밀번호 변경" />}
      footer={
        <Button
          size="lg"
          block
          loading={busy}
          onClick={() => void submit()}
          disabled={!current || !next || !confirm || Boolean(nextError || confirmError)}
        >
          변경하기
        </Button>
      }
    >
      <div className="form-stack">
        <TextField
          label="현재 비밀번호"
          type="password"
          autoComplete="current-password"
          value={current}
          onChange={(e) => setCurrent(e.target.value)}
        />
        <TextField
          label="새 비밀번호"
          type="password"
          autoComplete="new-password"
          value={next}
          onChange={(e) => setNext(e.target.value)}
          error={nextError}
          hint="영문과 숫자를 섞어 8자 이상"
        />
        <TextField
          label="새 비밀번호 확인"
          type="password"
          autoComplete="new-password"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          error={confirmError}
        />
        <Notice>비밀번호를 바꾸면 다른 기기의 로그인은 모두 해제돼요.</Notice>
      </div>
    </Screen>
  );
}
