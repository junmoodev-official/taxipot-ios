import { CarTaxiFront, ChevronRight } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '@/api';
import type { MyPotHistoryResponse, PotMemberRole, PotStatus } from '@/api/types';
import { Screen } from '@/components/layout/Screen';
import { PotStatusBadge } from '@/components/pot/PotStatusBadge';
import { RouteLine } from '@/components/pot/RouteLine';
import { Badge, EmptyState, ErrorState, Loader } from '@/components/ui/Feedback';
import { Segmented } from '@/components/ui/Segmented';
import { useAsync } from '@/hooks/useAsync';
import { dayAndTime, won } from '@/lib/format';
import { debtStatusLabel, memberStatusLabel } from '@/lib/labels';

type StatusFilter = 'ALL' | PotStatus;
type RoleFilter = 'ALL' | PotMemberRole;

function Outcome({ item }: { item: MyPotHistoryResponse }) {
  if (item.settlementStatus === 'SETTLED') {
    const paid = (item.fareShare ?? 0) + (item.feeAmount ?? 0);
    return (
      <span className="history__money">
        분담 {won(paid)}
        {item.debtStatus !== 'NONE' && item.debtStatus !== 'PAID' && (
          <Badge tone="danger">미수금 {debtStatusLabel(item.debtStatus)}</Badge>
        )}
      </span>
    );
  }
  if (item.settlementStatus === 'REFUNDED')
    return <span className="history__money">예치금 {won(item.heldAmount)} 환불</span>;
  return <span className="history__money">예치 중 {won(item.heldAmount)}</span>;
}

export function MyPotsScreen() {
  const [status, setStatus] = useState<StatusFilter>('ALL');
  const [role, setRole] = useState<RoleFilter>('ALL');
  const list = useAsync(
    () =>
      api.users.myPots({
        status: status === 'ALL' ? undefined : status,
        role: role === 'ALL' ? undefined : role,
        size: 50,
      }),
    [status, role],
  );

  return (
    <Screen
      withTabs
      header={
        <header className="tab-header">
          <h1>이용 기록</h1>
        </header>
      }
    >
      <div className="filters">
        <Segmented
          scroll
          label="방 상태"
          value={status}
          onChange={setStatus}
          options={[
            { value: 'ALL', label: '전체' },
            { value: 'RECRUITING', label: '모집 중' },
            { value: 'RUNNING', label: '이동 중' },
            { value: 'COMPLETED', label: '정산 완료' },
            { value: 'CANCELED', label: '취소' },
          ]}
        />
        <Segmented
          label="역할"
          value={role}
          onChange={setRole}
          options={[
            { value: 'ALL', label: '전체' },
            { value: 'HOST', label: '방장' },
            { value: 'GUEST', label: '동승' },
          ]}
        />
      </div>
      {list.loading && !list.data && <Loader />}
      {list.error ? <ErrorState error={list.error} onRetry={() => void list.reload()} /> : null}
      {list.data && list.data.content.length === 0 && (
        <EmptyState
          icon={<CarTaxiFront size={26} />}
          title="아직 이용 기록이 없어요"
          description="모집 중인 택시팟에 참여해 보세요."
          action={
            <Link to="/home" className="btn btn--primary">
              <span>택시팟 찾기</span>
            </Link>
          }
        />
      )}
      <ul className="history">
        {list.data?.content.map((item) => (
          <li key={item.potId}>
            <Link to={`/pots/${item.potId}`} className="history__item">
              <div className="history__top">
                <PotStatusBadge status={item.potStatus} />
                <span className="history__role">
                  {item.myRole === 'HOST' ? '방장' : '동승'} · {memberStatusLabel(item.myStatus)}
                </span>
                <ChevronRight size={16} />
              </div>
              <strong className="history__title">{item.title}</strong>
              <RouteLine from={item.departureName} to={item.destinationName} />
              <div className="history__bottom">
                <span>{dayAndTime(item.departureTime)}</span>
                <Outcome item={item} />
              </div>
              {item.potStatus === 'COMPLETED' && !item.isRated && item.myStatus === 'BOARDED' && (
                <span className="history__cta">평가를 남겨 주세요</span>
              )}
            </Link>
          </li>
        ))}
      </ul>
    </Screen>
  );
}
