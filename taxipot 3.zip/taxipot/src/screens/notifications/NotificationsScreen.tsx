import { Bell, CarTaxiFront, CircleAlert, Star, UserX, Wallet } from 'lucide-react';
import { useState, type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/api';
import type { NotificationResponse, NotificationType } from '@/api/types';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { EmptyState, ErrorState, Loader } from '@/components/ui/Feedback';
import { Segmented } from '@/components/ui/Segmented';
import { useAsync } from '@/hooks/useAsync';
import { relativeTime } from '@/lib/format';
import { useToast } from '@/store/ToastContext';

const ICONS: Partial<Record<NotificationType, ReactNode>> = {
  POT: <CarTaxiFront size={18} />,
  PAYMENT: <Wallet size={18} />,
  LATE_WARNING: <CircleAlert size={18} />,
  KICKED: <UserX size={18} />,
  RATING_REQUEST: <Star size={18} />,
};

export function NotificationsScreen() {
  const navigate = useNavigate();
  const toast = useToast();
  const [unreadOnly, setUnreadOnly] = useState(false);
  const list = useAsync(() => api.notifications.list({ unreadOnly, size: 50 }), [unreadOnly]);

  async function open(item: NotificationResponse) {
    if (!item.isRead) {
      list.setData((prev) => ({
        content: (prev?.content ?? []).map((n) => (n.id === item.id ? { ...n, isRead: true } : n)),
        page: prev!.page,
      }));
      void api.notifications.read(item.id).catch(() => undefined);
    }
    if (item.type === 'RATING_REQUEST' && item.potId) navigate(`/pots/${item.potId}/rate`);
    else if (item.type === 'PAYMENT' && item.title.includes('미수금')) navigate('/wallet/debts');
    else if (item.potId) navigate(`/pots/${item.potId}`);
    else if (item.title.includes('인증')) navigate('/verify');
  }

  async function readAll() {
    try {
      await api.notifications.readAll();
      await list.reload();
    } catch (error) {
      toast.error(error);
    }
  }

  return (
    <Screen
      header={
        <PageHeader
          title="알림"
          right={
            <button type="button" className="text-btn" onClick={() => void readAll()}>
              모두 읽음
            </button>
          }
        />
      }
    >
      <div className="filters">
        <Segmented
          label="알림 필터"
          value={unreadOnly ? 'unread' : 'all'}
          onChange={(v) => setUnreadOnly(v === 'unread')}
          options={[
            { value: 'all', label: '전체' },
            { value: 'unread', label: '안 읽음' },
          ]}
        />
      </div>
      {list.loading && !list.data && <Loader />}
      {list.error ? <ErrorState error={list.error} onRetry={() => void list.reload()} /> : null}
      {list.data && list.data.content.length === 0 && (
        <EmptyState icon={<Bell size={26} />} title="새 알림이 없어요" />
      )}
      <ul className="notes">
        {list.data?.content.map((item) => (
          <li key={item.id}>
            <button
              type="button"
              className={`note ${item.isRead ? '' : 'is-unread'}`}
              onClick={() => void open(item)}
            >
              <span className={`note__icon note__icon--${item.type.toLowerCase()}`}>
                {ICONS[item.type] ?? <Bell size={18} />}
              </span>
              <span className="note__body">
                <strong>{item.title}</strong>
                <span>{item.content}</span>
                <time>{relativeTime(item.createdAt)}</time>
              </span>
            </button>
          </li>
        ))}
      </ul>
    </Screen>
  );
}
