/** 참여자 채팅 — REST 로 저장, STOMP `CHAT_MESSAGE` 로 실시간 수신, 커서 기반 이전 메시지 */
import { SendHorizontal } from 'lucide-react';
import { useCallback, useEffect, useLayoutEffect, useRef, useState, type FormEvent } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '@/api';
import type { ChatMessageResponse, PotDetailResponse, QuickBlockResponse } from '@/api/types';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { ErrorState, Loader } from '@/components/ui/Feedback';
import { usePotRealtime } from '@/hooks/usePotRealtime';
import { clock } from '@/lib/format';
import { useUser } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

function mergeMessages(list: ChatMessageResponse[], incoming: ChatMessageResponse[]) {
  const byId = new Map(list.map((m) => [m.id, m]));
  incoming.forEach((m) => byId.set(m.id, m));
  return [...byId.values()].sort((a, b) => a.id - b.id);
}

export function ChatScreen() {
  const potId = Number(useParams().potId);
  const user = useUser();
  const toast = useToast();
  const [pot, setPot] = useState<PotDetailResponse | null>(null);
  const [messages, setMessages] = useState<ChatMessageResponse[]>([]);
  const [cursor, setCursor] = useState<number | null>(null);
  const [hasNext, setHasNext] = useState(false);
  const [quick, setQuick] = useState<QuickBlockResponse[]>([]);
  const [draft, setDraft] = useState('');
  const [error, setError] = useState<unknown>(null);
  const [sending, setSending] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);
  const stickToBottom = useRef(true);

  const load = useCallback(async () => {
    try {
      const [detail, page, blocks] = await Promise.all([
        api.pots.detail(potId),
        api.chat.messages(potId),
        api.chat.quickBlocks(),
      ]);
      setPot(detail);
      setMessages(mergeMessages([], page.messages));
      setCursor(page.nextCursor);
      setHasNext(page.hasNext);
      setQuick(blocks);
    } catch (err) {
      setError(err);
    }
  }, [potId]);

  useEffect(() => {
    void load();
  }, [load]);

  usePotRealtime(potId, Boolean(pot?.isJoined), (event) => {
    if (event.type === 'CHAT_MESSAGE') {
      stickToBottom.current = true;
      setMessages((list) => mergeMessages(list, [event.payload]));
    }
    if (event.type === 'POT_UPDATED')
      void api.pots
        .detail(potId)
        .then(setPot)
        .catch(() => undefined);
  });

  useLayoutEffect(() => {
    const box = listRef.current;
    if (box && stickToBottom.current) box.scrollTop = box.scrollHeight;
  }, [messages]);

  async function loadOlder() {
    if (!cursor) return;
    stickToBottom.current = false;
    try {
      const page = await api.chat.messages(potId, cursor);
      setMessages((list) => mergeMessages(list, page.messages));
      setCursor(page.nextCursor);
      setHasNext(page.hasNext);
    } catch (err) {
      toast.error(err);
    }
  }

  async function send(content: string, msgType: 'TEXT' | 'QUICK' = 'TEXT') {
    const text = content.trim();
    if (!text || sending) return;
    setSending(true);
    try {
      const sent = await api.chat.send(potId, { content: text, msgType });
      stickToBottom.current = true;
      setMessages((list) => mergeMessages(list, [sent]));
      if (msgType === 'TEXT') setDraft('');
    } catch (err) {
      toast.error(err);
    } finally {
      setSending(false);
    }
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    void send(draft);
  }

  if (error) {
    return (
      <Screen header={<PageHeader title="채팅" />}>
        <ErrorState
          error={error}
          onRetry={() => {
            setError(null);
            void load();
          }}
        />
      </Screen>
    );
  }
  if (!pot) {
    return (
      <Screen header={<PageHeader title="채팅" />}>
        <Loader />
      </Screen>
    );
  }

  const closed = pot.status === 'COMPLETED' || pot.status === 'CANCELED';

  return (
    <div className="screen chat">
      <PageHeader title={pot.title} />
      <div className="chat__list" ref={listRef}>
        {hasNext && (
          <Button variant="ghost" size="sm" onClick={() => void loadOlder()}>
            이전 메시지 보기
          </Button>
        )}
        <p className="chat__system">
          참여자만 볼 수 있는 채팅방이에요. 계좌번호 등 개인정보는 보내지 마세요.
        </p>
        {messages.map((message, index) => {
          const mine = message.senderId === user.id;
          const prev = messages[index - 1];
          const grouped = prev && prev.senderId === message.senderId;
          return (
            <div
              key={message.id}
              className={`bubble-row ${mine ? 'is-mine' : ''} ${grouped ? 'is-grouped' : ''}`}
            >
              {!mine && !grouped && (
                <span className="bubble-row__name">{message.senderNickname}</span>
              )}
              <div className="bubble-row__line">
                <p className={`bubble ${message.msgType === 'QUICK' ? 'bubble--quick' : ''}`}>
                  {message.content}
                </p>
                <time>{clock(message.sentAt)}</time>
              </div>
            </div>
          );
        })}
      </div>
      {closed ? (
        <p className="chat__closed">종료된 택시팟이라 메시지를 보낼 수 없어요.</p>
      ) : (
        <div className="chat__composer">
          <div className="quick-row" aria-label="빠른 메시지">
            {quick.map((block) => (
              <button
                key={block.code}
                type="button"
                disabled={sending}
                onClick={() => void send(block.content, 'QUICK')}
              >
                {block.content}
              </button>
            ))}
          </div>
          <form className="chat__form" onSubmit={submit}>
            <input
              value={draft}
              maxLength={1000}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="메시지 보내기"
              aria-label="메시지"
            />
            <button
              type="submit"
              className="chat__send"
              disabled={!draft.trim() || sending}
              aria-label="보내기"
            >
              <SendHorizontal size={20} />
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
