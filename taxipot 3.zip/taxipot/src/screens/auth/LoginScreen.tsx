import { LockKeyhole, Mail } from 'lucide-react';
import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/Field';
import { Notice } from '@/components/ui/Feedback';
import { env } from '@/config/env';
import { DEMO_ACCOUNTS } from '@/mock/db';
import { useSession } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

export function LoginScreen() {
  const session = useSession();
  const toast = useToast();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(event?: FormEvent, account = { email, password }) {
    event?.preventDefault();
    if (!account.email || !account.password)
      return toast.error('이메일과 비밀번호를 입력해 주세요.');
    setBusy(true);
    try {
      const user = await session.login(account.email, account.password);
      navigate(user.role === 'ADMIN' ? '/admin' : '/home', { replace: true });
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen header={<PageHeader title="로그인" backTo="/welcome" />}>
      <form className="form-stack auth-form" onSubmit={(e) => void submit(e)}>
        <div className="auth-form__intro">
          <h2>다시 만나서 반가워요</h2>
          <p>가입한 학교 이메일로 로그인해 주세요.</p>
        </div>
        <TextField
          label="학교 이메일"
          type="email"
          autoComplete="email"
          inputMode="email"
          icon={<Mail size={18} />}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="student@bu.ac.kr"
        />
        <TextField
          label="비밀번호"
          type="password"
          autoComplete="current-password"
          icon={<LockKeyhole size={18} />}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <Button type="submit" size="lg" block loading={busy}>
          로그인
        </Button>
        <p className="auth-form__switch">
          처음이신가요? <Link to="/signup">회원가입</Link>
        </p>
        {env.isMock && (
          <Notice>
            <strong>시연 계정</strong>
            <div className="demo-accounts">
              <button type="button" onClick={() => void submit(undefined, DEMO_ACCOUNTS.student)}>
                학생 · {DEMO_ACCOUNTS.student.email}
              </button>
              <button type="button" onClick={() => void submit(undefined, DEMO_ACCOUNTS.admin)}>
                운영자 · {DEMO_ACCOUNTS.admin.email}
              </button>
            </div>
          </Notice>
        )}
      </form>
    </Screen>
  );
}
