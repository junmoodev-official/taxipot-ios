/**
 * 학생 인증: 이메일 인증코드(1차) → 학생 정보 캡처 제출(2차) → 운영자 심사.
 * 명세 3.9.0: 코드 유효 1분, 재발송 간격 60초, 입력 5회 제한.
 */
import { CheckCircle2, Hourglass, MailCheck, ShieldAlert } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/api';
import type { VerificationResponse } from '@/api/types';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/Field';
import { ErrorState, Loader, Notice } from '@/components/ui/Feedback';
import { ImagePicker } from '@/components/ui/ImagePicker';
import { env } from '@/config/env';
import { POLICY } from '@/config/policy';
import { useAsync } from '@/hooks/useAsync';
import { useNow } from '@/hooks/useNow';
import { fullDateTime } from '@/lib/format';
import { validateImage } from '@/lib/validators';
import { mockTools } from '@/mock/server';
import { useUser, useSession } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

const SENT_KEY = 'taxipot.emailCodeSentAt';

export function VerifyScreen() {
  const state = useAsync(() => api.verification.me(), []);
  const { refreshUser } = useSession();

  return (
    <Screen header={<PageHeader title="학생 인증" backTo="/home" />}>
      {state.loading && !state.data && <Loader />}
      {state.error ? <ErrorState error={state.error} onRetry={() => void state.reload()} /> : null}
      {state.data && (
        <VerifyBody
          verification={state.data}
          onChange={(next) => {
            state.setData(next);
            if (next.reviewStatus === 'APPROVED') void refreshUser();
          }}
        />
      )}
    </Screen>
  );
}

function VerifyBody({
  verification,
  onChange,
}: {
  verification: VerificationResponse;
  onChange: (v: VerificationResponse) => void;
}) {
  if (verification.emailStatus === 'PENDING') return <EmailStep onDone={onChange} />;
  if (verification.reviewStatus === 'NOT_SUBMITTED' || verification.reviewStatus === 'REJECTED') {
    return <CaptureStep verification={verification} onDone={onChange} />;
  }
  if (verification.reviewStatus === 'PENDING') return <PendingStep />;
  return <ApprovedStep />;
}

function EmailStep({ onDone }: { onDone: (v: VerificationResponse) => void }) {
  const user = useUser();
  const toast = useToast();
  const now = useNow(1000);
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [sentAt, setSentAt] = useState(() => Number(sessionStorage.getItem(SENT_KEY)) || 0);

  const resendLeft = Math.max(
    0,
    Math.ceil((sentAt + POLICY.emailResendIntervalSeconds * 1000 - now.getTime()) / 1000),
  );
  const expiresLeft = Math.max(
    0,
    Math.ceil((sentAt + POLICY.emailCodeTtlSeconds * 1000 - now.getTime()) / 1000),
  );
  const demoCode = env.isMock ? mockTools.lastEmailCode(user.email) : null;

  async function confirm() {
    if (!/^\d{6}$/.test(code)) return setError('6자리 숫자를 입력해 주세요.');
    setBusy(true);
    try {
      const result = await api.verification.confirmEmailCode({ emailCode: code });
      toast.success('이메일 인증이 끝났어요.');
      onDone(result);
    } catch (err) {
      setError(null);
      toast.error(err);
    } finally {
      setBusy(false);
    }
  }

  async function resend() {
    try {
      await api.verification.resendEmailCode();
      const at = Date.now();
      sessionStorage.setItem(SENT_KEY, String(at));
      setSentAt(at);
      setCode('');
      toast.success('새 인증코드를 보냈어요.');
    } catch (err) {
      toast.error(err);
    }
  }

  return (
    <div className="form-stack verify">
      <div className="verify__hero">
        <MailCheck size={36} />
        <h2>메일로 받은 6자리 코드를 입력해 주세요</h2>
        <p>{user.email}</p>
      </div>
      <TextField
        label="인증코드"
        inputMode="numeric"
        autoComplete="one-time-code"
        maxLength={6}
        value={code}
        onChange={(e) => {
          setCode(e.target.value.replace(/\D/g, ''));
          setError(null);
        }}
        error={error}
        className="input--code"
        hint={
          sentAt
            ? expiresLeft > 0
              ? `${expiresLeft}초 안에 입력해 주세요.`
              : '코드가 만료됐어요. 재발송해 주세요.'
            : '코드는 1분 동안 유효해요.'
        }
      />
      {demoCode && (
        <Notice>
          시연 메일함 · 인증코드 <strong>{demoCode}</strong>
        </Notice>
      )}
      <Button size="lg" block loading={busy} onClick={() => void confirm()}>
        인증하기
      </Button>
      <Button variant="ghost" block disabled={resendLeft > 0} onClick={() => void resend()}>
        {resendLeft > 0 ? `${resendLeft}초 후 재발송할 수 있어요` : '인증코드 다시 받기'}
      </Button>
    </div>
  );
}

function CaptureStep({
  verification,
  onDone,
}: {
  verification: VerificationResponse;
  onDone: (v: VerificationResponse) => void;
}) {
  const user = useUser();
  const toast = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [studentNo, setStudentNo] = useState(user.studentNo);
  const [busy, setBusy] = useState(false);

  async function submit() {
    const err = validateImage(file);
    if (err) return setFileError(err);
    if (studentNo.trim() !== user.studentNo)
      return toast.error('가입할 때 입력한 학번과 같아야 해요.');
    setBusy(true);
    try {
      onDone(await api.verification.submitCapture(file!, studentNo.trim()));
      toast.success('캡처본을 제출했어요. 심사가 끝나면 알려드릴게요.');
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="form-stack">
      {verification.reviewStatus === 'REJECTED' && (
        <Notice tone="danger" icon={<ShieldAlert size={18} />}>
          <strong>심사가 반려됐어요</strong>
          <p>사유: {verification.rejectReason}</p>
        </Notice>
      )}
      <div className="verify__hero verify__hero--left">
        <h2>학생 정보 화면을 캡처해 올려 주세요</h2>
        <p>
          종합정보시스템의 학생 기본 정보(학번·학적·성별)가 보이게 캡처해 주세요. 운영자만 확인해요.
        </p>
      </div>
      <ImagePicker
        label="학생 정보 캡처"
        hint="jpg·png, 10MB 이하"
        file={file}
        error={fileError}
        onChange={(next, err) => {
          setFile(next);
          setFileError(err);
        }}
      />
      <TextField
        label="학번"
        value={studentNo}
        onChange={(e) => setStudentNo(e.target.value)}
        inputMode="numeric"
      />
      <Button size="lg" block loading={busy} onClick={() => void submit()}>
        {verification.reviewStatus === 'REJECTED' ? '다시 제출하기' : '제출하기'}
      </Button>
    </div>
  );
}

function PendingStep() {
  const navigate = useNavigate();
  return (
    <div className="verify__hero verify__hero--status">
      <Hourglass size={40} />
      <h2>운영자가 캡처본을 확인하고 있어요</h2>
      <p>심사가 끝나면 알림으로 알려드려요. 그동안 모집 중인 택시팟을 둘러볼 수 있어요.</p>
      <Button variant="secondary" onClick={() => navigate('/home')}>
        택시팟 둘러보기
      </Button>
    </div>
  );
}

function ApprovedStep() {
  const navigate = useNavigate();
  const user = useUser();
  const go = useCallback(() => navigate('/home', { replace: true }), [navigate]);
  useEffect(() => {
    if (!user.isVerified) return;
    const timer = window.setTimeout(go, 2500);
    return () => window.clearTimeout(timer);
  }, [user.isVerified, go]);
  return (
    <div className="verify__hero verify__hero--status">
      <CheckCircle2 size={40} className="text-success" />
      <h2>학생 인증이 끝났어요</h2>
      <p>{fullDateTime(user.updatedAt)} 기준 · 이제 택시팟을 만들고 참여할 수 있어요.</p>
      <Button onClick={go}>시작하기</Button>
    </div>
  );
}
