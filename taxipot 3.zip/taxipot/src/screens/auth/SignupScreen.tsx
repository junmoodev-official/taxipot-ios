/** 회원가입 4단계: 학교·계정 → 본인 정보 → 출금 계좌 → 약관 */
import { Building2, CreditCard, LockKeyhole, Mail, Phone, UserRound } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/api';
import type { BankResponse, Gender, UniversityResponse } from '@/api/types';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { Checkbox, SelectField, TextField } from '@/components/ui/Field';
import { Notice } from '@/components/ui/Feedback';
import { Segmented } from '@/components/ui/Segmented';
import * as V from '@/lib/validators';
import { useSession } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

const STEPS = ['학교·계정', '본인 정보', '출금 계좌', '약관 동의'] as const;

interface Form {
  university: string;
  email: string;
  password: string;
  passwordConfirm: string;
  name: string;
  nickname: string;
  gender: Gender;
  phone: string;
  studentNo: string;
  bankCode: string;
  accountNumber: string;
  agreeRequired: boolean;
  agreeMarketing: boolean;
}

const INITIAL: Form = {
  university: '',
  email: '',
  password: '',
  passwordConfirm: '',
  name: '',
  nickname: '',
  gender: 'M',
  phone: '',
  studentNo: '',
  bankCode: '',
  accountNumber: '',
  agreeRequired: false,
  agreeMarketing: false,
};

export function SignupScreen() {
  const navigate = useNavigate();
  const session = useSession();
  const toast = useToast();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<Form>(INITIAL);
  const [errors, setErrors] = useState<Partial<Record<keyof Form, string | null>>>({});
  const [universities, setUniversities] = useState<UniversityResponse[]>([]);
  const [banks, setBanks] = useState<BankResponse[]>([]);
  const [nicknameOk, setNicknameOk] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void Promise.all([api.auth.universities(), api.auth.banks()])
      .then(([u, b]) => {
        setUniversities(u);
        setBanks(b);
      })
      .catch(toast.error);
  }, [toast.error]);

  const domain = universities.find((u) => u.name === form.university)?.emailDomain;
  const set = <K extends keyof Form>(key: K, value: Form[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: null }));
    if (key === 'nickname') setNicknameOk(null);
  };

  function validate(current: number): boolean {
    const next: typeof errors = {};
    if (current === 0) {
      next.university = form.university ? null : '학교를 선택해 주세요.';
      next.email = V.validateSchoolEmail(form.email, domain);
      next.password = V.validatePassword(form.password);
      next.passwordConfirm =
        form.password === form.passwordConfirm ? null : '비밀번호가 서로 달라요.';
    }
    if (current === 1) {
      next.name = V.validateName(form.name);
      next.nickname =
        V.validateNickname(form.nickname) ??
        (nicknameOk === form.nickname ? null : '닉네임 중복 확인을 해 주세요.');
      next.phone = V.validatePhone(form.phone);
      next.studentNo = V.validateStudentNo(form.studentNo);
    }
    if (current === 2) {
      next.bankCode = form.bankCode ? null : '은행을 선택해 주세요.';
      next.accountNumber = V.validateAccountNumber(form.accountNumber);
    }
    if (current === 3) {
      next.agreeRequired = form.agreeRequired ? null : '필수 약관에 동의해야 가입할 수 있어요.';
    }
    setErrors(next);
    return Object.values(next).every((value) => !value);
  }

  async function checkNickname() {
    const local = V.validateNickname(form.nickname);
    if (local) return setErrors((e) => ({ ...e, nickname: local }));
    try {
      const result = await api.auth.checkNickname(form.nickname.trim());
      if (result.available) {
        setNicknameOk(form.nickname);
        toast.success('사용할 수 있는 닉네임이에요.');
      } else {
        setErrors((e) => ({
          ...e,
          nickname:
            result.reason === 'RESERVED'
              ? '이후 사용할 수 없는 닉네임입니다.'
              : '이미 사용 중인 닉네임이에요.',
        }));
      }
    } catch (error) {
      toast.error(error);
    }
  }

  async function next() {
    if (!validate(step)) return;
    if (step < STEPS.length - 1) return setStep(step + 1);
    setBusy(true);
    try {
      await session.signup({
        email: form.email.trim().toLowerCase(),
        password: form.password,
        name: form.name.trim(),
        nickname: form.nickname.trim(),
        phone: form.phone.trim(),
        gender: form.gender,
        university: form.university,
        studentNo: form.studentNo.trim(),
        bankCode: form.bankCode,
        accountNumber: V.digitsOnly(form.accountNumber),
        accountHolder: form.name.trim(),
        agreeRequired: form.agreeRequired,
        agreeMarketing: form.agreeMarketing,
      });
      sessionStorage.setItem('taxipot.emailCodeSentAt', String(Date.now()));
      toast.success(`${form.email}로 인증코드를 보냈어요.`);
      navigate('/verify', { replace: true });
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen
      header={<PageHeader title="회원가입" backTo={step === 0 ? '/welcome' : undefined} />}
      footer={
        <div className="footer-actions">
          {step > 0 && (
            <Button variant="secondary" size="lg" onClick={() => setStep(step - 1)} disabled={busy}>
              이전
            </Button>
          )}
          <Button size="lg" block onClick={() => void next()} loading={busy}>
            {step === STEPS.length - 1 ? '가입하고 인증코드 받기' : '다음'}
          </Button>
        </div>
      }
    >
      <ol className="stepper" aria-label="가입 단계">
        {STEPS.map((label, index) => (
          <li key={label} className={index === step ? 'is-current' : index < step ? 'is-done' : ''}>
            <span>{index + 1}</span>
            {label}
          </li>
        ))}
      </ol>

      <div className="form-stack">
        {step === 0 && (
          <>
            <SelectField
              label="학교"
              icon={<Building2 size={18} />}
              value={form.university}
              onChange={(e) => set('university', e.target.value)}
              error={errors.university}
            >
              <option value="">학교를 선택해 주세요</option>
              {universities.map((u) => (
                <option key={u.id} value={u.name}>
                  {u.name}
                </option>
              ))}
            </SelectField>
            <TextField
              label="학교 이메일"
              type="email"
              inputMode="email"
              autoComplete="email"
              icon={<Mail size={18} />}
              placeholder={domain ? `학번@${domain}` : '학교를 먼저 선택해 주세요'}
              value={form.email}
              onChange={(e) => set('email', e.target.value)}
              error={errors.email}
              hint={domain ? `@${domain} 주소로 인증코드를 보내요.` : undefined}
            />
            <TextField
              label="비밀번호"
              type="password"
              autoComplete="new-password"
              icon={<LockKeyhole size={18} />}
              value={form.password}
              onChange={(e) => set('password', e.target.value)}
              error={errors.password}
              hint="영문과 숫자를 섞어 8자 이상"
            />
            <TextField
              label="비밀번호 확인"
              type="password"
              autoComplete="new-password"
              icon={<LockKeyhole size={18} />}
              value={form.passwordConfirm}
              onChange={(e) => set('passwordConfirm', e.target.value)}
              error={errors.passwordConfirm}
            />
          </>
        )}

        {step === 1 && (
          <>
            <TextField
              label="이름 (실명)"
              autoComplete="name"
              icon={<UserRound size={18} />}
              value={form.name}
              onChange={(e) => set('name', e.target.value)}
              error={errors.name}
              hint="학생 정보 캡처와 출금 계좌 예금주 확인에 사용해요."
            />
            <TextField
              label="닉네임"
              value={form.nickname}
              maxLength={30}
              onChange={(e) => set('nickname', e.target.value)}
              error={errors.nickname}
              hint={
                nicknameOk === form.nickname && form.nickname
                  ? '사용할 수 있는 닉네임이에요.'
                  : '동승자에게 보이는 이름이에요.'
              }
              suffix={
                <button type="button" className="text-btn" onClick={() => void checkNickname()}>
                  중복 확인
                </button>
              }
            />
            <div className="field">
              <span className="field__label">성별</span>
              <Segmented
                label="성별"
                value={form.gender}
                onChange={(v) => set('gender', v)}
                options={[
                  { value: 'M', label: '남성' },
                  { value: 'F', label: '여성' },
                ]}
              />
            </div>
            <TextField
              label="휴대폰 번호"
              type="tel"
              inputMode="tel"
              autoComplete="tel"
              icon={<Phone size={18} />}
              placeholder="010-1234-5678"
              value={form.phone}
              onChange={(e) => set('phone', e.target.value)}
              error={errors.phone}
            />
            <TextField
              label="학번"
              inputMode="numeric"
              value={form.studentNo}
              maxLength={20}
              onChange={(e) => set('studentNo', e.target.value)}
              error={errors.studentNo}
              hint="학생 정보 캡처의 학번과 같아야 승인돼요."
            />
          </>
        )}

        {step === 2 && (
          <>
            <Notice>
              정산금과 남은 잔액을 돌려받을 본인 명의 계좌예요. 예금주는 가입 이름과 같아야 해요.
            </Notice>
            <SelectField
              label="은행"
              value={form.bankCode}
              onChange={(e) => set('bankCode', e.target.value)}
              error={errors.bankCode}
            >
              <option value="">은행을 선택해 주세요</option>
              {banks.map((bank) => (
                <option key={bank.code} value={bank.code}>
                  {bank.name}
                </option>
              ))}
            </SelectField>
            <TextField
              label="계좌번호"
              inputMode="numeric"
              icon={<CreditCard size={18} />}
              placeholder="숫자만 입력"
              value={form.accountNumber}
              onChange={(e) => set('accountNumber', e.target.value.replace(/[^\d-]/g, ''))}
              error={errors.accountNumber}
            />
            <TextField
              label="예금주"
              value={form.name}
              readOnly
              hint="가입 이름으로 자동 입력돼요."
            />
          </>
        )}

        {step === 3 && (
          <>
            <section className="terms">
              <h3>꼭 확인해 주세요</h3>
              <ul>
                <li>
                  택시팟에 참여하면 1인 예상 분담금의 1.2배와 수수료 1,000원이 지갑에서 예치돼요.
                  정산 후 남는 금액은 돌려드려요.
                </li>
                <li>
                  출발 10분 전부터는 참여를 취소할 수 없고, 출발 5분 전까지 출발지에서 도착을
                  확인하지 않으면 퇴장되며 15분 동안 이용이 제한돼요.
                </li>
                <li>
                  정산 때 잔액이 부족하면 미수금이 생기고, 3일 안에 납부하지 않으면 미납액의 10배
                  청구 등 법적 조치가 진행될 수 있어요.
                </li>
                <li>
                  탈퇴하면 지갑에 남은 잔액은 소멸되며 환불되지 않아요. 탈퇴 전에 출금해 주세요.
                </li>
                <li>
                  학번은 다른 사용자에게 공개되지 않고, 학생 정보 캡처는 심사 후 정책에 따라
                  파기돼요.
                </li>
              </ul>
            </section>
            <Checkbox
              checked={form.agreeRequired}
              onChange={(e) => set('agreeRequired', e.target.checked)}
            >
              <strong>[필수]</strong> 이용약관, 개인정보 수집·이용, 위 안내 사항에 동의해요.
            </Checkbox>
            {errors.agreeRequired && (
              <p className="field__message field__message--error">{errors.agreeRequired}</p>
            )}
            <Checkbox
              checked={form.agreeMarketing}
              onChange={(e) => set('agreeMarketing', e.target.checked)}
            >
              [선택] 이벤트·혜택 알림을 받을게요.
            </Checkbox>
          </>
        )}
      </div>
    </Screen>
  );
}
