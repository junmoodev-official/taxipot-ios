import { Link } from 'react-router-dom';
import { Brand } from '@/components/layout/Brand';

export function WelcomeScreen() {
  return (
    <div className="screen welcome">
      <div className="welcome__top">
        <Brand />
      </div>
      <div className="welcome__art" aria-hidden="true">
        <svg viewBox="0 0 320 220">
          <rect x="0" y="150" width="320" height="70" rx="0" className="welcome__road" />
          <path d="M20 186h40M100 186h40M180 186h40M260 186h40" className="welcome__lane" />
          <g className="welcome__taxi">
            <rect x="128" y="56" width="64" height="18" rx="6" className="welcome__roof" />
            <text x="160" y="69" textAnchor="middle">
              TAXI
            </text>
            <path
              d="M70 140h180l-22-50a18 18 0 0 0-16-10h-104a18 18 0 0 0-16 10z"
              className="welcome__body"
            />
            <rect x="58" y="132" width="204" height="34" rx="14" className="welcome__body" />
            <path d="M104 88h48v44H86zM168 88h48l18 44h-66z" className="welcome__window" />
            <circle cx="104" cy="168" r="18" className="welcome__wheel" />
            <circle cx="216" cy="168" r="18" className="welcome__wheel" />
          </g>
        </svg>
      </div>
      <div className="welcome__copy">
        <h1>
          같은 방향이면,
          <br />
          택시비는 반으로.
        </h1>
        <p>학교 인증을 마친 학생끼리 모여 타고, 요금은 지갑 예치금으로 자동 정산해요.</p>
      </div>
      <div className="welcome__actions">
        <Link to="/signup" className="btn btn--primary btn--lg btn--block">
          <span>학교 이메일로 시작하기</span>
        </Link>
        <Link to="/login" className="btn btn--ghost btn--lg btn--block">
          <span>이미 계정이 있어요</span>
        </Link>
      </div>
    </div>
  );
}
