import type { ReactNode } from 'react';
import { EmptyState, ErrorState, Loader } from '@/components/ui/Feedback';
import { Inbox } from 'lucide-react';

interface Column<Row> {
  header: string;
  cell: (row: Row) => ReactNode;
  align?: 'right';
}

interface AdminTableProps<Row> {
  rows: Row[] | undefined;
  columns: Column<Row>[];
  rowKey: (row: Row) => string | number;
  loading: boolean;
  error: unknown;
  onRetry: () => void;
  onRowClick?: (row: Row) => void;
  selected?: string | number | null;
  empty: string;
}

export function AdminTable<Row>({
  rows,
  columns,
  rowKey,
  loading,
  error,
  onRetry,
  onRowClick,
  selected,
  empty,
}: AdminTableProps<Row>) {
  if (error) return <ErrorState error={error} onRetry={onRetry} />;
  if (loading && !rows) return <Loader />;
  if (!rows || rows.length === 0) return <EmptyState icon={<Inbox size={24} />} title={empty} />;
  return (
    <div className="table-wrap">
      <table className="table">
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.header} className={c.align === 'right' ? 'is-right' : ''}>
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr
              key={rowKey(row)}
              className={`${onRowClick ? 'is-clickable' : ''} ${selected === rowKey(row) ? 'is-selected' : ''}`}
              onClick={() => onRowClick?.(row)}
            >
              {columns.map((c) => (
                <td key={c.header} className={c.align === 'right' ? 'is-right' : ''}>
                  {c.cell(row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
