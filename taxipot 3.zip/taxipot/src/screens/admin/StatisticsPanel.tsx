import { api } from '@/api';
import { ErrorState, Loader } from '@/components/ui/Feedback';
import { PotStatusBadge } from '@/components/pot/PotStatusBadge';
import { useAsync } from '@/hooks/useAsync';
import { dayAndTime, won } from '@/lib/format';
import { AdminTable } from './AdminTable';

export function StatisticsPanel() {
  const stats = useAsync(() => api.admin.statistics({ limit: 5 }), []);
  const pots = useAsync(() => api.admin.pots({ size: 20 }), []);

  if (stats.error) return <ErrorState error={stats.error} onRetry={() => void stats.reload()} />;
  if (!stats.data) return <Loader />;
  const s = stats.data;
  const peak = Math.max(1, ...s.hourlyTraffic.map((h) => h.potCount));

  return (
    <div className="stats">
      <div className="stats__cards">
        <div>
          <span>전체 택시팟 (30일)</span>
          <strong>{s.totalPots}</strong>
        </div>
        <div>
          <span>정산 완료</span>
          <strong>{s.completedPots}</strong>
        </div>
        <div>
          <span>취소</span>
          <strong>{s.canceledPots}</strong>
        </div>
      </div>
      <div className="stats__grid">
        <section className="panel">
          <h3 className="panel__title">주요 출발지</h3>
          <ol className="rank">
            {s.topDepartures.map((r) => (
              <li key={r.name}>
                <span>{r.name}</span>
                <strong>{r.count}</strong>
              </li>
            ))}
          </ol>
        </section>
        <section className="panel">
          <h3 className="panel__title">선호 목적지</h3>
          <ol className="rank">
            {s.topDestinations.map((r) => (
              <li key={r.name}>
                <span>{r.name}</span>
                <strong>{r.count}</strong>
              </li>
            ))}
          </ol>
        </section>
      </div>
      <section className="panel">
        <h3 className="panel__title">시간대별 출발</h3>
        <div className="bars" role="img" aria-label="시간대별 택시팟 수">
          {s.hourlyTraffic.map((h) => (
            <span key={h.hour} title={`${h.hour}시 ${h.potCount}건`}>
              <i style={{ height: `${(h.potCount / peak) * 100}%` }} />
              <small>{h.hour % 3 === 0 ? h.hour : ''}</small>
            </span>
          ))}
        </div>
      </section>
      <section className="panel">
        <h3 className="panel__title">최근 택시팟</h3>
        <AdminTable
          rows={pots.data?.content}
          loading={pots.loading}
          error={pots.error}
          onRetry={() => void pots.reload()}
          rowKey={(r) => r.id}
          empty="기록이 없어요"
          columns={[
            { header: '출발', cell: (r) => dayAndTime(r.departureTime) },
            { header: '경로', cell: (r) => `${r.departureName} → ${r.destinationName}` },
            { header: '방장', cell: (r) => r.hostNickname },
            { header: '인원', cell: (r) => `${r.currentMembers}/${r.maxMembers}` },
            { header: '예상 요금', cell: (r) => won(r.expectedFare), align: 'right' },
            { header: '상태', cell: (r) => <PotStatusBadge status={r.status} /> },
          ]}
        />
      </section>
    </div>
  );
}
