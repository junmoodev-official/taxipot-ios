/** 운영자 웹 (role = ADMIN) — 데스크톱 화면 기준 */
import { BarChart3, FileWarning, LogOut, ReceiptText, ShieldCheck, Users } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Brand } from '@/components/layout/Brand';
import { env } from '@/config/env';
import { useSession } from '@/store/SessionContext';
import { FareClaimsPanel } from './FareClaimsPanel';
import { ReportsPanel } from './ReportsPanel';
import { StatisticsPanel } from './StatisticsPanel';
import { UsersPanel } from './UsersPanel';
import { VerificationsPanel } from './VerificationsPanel';

const TABS = [
  { id: 'verifications', label: '학생 인증 심사', icon: ShieldCheck, Panel: VerificationsPanel },
  { id: 'fare-claims', label: '실요금 청구', icon: ReceiptText, Panel: FareClaimsPanel },
  { id: 'users', label: '회원·지갑', icon: Users, Panel: UsersPanel },
  { id: 'reports', label: '신고', icon: FileWarning, Panel: ReportsPanel },
  { id: 'statistics', label: '이용 현황', icon: BarChart3, Panel: StatisticsPanel },
] as const;

type TabId = (typeof TABS)[number]['id'];

export function AdminConsole() {
  const session = useSession();
  const navigate = useNavigate();
  const [tab, setTab] = useState<TabId>(() => {
    const hash = window.location.hash.slice(1);
    return (TABS.find((t) => t.id === hash)?.id ?? 'verifications') as TabId;
  });
  const active = TABS.find((t) => t.id === tab)!;

  function select(id: TabId) {
    setTab(id);
    window.history.replaceState(null, '', `#${id}`);
  }

  return (
    <div className="admin">
      <aside className="admin__nav">
        <Brand />
        <p className="admin__role">운영자 콘솔{env.isMock ? ' · 시연 모드' : ''}</p>
        <nav>
          {TABS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              className={tab === id ? 'is-active' : ''}
              onClick={() => select(id)}
            >
              <Icon size={18} /> {label}
            </button>
          ))}
        </nav>
        <button
          type="button"
          className="admin__logout"
          onClick={() => void session.logout().then(() => navigate('/welcome', { replace: true }))}
        >
          <LogOut size={16} /> 로그아웃
        </button>
      </aside>
      <main className="admin__main">
        <h1>{active.label}</h1>
        <active.Panel />
      </main>
    </div>
  );
}
