import { useState } from 'react';
import { api } from '@/api';
import type { AdminUserResponse } from '@/api/types';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/Field';
import { Badge, InfoRow, Loader } from '@/components/ui/Feedback';
import { useAsync } from '@/hooks/useAsync';
import { fullDateTime, rating, signedWon, won } from '@/lib/format';
import { potStatusLabel, userStatusLabel } from '@/lib/labels';
import { addDays, toKstIso } from '@/lib/time';
import { useToast } from '@/store/ToastContext';
import { AdminTable } from './AdminTable';

export function UsersPanel() {
  const toast = useToast();
  const [keyword, setKeyword] = useState('');
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [amount, setAmount] = useState('10000');
  const [busy, setBusy] = useState(false);
  const list = useAsync(
    () => api.admin.users({ keyword: search || undefined, size: 50 }),
    [search],
  );
  const detail = useAsync(
    () => (selectedId ? api.admin.user(selectedId) : Promise.resolve(null)),
    [selectedId],
  );

  async function run(task: () => Promise<unknown>, message: string) {
    setBusy(true);
    try {
      await task();
      toast.success(message);
      await Promise.all([detail.reload(), list.reload()]);
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  const value = Number(amount.replace(/[^\d-]/g, '')) || 0;
  const user = detail.data;

  return (
    <div className="admin-split">
      <div>
        <form
          className="admin-search"
          onSubmit={(e) => {
            e.preventDefault();
            setSearch(keyword.trim());
          }}
        >
          <TextField
            placeholder="이름·닉네임·이메일·학번"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            aria-label="회원 검색"
          />
          <Button type="submit" variant="secondary">
            검색
          </Button>
        </form>
        <AdminTable<AdminUserResponse>
          rows={list.data?.content}
          loading={list.loading}
          error={list.error}
          onRetry={() => void list.reload()}
          rowKey={(r) => r.id}
          selected={selectedId}
          onRowClick={(r) => setSelectedId(r.id)}
          empty="회원이 없어요"
          columns={[
            { header: '닉네임', cell: (r) => r.nickname },
            { header: '이름', cell: (r) => r.name ?? '-' },
            { header: '학교', cell: (r) => r.university },
            { header: '인증', cell: (r) => (r.isVerified ? '완료' : '미완료') },
            { header: '평점', cell: (r) => rating(r.ratingAvg), align: 'right' },
            {
              header: '상태',
              cell: (r) => (
                <Badge tone={r.status === 'ACTIVE' ? 'success' : 'danger'}>
                  {userStatusLabel(r.status)}
                </Badge>
              ),
            },
          ]}
        />
      </div>
      {selectedId && (
        <aside className="admin-detail">
          {!user ? (
            <Loader />
          ) : (
            <>
              <h2>
                {user.nickname} <small>{user.role === 'ADMIN' ? '운영자' : ''}</small>
              </h2>
              <dl>
                <InfoRow label="이메일">{user.email}</InfoRow>
                <InfoRow label="학번">{user.studentNo}</InfoRow>
                <InfoRow label="노쇼 / 신고">
                  {user.noShowCount}회 / {user.reportCount}회
                </InfoRow>
                <InfoRow label="정지">
                  {user.status === 'SUSPENDED'
                    ? user.suspendedUntil
                      ? `${fullDateTime(user.suspendedUntil)}까지`
                      : '영구'
                    : '없음'}
                </InfoRow>
                <InfoRow label="잔액" strong>
                  {won(user.walletBalance)}
                </InfoRow>
                <InfoRow label="예치 중">{won(user.heldBalance)}</InfoRow>
                <InfoRow label="미수금">{won(user.debtAmount)}</InfoRow>
              </dl>

              <h3>지갑 잔액 조정 (시연 충전)</h3>
              <div className="admin-inline">
                <TextField
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  inputMode="numeric"
                  aria-label="조정 금액"
                  hint="음수는 차감 · ±500,000원"
                />
                <Button
                  loading={busy}
                  disabled={!value}
                  onClick={() =>
                    void run(
                      () => api.admin.adjustWallet(user.id, { amount: value }),
                      `${signedWon(value)} 조정했어요.`,
                    )
                  }
                >
                  조정
                </Button>
              </div>

              {user.role !== 'ADMIN' && user.status !== 'WITHDRAWN' && (
                <>
                  <h3>이용 정지</h3>
                  <div className="admin-inline admin-inline--wrap">
                    <Button
                      size="sm"
                      variant="secondary"
                      loading={busy}
                      onClick={() =>
                        void run(
                          () =>
                            api.admin.updateUserStatus(user.id, {
                              status: 'SUSPENDED',
                              suspendedUntil: toKstIso(addDays(new Date(), 3)),
                            }),
                          '3일 정지했어요.',
                        )
                      }
                    >
                      3일 정지
                    </Button>
                    <Button
                      size="sm"
                      variant="danger"
                      loading={busy}
                      onClick={() =>
                        void run(
                          () =>
                            api.admin.updateUserStatus(user.id, {
                              status: 'SUSPENDED',
                              suspendedUntil: null,
                            }),
                          '영구 정지했어요.',
                        )
                      }
                    >
                      영구 정지
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      loading={busy}
                      onClick={() =>
                        void run(
                          () => api.admin.updateUserStatus(user.id, { status: 'ACTIVE' }),
                          '정지를 해제했어요.',
                        )
                      }
                    >
                      정지 해제
                    </Button>
                  </div>
                </>
              )}

              <h3>최근 이용</h3>
              <ul className="settle-list">
                {user.potHistory.map((h) => (
                  <li key={h.potId}>
                    <span>{h.title}</span>
                    <Badge>{potStatusLabel(h.potStatus)}</Badge>
                    <strong>{h.fareShare === null ? won(h.heldAmount) : won(h.fareShare)}</strong>
                  </li>
                ))}
                {user.potHistory.length === 0 && <li>이용 기록 없음</li>}
              </ul>
            </>
          )}
        </aside>
      )}
    </div>
  );
}
