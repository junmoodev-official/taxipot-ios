import { useState } from 'react';
import { api } from '@/api';
import type { ReportStatus } from '@/api/types';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Feedback';
import { Segmented } from '@/components/ui/Segmented';
import { useAsync } from '@/hooks/useAsync';
import { fullDateTime } from '@/lib/format';
import { reportStatusLabel, reportTypeLabel } from '@/lib/labels';
import { useToast } from '@/store/ToastContext';
import { AdminTable } from './AdminTable';

export function ReportsPanel() {
  const toast = useToast();
  const [status, setStatus] = useState<ReportStatus>('PENDING');
  const [busyId, setBusyId] = useState<number | null>(null);
  const list = useAsync(() => api.admin.reports({ status, size: 50 }), [status]);

  async function process(id: number, decision: 'APPROVED' | 'REJECTED') {
    setBusyId(id);
    try {
      await api.admin.processReport(id, { status: decision });
      toast.success(
        decision === 'APPROVED' ? '승인했어요. 피신고자 신고 누적에 반영돼요.' : '반려했어요.',
      );
      await list.reload();
    } catch (error) {
      toast.error(error);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <Segmented
        label="처리 상태"
        value={status}
        onChange={setStatus}
        options={(['PENDING', 'APPROVED', 'REJECTED'] as const).map((v) => ({
          value: v,
          label: reportStatusLabel(v),
        }))}
      />
      <AdminTable
        rows={list.data?.content}
        loading={list.loading}
        error={list.error}
        onRetry={() => void list.reload()}
        rowKey={(r) => r.id}
        empty="처리할 신고가 없어요"
        columns={[
          { header: '방', cell: (r) => r.potTitle },
          { header: '신고자', cell: (r) => r.reporterNickname },
          {
            header: '피신고자 (누적)',
            cell: (r) => `${r.reportedNickname} (${r.reportedReportCount})`,
          },
          {
            header: '유형',
            cell: (r) => (
              <Badge tone={r.type === 'NO_SHOW' ? 'amber' : 'neutral'}>
                {reportTypeLabel(r.type)}
              </Badge>
            ),
          },
          { header: '내용', cell: (r) => <span className="table__text">{r.reason}</span> },
          { header: '접수', cell: (r) => fullDateTime(r.createdAt) },
          {
            header: '처리',
            cell: (r) =>
              r.status === 'PENDING' ? (
                <span className="admin-inline">
                  <Button
                    size="sm"
                    variant="secondary"
                    loading={busyId === r.id}
                    onClick={() => void process(r.id, 'REJECTED')}
                  >
                    반려
                  </Button>
                  <Button
                    size="sm"
                    loading={busyId === r.id}
                    onClick={() => void process(r.id, 'APPROVED')}
                  >
                    승인
                  </Button>
                </span>
              ) : (
                reportStatusLabel(r.status)
              ),
          },
        ]}
      />
    </div>
  );
}
