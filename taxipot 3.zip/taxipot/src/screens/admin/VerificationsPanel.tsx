import { useCallback, useState } from 'react';
import { api } from '@/api';
import type { AdminVerificationResponse, ReviewStatus } from '@/api/types';
import { AuthImage } from '@/components/ui/AuthImage';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/Field';
import { Badge, InfoRow } from '@/components/ui/Feedback';
import { Segmented } from '@/components/ui/Segmented';
import { useAsync } from '@/hooks/useAsync';
import { fullDateTime } from '@/lib/format';
import { reviewStatusLabel } from '@/lib/labels';
import { useToast } from '@/store/ToastContext';
import { AdminTable } from './AdminTable';

export function VerificationsPanel() {
  const toast = useToast();
  const [status, setStatus] = useState<ReviewStatus>('PENDING');
  const [selected, setSelected] = useState<AdminVerificationResponse | null>(null);
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const list = useAsync(
    () => api.admin.verifications({ reviewStatus: status, size: 50 }),
    [status],
  );
  const loadCapture = useCallback(() => api.admin.verificationCapture(selected!.id), [selected]);

  async function review(decision: 'APPROVED' | 'REJECTED') {
    if (!selected) return;
    if (decision === 'REJECTED' && !reason.trim()) return toast.error('반려 사유를 입력해 주세요.');
    setBusy(true);
    try {
      await api.admin.reviewVerification(selected.id, {
        reviewStatus: decision,
        rejectReason: decision === 'REJECTED' ? reason.trim() : undefined,
      });
      toast.success(
        decision === 'APPROVED' ? `${selected.memberName}님 인증을 승인했어요.` : '반려했어요.',
      );
      setSelected(null);
      setReason('');
      await list.reload();
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  const studentNoMatches = selected && selected.registeredStudentNo === selected.submittedStudentNo;

  return (
    <div className="admin-split">
      <div>
        <Segmented
          label="심사 상태"
          value={status}
          onChange={(v) => {
            setStatus(v);
            setSelected(null);
          }}
          options={(['PENDING', 'NOT_SUBMITTED', 'APPROVED', 'REJECTED'] as const).map((v) => ({
            value: v,
            label: reviewStatusLabel(v),
          }))}
        />
        <AdminTable
          rows={list.data?.content}
          loading={list.loading}
          error={list.error}
          onRetry={() => void list.reload()}
          rowKey={(r) => r.id}
          selected={selected?.id}
          onRowClick={setSelected}
          empty="심사할 건이 없어요"
          columns={[
            { header: '이름', cell: (r) => r.memberName },
            { header: '학교', cell: (r) => r.university },
            { header: '가입 학번', cell: (r) => r.registeredStudentNo },
            { header: '제출 학번', cell: (r) => r.submittedStudentNo },
            { header: '제출', cell: (r) => fullDateTime(r.createdAt) },
            {
              header: '상태',
              cell: (r) => (
                <Badge tone={r.reviewStatus === 'PENDING' ? 'brand' : 'neutral'}>
                  {reviewStatusLabel(r.reviewStatus)}
                </Badge>
              ),
            },
          ]}
        />
      </div>
      {selected && (
        <aside className="admin-detail">
          <h2>{selected.memberName}</h2>
          <dl>
            <InfoRow label="성별">{selected.memberGender === 'M' ? '남' : '여'}</InfoRow>
            <InfoRow label="이메일">{selected.email}</InfoRow>
            <InfoRow label="학번 일치">{studentNoMatches ? '일치' : '불일치'}</InfoRow>
          </dl>
          {selected.captureImgUrl ? (
            <AuthImage key={selected.id} load={loadCapture} alt="학생 정보 캡처" />
          ) : (
            <p className="screen-note">캡처 미제출</p>
          )}
          {selected.reviewStatus === 'PENDING' && (
            <>
              <TextField
                label="반려 사유 (반려 시 필수)"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                maxLength={255}
              />
              <div className="footer-actions">
                <Button variant="secondary" loading={busy} onClick={() => void review('REJECTED')}>
                  반려
                </Button>
                <Button
                  block
                  loading={busy}
                  disabled={!studentNoMatches}
                  onClick={() => void review('APPROVED')}
                >
                  승인
                </Button>
              </div>
            </>
          )}
        </aside>
      )}
    </div>
  );
}
