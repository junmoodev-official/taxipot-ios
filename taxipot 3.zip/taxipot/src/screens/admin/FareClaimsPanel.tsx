import { useCallback, useState } from 'react';
import { api } from '@/api';
import type { FareClaimResponse, FareClaimStatus } from '@/api/types';
import { AuthImage } from '@/components/ui/AuthImage';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/Field';
import { Badge, InfoRow, Notice } from '@/components/ui/Feedback';
import { Segmented } from '@/components/ui/Segmented';
import { useAsync } from '@/hooks/useAsync';
import { fullDateTime, won } from '@/lib/format';
import { fareClaimLabel } from '@/lib/labels';
import { useToast } from '@/store/ToastContext';
import { AdminTable } from './AdminTable';

export function FareClaimsPanel() {
  const toast = useToast();
  const [status, setStatus] = useState<FareClaimStatus>('PENDING');
  const [selected, setSelected] = useState<FareClaimResponse | null>(null);
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const list = useAsync(
    () => api.admin.fareClaims({ fareClaimStatus: status, size: 50 }),
    [status],
  );
  const loadReceipt = useCallback(() => api.admin.receipt(selected!.potId), [selected]);

  async function review(decision: 'APPROVED' | 'REJECTED') {
    if (!selected) return;
    if (decision === 'REJECTED' && !reason.trim()) return toast.error('반려 사유를 입력해 주세요.');
    setBusy(true);
    try {
      await api.admin.reviewFareClaim(selected.potId, {
        decision,
        rejectReason: decision === 'REJECTED' ? reason.trim() : null,
      });
      toast.success(decision === 'APPROVED' ? '승인하고 정산을 실행했어요.' : '청구를 반려했어요.');
      setSelected(null);
      setReason('');
      await list.reload();
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="admin-split">
      <div>
        <Segmented
          label="청구 상태"
          value={status}
          onChange={(v) => {
            setStatus(v);
            setSelected(null);
          }}
          options={(['PENDING', 'OVERDUE', 'REJECTED', 'APPROVED'] as const).map((v) => ({
            value: v,
            label: fareClaimLabel(v),
          }))}
        />
        <AdminTable
          rows={list.data?.content}
          loading={list.loading}
          error={list.error}
          onRetry={() => void list.reload()}
          rowKey={(r) => r.potId}
          selected={selected?.potId}
          onRowClick={setSelected}
          empty="확인할 청구가 없어요"
          columns={[
            { header: '방', cell: (r) => r.title },
            { header: '방장', cell: (r) => r.hostNickname },
            { header: '예상', cell: (r) => won(r.expectedFare), align: 'right' },
            { header: '청구', cell: (r) => won(r.actualFare), align: 'right' },
            {
              header: '비율',
              cell: (r) =>
                r.fareRatio === null ? (
                  '-'
                ) : (
                  <Badge tone={r.fareRatio > 1.5 ? 'danger' : 'neutral'}>
                    {r.fareRatio.toFixed(2)}
                  </Badge>
                ),
              align: 'right',
            },
            { header: '청구 시각', cell: (r) => fullDateTime(r.fareClaimedAt) },
          ]}
        />
      </div>
      {selected && (
        <aside className="admin-detail">
          <h2>{selected.title}</h2>
          <dl>
            <InfoRow label="탑승 인원">{selected.boardedCount}명</InfoRow>
            <InfoRow label="청구 금액" strong>
              {won(selected.actualFare)}
            </InfoRow>
            <InfoRow label="1인 분담금">
              {selected.actualFare === null
                ? '-'
                : won(Math.floor(selected.actualFare / Math.max(selected.boardedCount, 1)))}
            </InfoRow>
            <InfoRow label="탑승 시작">{fullDateTime(selected.startedAt)}</InfoRow>
            <InfoRow label="청구 기한">{fullDateTime(selected.claimDeadline)}</InfoRow>
          </dl>
          {selected.fareRatio !== null && selected.fareRatio > 1.5 && (
            <Notice tone="warn">
              예상 요금보다 {Math.round((selected.fareRatio - 1) * 100)}% 많아요. 사진의 금액과 결제
              일시를 꼭 대조해 주세요.
            </Notice>
          )}
          {selected.receiptUrl ? (
            <AuthImage key={selected.potId} load={loadReceipt} alt="결제내역 사진" />
          ) : (
            <p className="screen-note">영수증 사진 없음</p>
          )}
          {selected.fareClaimStatus === 'PENDING' && (
            <>
              <TextField
                label="반려 사유 (반려 시 필수)"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                maxLength={255}
              />
              <div className="footer-actions">
                <Button variant="secondary" loading={busy} onClick={() => void review('REJECTED')}>
                  반려
                </Button>
                <Button block loading={busy} onClick={() => void review('APPROVED')}>
                  승인하고 정산
                </Button>
              </div>
            </>
          )}
        </aside>
      )}
    </div>
  );
}
