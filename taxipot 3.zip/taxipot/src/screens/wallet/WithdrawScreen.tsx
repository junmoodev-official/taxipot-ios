import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api, isApiError } from '@/api';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/Field';
import { Badge, InfoRow, Loader, Notice } from '@/components/ui/Feedback';
import { env } from '@/config/env';
import { POLICY } from '@/config/policy';
import { useAsync } from '@/hooks/useAsync';
import { useWallet, walletChanged } from '@/hooks/useWallet';
import { fullDateTime, won } from '@/lib/format';
import { withdrawalStatusLabel } from '@/lib/labels';
import { DUMMY_FAIL_AMOUNT } from '@/mock/db';
import { useToast } from '@/store/ToastContext';

export function WithdrawScreen() {
  const toast = useToast();
  const wallet = useWallet();
  const account = useAsync(
    () => api.users.account().catch((e) => (isApiError(e, 'NOT_FOUND') ? null : Promise.reject(e))),
    [],
  );
  const history = useAsync(() => api.wallet.withdrawals({ size: 10 }), []);
  const [amount, setAmount] = useState('');
  const [busy, setBusy] = useState(false);

  const balance = wallet.data?.balance ?? 0;
  const value = Number(amount.replace(/\D/g, '')) || 0;
  const error =
    value === 0
      ? null
      : value < POLICY.minWithdrawal
        ? '1,000원 이상부터 출금할 수 있어요.'
        : value > balance
          ? '사용 가능 잔액보다 많아요.'
          : value > POLICY.maxWithdrawal
            ? '1회 최대 1,000,000원까지 출금할 수 있어요.'
            : null;

  async function submit() {
    if (!value || error) return;
    setBusy(true);
    try {
      const result = await api.wallet.withdraw({ amount: value });
      if (result.status === 'COMPLETED')
        toast.success(`${won(result.amount)}이 ${result.bankName} 계좌로 입금됐어요.`);
      else toast.error(`출금에 실패해 잔액을 돌려드렸어요. (${result.failReason ?? '송금 실패'})`);
      setAmount('');
      walletChanged();
      await history.reload();
    } catch (err) {
      toast.error(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen
      header={<PageHeader title="출금" />}
      footer={
        account.data === null ? undefined : (
          <Button
            size="lg"
            block
            loading={busy}
            disabled={!value || Boolean(error)}
            onClick={() => void submit()}
          >
            {value ? `${won(value)} 출금하기` : '출금하기'}
          </Button>
        )
      }
    >
      {account.loading ? (
        <Loader />
      ) : account.data === null ? (
        <Notice tone="warn">
          출금 계좌가 등록되지 않았어요. <Link to="/me/account">계좌 등록하기</Link>
        </Notice>
      ) : (
        <div className="form-stack">
          {account.data && (
            <section className="panel">
              <dl>
                <InfoRow label="받는 계좌">
                  {account.data.bankName} {account.data.maskedAccountNumber}
                </InfoRow>
                <InfoRow label="예금주">{account.data.accountHolder}</InfoRow>
                <InfoRow label="출금 가능" strong>
                  {won(balance)}
                </InfoRow>
              </dl>
            </section>
          )}
          <TextField
            label="출금할 금액"
            inputMode="numeric"
            suffix="원"
            value={value ? value.toLocaleString('ko-KR') : ''}
            onChange={(e) => setAmount(e.target.value)}
            error={error}
            hint="예치 중인 금액은 정산이 끝난 뒤 출금할 수 있어요."
          />
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setAmount(String(Math.min(balance, POLICY.maxWithdrawal)))}
            disabled={balance < POLICY.minWithdrawal}
          >
            전액 입력
          </Button>
          {env.isMock && (
            <Notice>
              시연 모드: {won(DUMMY_FAIL_AMOUNT)}을 입력하면 송금 실패 흐름을 볼 수 있어요.
            </Notice>
          )}
        </div>
      )}

      {history.data && history.data.content.length > 0 && (
        <section className="panel">
          <h3 className="panel__title">출금 내역</h3>
          <ul className="ledger">
            {history.data.content.map((w) => (
              <li key={w.id}>
                <span>
                  <strong>{won(w.amount)}</strong>
                  <small>
                    {fullDateTime(w.requestedAt)} · {w.bankName} {w.maskedAccountNumber}
                  </small>
                </span>
                <Badge
                  tone={
                    w.status === 'COMPLETED'
                      ? 'success'
                      : w.status === 'FAILED'
                        ? 'danger'
                        : 'brand'
                  }
                >
                  {withdrawalStatusLabel(w.status)}
                </Badge>
              </li>
            ))}
          </ul>
        </section>
      )}
    </Screen>
  );
}
