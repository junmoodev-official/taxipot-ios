import { useEffect, useState } from 'react';
import { api } from '@/api';
import type { PointHistoryResponse, PointType } from '@/api/types';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, Loader } from '@/components/ui/Feedback';
import { Segmented } from '@/components/ui/Segmented';
import { useAsync } from '@/hooks/useAsync';
import { fullDateTime, signedWon, won } from '@/lib/format';
import { pointTypeLabel } from '@/lib/labels';
import { History } from 'lucide-react';

type Filter = 'ALL' | PointType;

export function WalletHistoryScreen() {
  const [type, setType] = useState<Filter>('ALL');
  const [page, setPage] = useState(0);
  const [rows, setRows] = useState<PointHistoryResponse[]>([]);
  const state = useAsync(
    () => api.wallet.history({ type: type === 'ALL' ? undefined : type, page, size: 20 }),
    [type, page],
  );

  useEffect(() => setPage(0), [type]);
  useEffect(() => {
    if (state.data)
      setRows((prev) =>
        state.data!.page.page === 0 ? state.data!.content : [...prev, ...state.data!.content],
      );
  }, [state.data]);

  const hasMore = state.data ? state.data.page.page + 1 < state.data.page.totalPages : false;

  return (
    <Screen header={<PageHeader title="포인트 이용 내역" />}>
      <div className="filters">
        <Segmented
          scroll
          label="내역 유형"
          value={type}
          onChange={setType}
          options={[
            { value: 'ALL', label: '전체' },
            { value: 'FARE_HOLD', label: '예치' },
            { value: 'FARE_REFUND', label: '예치 해제' },
            { value: 'FARE_PAY', label: '분담금' },
            { value: 'HOST_PAYOUT', label: '방장 정산금' },
            { value: 'WITHDRAW', label: '출금' },
            { value: 'ADMIN_ADJUST', label: '충전' },
          ]}
        />
      </div>
      {state.error && rows.length === 0 ? (
        <ErrorState error={state.error} onRetry={() => void state.reload()} />
      ) : null}
      {state.loading && rows.length === 0 && <Loader />}
      {!state.loading && rows.length === 0 && !state.error && (
        <EmptyState icon={<History size={26} />} title="내역이 없어요" />
      )}
      <ul className="ledger ledger--full">
        {rows.map((row) => (
          <li key={row.id}>
            <span>
              <strong>{pointTypeLabel(row.type)}</strong>
              <small>
                {row.potTitle ? `${row.potTitle} · ` : ''}
                {fullDateTime(row.createdAt)}
              </small>
            </span>
            <span className="ledger__amount">
              <b className={row.amount > 0 ? 'is-plus' : 'is-minus'}>{signedWon(row.amount)}</b>
              <small>잔액 {won(row.balanceAfter)}</small>
            </span>
          </li>
        ))}
      </ul>
      {hasMore && (
        <Button
          variant="secondary"
          block
          loading={state.loading}
          onClick={() => setPage((p) => p + 1)}
        >
          더 보기
        </Button>
      )}
    </Screen>
  );
}
