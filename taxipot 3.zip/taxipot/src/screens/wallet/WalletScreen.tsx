import {
  ArrowDownToLine,
  ChevronRight,
  CircleAlert,
  History,
  Landmark,
  PiggyBank,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { api } from '@/api';
import { Screen } from '@/components/layout/Screen';
import { ErrorState, Loader, Notice } from '@/components/ui/Feedback';
import { POLICY } from '@/config/policy';
import { useAsync } from '@/hooks/useAsync';
import { useWallet } from '@/hooks/useWallet';
import { relativeTime, signedWon, won } from '@/lib/format';
import { pointTypeLabel } from '@/lib/labels';

export function WalletScreen() {
  const wallet = useWallet();
  const recent = useAsync(() => api.wallet.history({ size: 5 }), [wallet.data?.updatedAt]);
  const w = wallet.data;

  return (
    <Screen
      withTabs
      header={
        <header className="tab-header">
          <h1>지갑</h1>
        </header>
      }
    >
      {!w ? (
        wallet.error ? (
          <ErrorState error={wallet.error} onRetry={() => void wallet.reload()} />
        ) : (
          <Loader />
        )
      ) : (
        <>
          <section className="wallet-card">
            <span className="wallet-card__label">사용 가능 잔액</span>
            <strong className="wallet-card__balance">{won(w.balance)}</strong>
            <div className="wallet-card__row">
              <span>예치 중</span>
              <strong>{won(w.heldBalance)}</strong>
            </div>
            <div className="wallet-card__row">
              <span>지갑 한도</span>
              <strong>{won(POLICY.walletMaxBalance)}</strong>
            </div>
          </section>

          {w.debtAmount > 0 && (
            <Link to="/wallet/debts" className="banner banner--danger">
              <CircleAlert size={18} />
              <span>
                <strong>미수금 {won(w.debtAmount)}</strong>
                납부 전까지 택시팟 이용이 제한돼요.
              </span>
            </Link>
          )}

          <nav className="menu">
            <Link to="/wallet/withdraw" className="menu__item">
              <ArrowDownToLine size={20} />
              <span>등록 계좌로 출금</span>
              <ChevronRight size={18} />
            </Link>
            <Link to="/wallet/history" className="menu__item">
              <History size={20} />
              <span>포인트 이용 내역</span>
              <ChevronRight size={18} />
            </Link>
            <Link to="/wallet/debts" className="menu__item">
              <PiggyBank size={20} />
              <span>미수금</span>
              <ChevronRight size={18} />
            </Link>
            <Link to="/me/account" className="menu__item">
              <Landmark size={20} />
              <span>출금 계좌 관리</span>
              <ChevronRight size={18} />
            </Link>
          </nav>

          <Notice>
            <strong>충전 안내</strong>
            <p>
              카드 충전(PG 연동)은 준비 중이에요. 시연 기간에는 운영자가 지갑에 포인트를 넣어
              드려요.
            </p>
          </Notice>

          <section className="panel">
            <h3 className="panel__title">최근 내역</h3>
            <ul className="ledger">
              {recent.data?.content.map((row) => (
                <li key={row.id}>
                  <span>
                    <strong>{pointTypeLabel(row.type)}</strong>
                    <small>{row.potTitle ?? relativeTime(row.createdAt)}</small>
                  </span>
                  <span className={row.amount > 0 ? 'is-plus' : 'is-minus'}>
                    {signedWon(row.amount)}
                  </span>
                </li>
              ))}
              {recent.data?.content.length === 0 && (
                <li className="ledger__empty">아직 내역이 없어요.</li>
              )}
            </ul>
          </section>
        </>
      )}
    </Screen>
  );
}
