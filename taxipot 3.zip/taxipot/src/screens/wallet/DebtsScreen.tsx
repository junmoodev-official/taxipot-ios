import { PartyPopper } from 'lucide-react';
import { useState } from 'react';
import { api } from '@/api';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { Badge, EmptyState, ErrorState, InfoRow, Loader, Notice } from '@/components/ui/Feedback';
import { useAsync } from '@/hooks/useAsync';
import { useWallet, walletChanged } from '@/hooks/useWallet';
import { dayAndTime, won } from '@/lib/format';
import { debtStatusLabel } from '@/lib/labels';
import { useToast } from '@/store/ToastContext';

export function DebtsScreen() {
  const toast = useToast();
  const wallet = useWallet();
  const debts = useAsync(() => api.wallet.debts(), []);
  const [paying, setPaying] = useState<number | null>(null);

  async function pay(settlementId: number) {
    setPaying(settlementId);
    try {
      const result = await api.wallet.payDebt(settlementId);
      toast.success(
        result.debtAmount === 0
          ? `${won(result.paidAmount)}을 납부해 미수금을 모두 갚았어요.`
          : `${won(result.paidAmount)}을 납부했어요. 남은 금액 ${won(result.debtAmount)}`,
      );
      walletChanged();
      await debts.reload();
    } catch (error) {
      toast.error(error);
    } finally {
      setPaying(null);
    }
  }

  return (
    <Screen header={<PageHeader title="미수금" />}>
      {debts.loading && !debts.data && <Loader />}
      {debts.error ? <ErrorState error={debts.error} onRetry={() => void debts.reload()} /> : null}
      {debts.data && debts.data.length === 0 && (
        <EmptyState icon={<PartyPopper size={26} />} title="납부할 미수금이 없어요" />
      )}
      {debts.data && debts.data.length > 0 && (
        <>
          <Notice tone="danger">
            정산 때 잔액이 부족해 생긴 금액이에요. 납부 전까지 택시팟 이용·출금이 제한돼요.
            기한(정산 후 3일)이 지나면 약관에 따라 법적 조치가 진행될 수 있어요.
          </Notice>
          <p className="screen-note">
            지갑 잔액 {won(wallet.data?.balance)} · 부분 납부도 가능해요.
          </p>
          {debts.data.map((debt) => (
            <section key={debt.settlementId} className="panel">
              <header className="panel__row">
                <strong>{debt.potTitle}</strong>
                <Badge tone={debt.debtStatus === 'OVERDUE' ? 'danger' : 'amber'}>
                  {debtStatusLabel(debt.debtStatus)}
                </Badge>
              </header>
              <dl>
                <InfoRow label="남은 금액" strong>
                  {won(debt.debtAmount)}
                </InfoRow>
                <InfoRow label="정산 당시 부족분">{won(debt.uncoveredAmount)}</InfoRow>
                <InfoRow label="납부 기한">{dayAndTime(debt.debtDueAt)}</InfoRow>
              </dl>
              <Button
                block
                variant="danger"
                loading={paying === debt.settlementId}
                disabled={(wallet.data?.balance ?? 0) <= 0}
                onClick={() => void pay(debt.settlementId)}
              >
                {(wallet.data?.balance ?? 0) > 0
                  ? `${won(Math.min(wallet.data!.balance, debt.debtAmount))} 납부하기`
                  : '잔액이 없어요'}
              </Button>
            </section>
          ))}
        </>
      )}
    </Screen>
  );
}
