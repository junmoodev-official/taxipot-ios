import { Bell, CarTaxiFront, LocateFixed, Plus, Search, ShieldAlert, Wallet } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '@/api';
import type { MyPotHistoryResponse, PotSort, PotSummaryResponse } from '@/api/types';
import { Brand } from '@/components/layout/Brand';
import { Screen } from '@/components/layout/Screen';
import { MapView, type MapMarker } from '@/components/map/MapView';
import { PotCard } from '@/components/pot/PotCard';
import { RouteLine } from '@/components/pot/RouteLine';
import { Button } from '@/components/ui/Button';
import { EmptyState, ErrorState, Loader, Notice } from '@/components/ui/Feedback';
import { Segmented } from '@/components/ui/Segmented';
import { useAsync } from '@/hooks/useAsync';
import { useGeolocation } from '@/hooks/useGeolocation';
import { useUnreadCount } from '@/hooks/useUnreadCount';
import { useWallet } from '@/hooks/useWallet';
import { dayAndTime, won } from '@/lib/format';
import type { LatLng } from '@/lib/geo';
import { potStatusLabel } from '@/lib/labels';
import { useUser } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

const PAGE_SIZE = 10;

function useDebounced<T>(value: T, ms = 350): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(value), ms);
    return () => window.clearTimeout(timer);
  }, [value, ms]);
  return debounced;
}

function isActive(item: MyPotHistoryResponse) {
  const live = ['RECRUITING', 'CLOSED', 'RUNNING'].includes(item.potStatus);
  return live && (item.myStatus === 'JOINED' || item.myStatus === 'BOARDED');
}

export function HomeScreen() {
  const user = useUser();
  const navigate = useNavigate();
  const toast = useToast();
  const unread = useUnreadCount();
  const wallet = useWallet();
  const { locate, locating } = useGeolocation();

  const [departure, setDeparture] = useState('');
  const [destination, setDestination] = useState('');
  const [sort, setSort] = useState<PotSort>('DEPARTURE_TIME');
  const [near, setNear] = useState<LatLng | null>(null);
  const [page, setPage] = useState(0);
  const [items, setItems] = useState<PotSummaryResponse[]>([]);

  const query = useDebounced({ departure, destination, sort, near });
  const list = useAsync(
    () =>
      api.pots.list({
        departureName: query.departure.trim() || undefined,
        destinationName: query.destination.trim() || undefined,
        sort: query.sort,
        lat: query.near?.lat,
        lng: query.near?.lng,
        radius: query.near ? 3000 : undefined,
        page,
        size: PAGE_SIZE,
      }),
    [query, page],
  );
  const history = useAsync(() => api.users.myPots({ size: 5 }), []);
  const active = history.data?.content.find(isActive);

  useEffect(() => setPage(0), [query]);
  useEffect(() => {
    if (!list.data) return;
    setItems((prev) =>
      list.data!.page.page === 0 ? list.data!.content : [...prev, ...list.data!.content],
    );
  }, [list.data]);

  const markers = useMemo<MapMarker[]>(
    () =>
      items.slice(0, 12).map((pot) => ({
        id: pot.id,
        lat: pot.departureLat,
        lng: pot.departureLng,
        label: `${pot.departureName}에서 ${pot.destinationName}`,
        tone: pot.hasCanceled ? 'amber' : 'brand',
        onClick: () => navigate(`/pots/${pot.id}`),
      })),
    [items, navigate],
  );

  async function toggleNear() {
    if (near) {
      setNear(null);
      if (sort === 'DISTANCE') setSort('DEPARTURE_TIME');
      return;
    }
    try {
      const position = await locate(
        items[0] ? { lat: items[0].departureLat, lng: items[0].departureLng } : undefined,
      );
      setNear(position);
      setSort('DISTANCE');
    } catch (error) {
      toast.error(error);
    }
  }

  const hasMore = list.data ? list.data.page.page + 1 < list.data.page.totalPages : false;

  return (
    <Screen
      withTabs
      className="home"
      header={
        <header className="home-header">
          <Brand />
          <div className="home-header__actions">
            <Link to="/wallet" className="wallet-chip" aria-label="지갑 잔액">
              <Wallet size={15} />
              {wallet.data ? won(wallet.data.balance) : '—'}
            </Link>
            <Link to="/notifications" className="icon-btn bell" aria-label={`알림 ${unread}개`}>
              <Bell size={21} />
              {unread > 0 && <span className="bell__dot">{unread > 9 ? '9+' : unread}</span>}
            </Link>
          </div>
        </header>
      }
    >
      <section className="home-hero">
        <p>
          {user.university} · {user.nickname}님
        </p>
        <h2>어디로 가세요?</h2>
      </section>

      {!user.isVerified && (
        <Link to="/verify" className="banner banner--brand">
          <ShieldAlert size={18} />
          <span>
            <strong>학생 인증을 마쳐 주세요</strong>
            인증 후 택시팟을 만들고 참여할 수 있어요.
          </span>
        </Link>
      )}
      {user.status === 'SUSPENDED' && (
        <Notice tone="warn">
          {user.suspendedUntil
            ? `${dayAndTime(user.suspendedUntil)}까지`
            : '운영자가 해제할 때까지'}{' '}
          방 생성·참여가 제한돼요. 조회와 채팅은 할 수 있어요.
        </Notice>
      )}
      {wallet.data && wallet.data.debtAmount > 0 && (
        <Link to="/wallet/debts" className="banner banner--danger">
          <ShieldAlert size={18} />
          <span>
            <strong>미수금 {won(wallet.data.debtAmount)}</strong>
            납부하기 전까지 대부분의 기능이 제한돼요.
          </span>
        </Link>
      )}

      {active && (
        <Link to={`/pots/${active.potId}`} className="active-pot">
          <span className="active-pot__label">
            <CarTaxiFront size={16} /> 진행 중 · {potStatusLabel(active.potStatus)}
          </span>
          <RouteLine from={active.departureName} to={active.destinationName} />
          <span className="active-pot__time">{dayAndTime(active.departureTime)} 출발</span>
        </Link>
      )}

      <MapView markers={markers} me={near} height={180} />

      <section className="search-card">
        <div className="search-card__fields">
          <span className="route__dot route__dot--from" aria-hidden="true" />
          <input
            aria-label="출발지 검색"
            placeholder="출발지 검색"
            value={departure}
            onChange={(e) => setDeparture(e.target.value)}
          />
          <span className="route__dot route__dot--to" aria-hidden="true" />
          <input
            aria-label="도착지 검색"
            placeholder="도착지 검색"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
          />
        </div>
        <button
          type="button"
          className={`near-btn ${near ? 'is-on' : ''}`}
          onClick={() => void toggleNear()}
          disabled={locating}
          aria-pressed={Boolean(near)}
        >
          <LocateFixed size={16} />
          {locating ? '확인 중' : near ? '내 주변 3km' : '내 주변'}
        </button>
      </section>

      <div className="list-head">
        <h3>
          모집 중 <span>{list.data?.page.totalElements ?? 0}</span>
        </h3>
        <Segmented
          label="정렬"
          value={sort}
          onChange={setSort}
          options={[
            { value: 'DEPARTURE_TIME', label: '출발순' },
            { value: 'DISTANCE', label: '가까운순', disabled: !near },
            { value: 'HOST_RATING', label: '평점순' },
          ]}
        />
      </div>

      {list.error && items.length === 0 ? (
        <ErrorState error={list.error} onRetry={() => void list.reload()} />
      ) : list.loading && items.length === 0 ? (
        <Loader />
      ) : items.length === 0 ? (
        <EmptyState
          icon={<Search size={26} />}
          title="조건에 맞는 택시팟이 없어요"
          description="검색어를 바꾸거나 직접 택시팟을 만들어 보세요."
        />
      ) : (
        <div className="pot-list">
          {items.map((pot) => (
            <PotCard key={pot.id} pot={pot} />
          ))}
          {hasMore && (
            <Button
              variant="secondary"
              block
              loading={list.loading}
              onClick={() => setPage((p) => p + 1)}
            >
              더 보기
            </Button>
          )}
        </div>
      )}

      <button type="button" className="fab" onClick={() => navigate('/pots/new')}>
        <Plus size={20} /> 택시팟 만들기
      </button>
    </Screen>
  );
}
