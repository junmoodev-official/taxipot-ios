/** 동승자 평가 — 4항목 별점, 평균 3점 미만이면 사유 필수, 정산 후 24시간 */
import { CheckCircle2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '@/api';
import type { RatingItem } from '@/api/types';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { TextArea } from '@/components/ui/Field';
import { Avatar, EmptyState, ErrorState, Loader } from '@/components/ui/Feedback';
import { StarRating } from '@/components/ui/StarRating';
import { useAsync } from '@/hooks/useAsync';
import { useToast } from '@/store/ToastContext';

const CRITERIA = [
  { key: 'noshowScore', label: '약속 시간' },
  { key: 'mannerScore', label: '매너' },
  { key: 'communicationScore', label: '소통' },
  { key: 'paymentScore', label: '정산 협조' },
] as const;

type Draft = Omit<RatingItem, 'revieweeId' | 'badReason'> & { badReason: string };

const EMPTY: Draft = {
  noshowScore: 5,
  mannerScore: 5,
  communicationScore: 5,
  paymentScore: 5,
  badReason: '',
};

export function RatingScreen() {
  const potId = Number(useParams().potId);
  const toast = useToast();
  const navigate = useNavigate();
  const targets = useAsync(() => api.pots.ratingTargets(potId), [potId]);
  const [drafts, setDrafts] = useState<Record<number, Draft>>({});
  const [busy, setBusy] = useState(false);

  const pending = targets.data?.filter((t) => !t.isRated) ?? [];

  useEffect(() => {
    if (!targets.data) return;
    setDrafts(
      Object.fromEntries(
        targets.data.filter((t) => !t.isRated).map((t) => [t.memberId, { ...EMPTY }]),
      ),
    );
  }, [targets.data]);

  const average = (d: Draft) =>
    (d.noshowScore + d.mannerScore + d.communicationScore + d.paymentScore) / 4;

  async function submit() {
    const missing = pending.find(
      (t) => average(drafts[t.memberId]) < 3 && !drafts[t.memberId].badReason.trim(),
    );
    if (missing) return toast.error(`${missing.nickname}님에게 아쉬웠던 점을 적어 주세요.`);
    setBusy(true);
    try {
      await api.pots.rate(potId, {
        ratings: pending.map((t) => {
          const d = drafts[t.memberId];
          return {
            revieweeId: t.memberId,
            noshowScore: d.noshowScore,
            mannerScore: d.mannerScore,
            communicationScore: d.communicationScore,
            paymentScore: d.paymentScore,
            badReason: average(d) < 3 ? d.badReason.trim() : undefined,
          };
        }),
      });
      toast.success('평가를 보냈어요. 고마워요!');
      navigate(`/pots/${potId}`, { replace: true });
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen
      header={<PageHeader title="동승자 평가" />}
      footer={
        pending.length > 0 ? (
          <Button size="lg" block loading={busy} onClick={() => void submit()}>
            {pending.length}명 평가 보내기
          </Button>
        ) : undefined
      }
    >
      {targets.loading && !targets.data && <Loader />}
      {targets.error ? (
        <ErrorState error={targets.error} onRetry={() => void targets.reload()} />
      ) : null}
      {targets.data && pending.length === 0 && (
        <EmptyState
          icon={<CheckCircle2 size={26} />}
          title="모든 동승자를 평가했어요"
          description="평가는 상대 평점에 반영돼요."
          action={
            <Link to={`/pots/${potId}/report`} className="text-btn">
              불편했던 동승자 신고하기
            </Link>
          }
        />
      )}
      {pending.map((target) => {
        const draft = drafts[target.memberId];
        if (!draft) return null;
        const update = (patch: Partial<Draft>) =>
          setDrafts((prev) => ({
            ...prev,
            [target.memberId]: { ...prev[target.memberId], ...patch },
          }));
        return (
          <section key={target.memberId} className="panel rate-card">
            <header className="rate-card__head">
              <Avatar name={target.nickname} />
              <strong>{target.nickname}</strong>
              <span>{target.role === 'HOST' ? '방장' : '동승자'}</span>
            </header>
            {CRITERIA.map((c) => (
              <StarRating
                key={c.key}
                label={c.label}
                value={draft[c.key]}
                onChange={(v) => update({ [c.key]: v })}
              />
            ))}
            {average(draft) < 3 && (
              <TextArea
                label="아쉬웠던 점 (필수)"
                rows={3}
                maxLength={255}
                value={draft.badReason}
                onChange={(e) => update({ badReason: e.target.value })}
              />
            )}
          </section>
        );
      })}
      {targets.data && pending.length > 0 && (
        <p className="screen-note">
          문제가 있었나요? <Link to={`/pots/${potId}/report`}>신고하기</Link>
        </p>
      )}
    </Screen>
  );
}
