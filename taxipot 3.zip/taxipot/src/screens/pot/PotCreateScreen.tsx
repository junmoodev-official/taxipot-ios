import { CalendarClock, Link2, MapPin, Navigation } from 'lucide-react';
import { useMemo, useState, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '@/api';
import type { GenderOption, PreferredSeat } from '@/api/types';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { PlacePicker } from '@/components/map/PlacePicker';
import { SeatPicker } from '@/components/pot/SeatPicker';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/Field';
import { InfoRow, Notice } from '@/components/ui/Feedback';
import { Segmented } from '@/components/ui/Segmented';
import { POLICY, holdAmountOf } from '@/config/policy';
import { useWallet, walletChanged } from '@/hooks/useWallet';
import { clock, won } from '@/lib/format';
import type { Place } from '@/lib/geo';
import {
  addHours,
  addMinutes,
  fromKstLocalInput,
  serverClock,
  toKstIso,
  toKstLocalInput,
} from '@/lib/time';
import { validateOpenChatUrl } from '@/lib/validators';
import { useUser } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

function PlaceButton({
  label,
  place,
  icon,
  onClick,
}: {
  label: string;
  place: Place | null;
  icon: ReactNode;
  onClick: () => void;
}) {
  return (
    <div className="field">
      <span className="field__label">{label}</span>
      <button type="button" className={`place-btn ${place ? 'has-value' : ''}`} onClick={onClick}>
        {icon}
        <span>{place?.name ?? `${label}를 선택해 주세요`}</span>
      </button>
    </div>
  );
}

export function PotCreateScreen() {
  const user = useUser();
  const toast = useToast();
  const navigate = useNavigate();
  const wallet = useWallet();

  const defaultTime = useMemo(() => toKstLocalInput(addMinutes(serverClock.now(), 40)), []);
  const [title, setTitle] = useState('');
  const [departure, setDeparture] = useState<Place | null>(null);
  const [destination, setDestination] = useState<Place | null>(null);
  const [picker, setPicker] = useState<'departure' | 'destination' | null>(null);
  const [time, setTime] = useState(defaultTime);
  const [maxMembers, setMaxMembers] = useState<3 | 4>(4);
  const [genderOption, setGenderOption] = useState<GenderOption>('ALL');
  const [fare, setFare] = useState('15000');
  const [openChatUrl, setOpenChatUrl] = useState('');
  const [seat, setSeat] = useState<PreferredSeat>('FRONT');
  const [errors, setErrors] = useState<Record<string, string | null>>({});
  const [busy, setBusy] = useState(false);

  const fareNumber = Number(fare.replace(/\D/g, '')) || 0;
  const hold = holdAmountOf(fareNumber, maxMembers);
  const balance = wallet.data?.balance ?? 0;
  const shortage = Math.max(0, hold - balance);
  const now = serverClock.now();
  const minTime = toKstLocalInput(addMinutes(now, POLICY.minLeadMinutes));
  const maxTime = toKstLocalInput(addHours(now, POLICY.maxAdvanceHours));
  const departureAt = fromKstLocalInput(time);

  function validate() {
    const next: Record<string, string | null> = {};
    next.title = title.trim() ? null : '방 제목을 입력해 주세요.';
    next.departure = departure ? null : '출발지를 선택해 주세요.';
    next.destination = destination ? null : '도착지를 선택해 주세요.';
    if (departure && destination && departure.name === destination.name)
      next.destination = '출발지와 도착지가 같아요.';
    if (!departureAt) next.time = '출발 시각을 선택해 주세요.';
    else if (departureAt < addMinutes(now, POLICY.minLeadMinutes))
      next.time = '출발 15분 전까지만 만들 수 있어요.';
    else if (departureAt > addHours(now, POLICY.maxAdvanceHours))
      next.time = '24시간 이내 출발만 만들 수 있어요.';
    next.fare =
      fareNumber >= 1000 && fareNumber <= POLICY.maxFare
        ? null
        : '예상 요금을 1,000원 ~ 500,000원으로 입력해 주세요.';
    next.openChatUrl = validateOpenChatUrl(openChatUrl);
    setErrors(next);
    return Object.values(next).every((v) => !v);
  }

  async function submit() {
    if (!validate() || !departure || !destination || !departureAt) return;
    setBusy(true);
    try {
      const pot = await api.pots.create({
        title: title.trim(),
        departureName: departure.name,
        departureLat: departure.lat,
        departureLng: departure.lng,
        destinationName: destination.name,
        destinationLat: destination.lat,
        destinationLng: destination.lng,
        departureTime: toKstIso(departureAt),
        maxMembers,
        genderOption,
        expectedFare: fareNumber,
        openChatUrl: openChatUrl.trim() || undefined,
        preferredSeat: seat,
      });
      walletChanged();
      toast.success(`택시팟을 만들었어요. ${won(pot.holdAmount)}이 예치됐어요.`);
      navigate(`/pots/${pot.id}`, { replace: true });
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  const ownGender: GenderOption = user.gender === 'M' ? 'MALE' : 'FEMALE';

  return (
    <Screen
      header={<PageHeader title="택시팟 만들기" />}
      footer={
        shortage > 0 ? (
          <Link to="/wallet" className="btn btn--amber btn--lg btn--block">
            <span>{won(shortage)} 부족해요 · 지갑 확인</span>
          </Link>
        ) : (
          <Button
            size="lg"
            block
            loading={busy}
            onClick={() => void submit()}
            disabled={!user.isVerified}
          >
            {user.isVerified ? `${won(hold)} 예치하고 만들기` : '학생 인증 후 만들 수 있어요'}
          </Button>
        )
      }
    >
      <div className="form-stack">
        <TextField
          label="방 제목"
          maxLength={100}
          placeholder="예: KTX 타러 가실 분"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          error={errors.title}
        />
        <PlaceButton
          label="출발지"
          place={departure}
          icon={<MapPin size={18} />}
          onClick={() => setPicker('departure')}
        />
        {errors.departure && (
          <p className="field__message field__message--error">{errors.departure}</p>
        )}
        <PlaceButton
          label="도착지"
          place={destination}
          icon={<Navigation size={18} />}
          onClick={() => setPicker('destination')}
        />
        {errors.destination && (
          <p className="field__message field__message--error">{errors.destination}</p>
        )}

        <TextField
          label="출발 시각"
          type="datetime-local"
          icon={<CalendarClock size={18} />}
          min={minTime}
          max={maxTime}
          value={time}
          onChange={(e) => setTime(e.target.value)}
          error={errors.time}
          hint={
            departureAt
              ? `참여 마감·집결 기한 ${clock(toKstIso(addMinutes(departureAt, -POLICY.arrivalDeadlineMinutes)))} · 취소 마감 ${clock(toKstIso(addMinutes(departureAt, -POLICY.cancelDeadlineMinutes)))}`
              : '지금부터 15분 후 ~ 24시간 이내'
          }
        />

        <div className="field">
          <span className="field__label">모집 인원 (나 포함)</span>
          <Segmented
            label="모집 인원"
            value={maxMembers}
            onChange={setMaxMembers}
            options={[
              { value: 3, label: '3명' },
              { value: 4, label: '4명' },
            ]}
          />
        </div>
        <div className="field">
          <span className="field__label">함께 탈 사람</span>
          <Segmented
            label="성별 제한"
            value={genderOption}
            onChange={setGenderOption}
            options={[
              { value: 'ALL', label: '누구나' },
              { value: ownGender, label: ownGender === 'MALE' ? '남성만' : '여성만' },
            ]}
          />
        </div>

        <TextField
          label="예상 택시 요금 (전체)"
          inputMode="numeric"
          value={fareNumber ? fareNumber.toLocaleString('ko-KR') : ''}
          onChange={(e) => setFare(e.target.value)}
          suffix="원"
          error={errors.fare}
          hint="카카오T 등에서 확인한 예상 요금을 입력해 주세요."
        />

        <section className="calc-card">
          <dl>
            <InfoRow label="1인 예상 분담금">{won(Math.floor(fareNumber / maxMembers))}</InfoRow>
            <InfoRow label="여유분 (분담금의 20%)">
              {won(hold - POLICY.feeAmount - Math.floor(fareNumber / maxMembers))}
            </InfoRow>
            <InfoRow label="서비스 수수료">{won(POLICY.feeAmount)}</InfoRow>
            <InfoRow label="지금 예치할 금액" strong>
              {won(hold)}
            </InfoRow>
          </dl>
          <p>실제 요금으로 정산한 뒤 남는 금액은 지갑으로 돌려드려요. 내 잔액 {won(balance)}</p>
        </section>

        <div className="field">
          <span className="field__label">내 희망 좌석</span>
          <SeatPicker value={seat} onChange={setSeat} />
        </div>

        <TextField
          label="오픈채팅 링크 (선택)"
          icon={<Link2 size={18} />}
          placeholder="https://open.kakao.com/o/..."
          value={openChatUrl}
          onChange={(e) => setOpenChatUrl(e.target.value)}
          error={errors.openChatUrl}
          hint="참여자에게만 보여요. 앱 안 채팅도 함께 쓸 수 있어요."
        />
        <Notice>
          방을 만들면 바로 예치금이 묶여요. 혼자 남은 방은 출발 시각에 자동으로 해산되고 전액
          돌려드려요.
        </Notice>
      </div>

      <PlacePicker
        open={picker === 'departure'}
        title="출발지 선택"
        onClose={() => setPicker(null)}
        onSelect={setDeparture}
      />
      <PlacePicker
        open={picker === 'destination'}
        title="도착지 선택"
        onClose={() => setPicker(null)}
        onSelect={setDestination}
      />
    </Screen>
  );
}
