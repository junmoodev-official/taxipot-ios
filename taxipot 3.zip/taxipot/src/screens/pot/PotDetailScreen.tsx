/**
 * 택시팟 상세 — 참여 상태와 방 상태에 따라 가능한 행동만 보여 줍니다.
 * 최종 판정은 서버가 하며, 화면은 서버 시각(Date 헤더) 기준으로 버튼을 전환합니다.
 */
import {
  Ban,
  CarTaxiFront,
  Clock3,
  ExternalLink,
  MapPinCheck,
  MessageCircle,
  Pencil,
  ReceiptText,
  Star,
  UserX,
} from 'lucide-react';
import { useCallback, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '@/api';
import type { JoinRequestResponse, PotDetailResponse, PreferredSeat } from '@/api/types';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { MapView } from '@/components/map/MapView';
import { MemberList } from '@/components/pot/MemberList';
import { PotStatusBadge } from '@/components/pot/PotStatusBadge';
import { RouteLine } from '@/components/pot/RouteLine';
import { SeatPicker } from '@/components/pot/SeatPicker';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/Field';
import { Avatar, ErrorState, InfoRow, Loader, Notice } from '@/components/ui/Feedback';
import { ConfirmDialog, Sheet } from '@/components/ui/Sheet';
import { env } from '@/config/env';
import { useAsync } from '@/hooks/useAsync';
import { useGeolocation } from '@/hooks/useGeolocation';
import { useNow } from '@/hooks/useNow';
import { usePotRealtime } from '@/hooks/usePotRealtime';
import { useWallet, walletChanged } from '@/hooks/useWallet';
import { clock, dayAndTime, rating, remaining, won } from '@/lib/format';
import { kakaoTaxiLink, uberLink } from '@/lib/geo';
import { fareClaimLabel, genderOptionLabel, memberStatusLabel, seatLabel } from '@/lib/labels';
import { parseIso } from '@/lib/time';
import { validateOpenChatUrl } from '@/lib/validators';
import { useUser } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

type SheetName = 'join' | 'request' | 'seat' | 'edit' | null;
type ConfirmName =
  | 'leave'
  | 'cancel'
  | 'start'
  | 'withdrawRequest'
  | { kick: number; nickname: string }
  | null;

export function PotDetailScreen() {
  const potId = Number(useParams().potId);
  const user = useUser();
  const toast = useToast();
  const navigate = useNavigate();
  const now = useNow(1000);
  const wallet = useWallet();
  const { locate, locating } = useGeolocation();

  const detail = useAsync(() => api.pots.detail(potId), [potId]);
  const pot = detail.data;
  const isHost = pot?.hostId === user.id;
  const isParticipant = Boolean(pot?.isJoined);

  const requests = useAsync<JoinRequestResponse[]>(
    () =>
      isHost && pot?.status === 'RECRUITING' ? api.pots.joinRequests(potId) : Promise.resolve([]),
    [potId, isHost, pot?.status, pot?.updatedAt],
  );

  const refresh = useCallback(() => {
    void detail.reload();
  }, [detail]);
  usePotRealtime(potId, isParticipant, (event) => {
    if (event.type === 'POT_UPDATED') refresh();
  });

  const [sheet, setSheet] = useState<SheetName>(null);
  const [confirm, setConfirm] = useState<ConfirmName>(null);
  const [seat, setSeat] = useState<PreferredSeat>('NONE');
  const [busy, setBusy] = useState(false);

  async function act(task: () => Promise<unknown>, success: string, after?: () => void) {
    setBusy(true);
    try {
      await task();
      toast.success(success);
      walletChanged();
      setSheet(null);
      setConfirm(null);
      after?.();
      await detail.reload();
      void requests.reload();
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  if (!pot) {
    return (
      <Screen header={<PageHeader title="택시팟" />}>
        {detail.error ? <ErrorState error={detail.error} onRetry={refresh} /> : <Loader />}
      </Screen>
    );
  }

  const me = pot.members.find((m) => m.memberId === user.id);
  const status = pot.myMemberStatus;
  const live = pot.status === 'RECRUITING' || pot.status === 'CLOSED';
  const deadlinePassed = (parseIso(pot.arrivalDeadline)?.getTime() ?? 0) <= now.getTime();
  const cancelPassed = (parseIso(pot.cancelDeadline)?.getTime() ?? 0) <= now.getTime();
  const joined = pot.members.filter((m) => m.status === 'JOINED');
  const allArrived = joined.length >= 2 && joined.every((m) => m.arrivedAt);
  const takenSeats = pot.members.filter((m) => m.memberId !== user.id).map((m) => m.preferredSeat);
  const departurePoint = { lat: pot.departureLat, lng: pot.departureLng };

  async function arrive() {
    try {
      const position = await locate(departurePoint);
      await act(() => api.pots.arrive(pot!.id, position), '도착을 확인했어요.');
    } catch (error) {
      toast.error(error);
    }
  }

  async function requestJoin() {
    try {
      const position = await locate(departurePoint);
      await act(
        () => api.pots.requestJoin(pot!.id, { ...position, preferredSeat: seat }),
        '방장에게 입장을 요청했어요.',
      );
    } catch (error) {
      toast.error(error);
    }
  }

  return (
    <Screen
      className="pot-detail"
      header={
        <PageHeader
          title="택시팟"
          right={
            isHost && live ? (
              <button
                type="button"
                className="icon-btn"
                aria-label="방 정보 수정"
                onClick={() => setSheet('edit')}
              >
                <Pencil size={19} />
              </button>
            ) : undefined
          }
        />
      }
      footer={Footer()}
    >
      <MapView
        markers={[]}
        route={[departurePoint, { lat: pot.destinationLat, lng: pot.destinationLng }]}
        height={170}
      />

      <section className="ticket">
        <div className="ticket__head">
          <PotStatusBadge status={pot.status} />
          {pot.genderOption !== 'ALL' && (
            <span className="mini-tag">{genderOptionLabel(pot.genderOption)}</span>
          )}
          {pot.hasCanceled && live && <span className="roof-tag">빈자리 생김</span>}
        </div>
        <h2 className="ticket__title">{pot.title}</h2>
        <div className="ticket__body">
          <div className="ticket__meter">
            <span>{clock(pot.departureTime)}</span>
            <small>{dayAndTime(pot.departureTime).split(' ')[0]} 출발</small>
          </div>
          <RouteLine from={pot.departureName} to={pot.destinationName} size="lg" />
        </div>
        {live && (
          <div className="ticket__deadlines">
            <div className={deadlinePassed ? 'is-past' : ''}>
              <Clock3 size={14} />
              <span>참여 마감·집결</span>
              <strong>{clock(pot.arrivalDeadline)}</strong>
              <em>{remaining(pot.arrivalDeadline) ?? '지남'}</em>
            </div>
            <div className={cancelPassed ? 'is-past' : ''}>
              <Ban size={14} />
              <span>취소 마감</span>
              <strong>{clock(pot.cancelDeadline)}</strong>
              <em>{remaining(pot.cancelDeadline) ?? '지남'}</em>
            </div>
          </div>
        )}
      </section>

      <section className="panel">
        <dl>
          <InfoRow label="예상 택시 요금">{won(pot.expectedFare)}</InfoRow>
          <InfoRow label="1인 예치액">{won(pot.holdAmount)}</InfoRow>
          {pot.actualFare !== null && <InfoRow label="실제 요금">{won(pot.actualFare)}</InfoRow>}
          <InfoRow label="인원">
            {pot.currentMembers}/{pot.maxMembers}명
          </InfoRow>
        </dl>
      </section>

      {StatusNotice()}

      <section className="panel">
        <h3 className="panel__title">
          함께 타는 사람 <span>{pot.members.length}</span>
        </h3>
        <MemberList
          members={pot.members}
          myId={user.id}
          action={(member) =>
            isHost &&
            live &&
            member.role === 'GUEST' &&
            member.status === 'JOINED' &&
            !member.arrivedAt ? (
              <button
                type="button"
                className="icon-btn icon-btn--danger"
                aria-label={`${member.nickname} 내보내기`}
                onClick={() => setConfirm({ kick: member.memberId, nickname: member.nickname })}
              >
                <UserX size={18} />
              </button>
            ) : null
          }
        />
        {isParticipant && live && joined.length > 0 && (
          <p className="panel__foot">
            도착 확인 {joined.filter((m) => m.arrivedAt).length}/{joined.length}명 · 모두 도착하면
            방장이 탑승을 시작해요.
          </p>
        )}
      </section>

      {isHost && pot.status === 'RECRUITING' && (requests.data?.length ?? 0) > 0 && (
        <section className="panel">
          <h3 className="panel__title">
            입장 요청 <span>{requests.data!.length}</span>
          </h3>
          <ul className="member-list">
            {requests.data!.map((request) => (
              <li key={request.memberId} className="member">
                <Avatar name={request.nickname} />
                <div className="member__body">
                  <strong>{request.nickname}</strong>
                  <small>
                    평점 {rating(request.ratingAvg)} · {seatLabel(request.preferredSeat)} ·{' '}
                    {clock(request.requestedAt)} 요청
                  </small>
                </div>
                <div className="member__actions">
                  <Button
                    size="sm"
                    variant="secondary"
                    disabled={busy}
                    onClick={() =>
                      void act(
                        () => api.pots.rejectJoinRequest(pot.id, request.memberId),
                        '입장 요청을 거절했어요.',
                      )
                    }
                  >
                    거절
                  </Button>
                  <Button
                    size="sm"
                    disabled={busy}
                    onClick={() =>
                      void act(
                        () => api.pots.acceptJoinRequest(pot.id, request.memberId),
                        `${request.nickname}님을 태웠어요.`,
                      )
                    }
                  >
                    수락
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </section>
      )}

      {pot.status === 'RUNNING' && isParticipant && (
        <section className="panel">
          <h3 className="panel__title">택시 부르기</h3>
          <p className="panel__desc">출발지와 도착지가 입력된 상태로 택시 앱을 열어요.</p>
          <div className="deeplinks">
            <a
              className="btn btn--secondary"
              href={kakaoTaxiLink(departurePoint, {
                lat: pot.destinationLat,
                lng: pot.destinationLng,
              })}
            >
              <CarTaxiFront size={18} />
              <span>카카오 T</span>
            </a>
            <a
              className="btn btn--secondary"
              href={uberLink(
                { name: pot.departureName, ...departurePoint },
                { name: pot.destinationName, lat: pot.destinationLat, lng: pot.destinationLng },
              )}
              target="_blank"
              rel="noopener noreferrer"
            >
              <ExternalLink size={18} />
              <span>Uber</span>
            </a>
          </div>
        </section>
      )}

      {pot.openChatUrl && (
        <a className="link-row" href={pot.openChatUrl} target="_blank" rel="noopener noreferrer">
          <ExternalLink size={16} /> 카카오톡 오픈채팅 열기
        </a>
      )}

      {JoinSheets()}
      {ConfirmDialogs()}
    </Screen>
  );

  /* ─────────── 상태 안내 ─────────── */

  function StatusNotice() {
    const p = pot as PotDetailResponse;
    if (p.status === 'CANCELED')
      return <Notice tone="danger">취소된 택시팟이에요. 예치금은 모두 돌려드렸어요.</Notice>;
    if (status === 'REQUESTED')
      return <Notice>입장을 요청했어요. 방장이 수락하면 바로 함께 탈 수 있어요.</Notice>;
    if (status === 'REJECTED' || status === 'KICKED' || status === 'NO_SHOW') {
      return (
        <Notice tone="warn">
          {memberStatusLabel(status)} 처리된 택시팟이라 다시 참여할 수 없어요.
        </Notice>
      );
    }
    if (p.status === 'RUNNING') {
      if (p.fareClaimStatus === 'NONE') {
        return (
          <Notice>
            {isHost
              ? '하차 후 결제내역 사진과 실제 요금으로 정산을 청구해 주세요. (탑승 후 24시간 이내)'
              : '하차 후 방장이 실제 요금을 청구하면 운영자 확인 뒤 정산돼요.'}
          </Notice>
        );
      }
      if (p.fareClaimStatus === 'REJECTED') {
        return (
          <Notice tone="warn">
            정산 청구가 반려됐어요 · {p.fareRejectReason}
            {isHost ? ' 다시 청구해 주세요.' : ''}
          </Notice>
        );
      }
      return (
        <Notice tone={p.fareClaimStatus === 'OVERDUE' ? 'warn' : 'info'}>
          정산 청구 상태: {fareClaimLabel(p.fareClaimStatus)}
          {p.actualFare !== null ? ` · 실요금 ${won(p.actualFare)}` : ''}
        </Notice>
      );
    }
    if (live && isParticipant && me && !me.arrivedAt) {
      return (
        <Notice tone={deadlinePassed ? 'danger' : 'warn'}>
          {clock(p.arrivalDeadline)}까지 출발지 50m 안에서 도착을 확인해 주세요. 확인하지 않으면
          퇴장되고 15분 동안 이용이 제한돼요.
          {env.isMock && ' (시연 모드: 출발지 근처 좌표로 대신 확인해요)'}
        </Notice>
      );
    }
    return null;
  }

  /* ─────────── 하단 버튼 ─────────── */

  function Footer() {
    const p = pot as PotDetailResponse;
    const chat = (
      <Button
        variant="secondary"
        size="lg"
        icon={<MessageCircle size={18} />}
        onClick={() => navigate(`/pots/${p.id}/chat`)}
      >
        채팅
      </Button>
    );

    if (p.status === 'COMPLETED' && isParticipant) {
      return (
        <div className="footer-actions">
          <Button
            variant="secondary"
            size="lg"
            icon={<ReceiptText size={18} />}
            onClick={() => navigate(`/pots/${p.id}/settlement`)}
          >
            정산 내역
          </Button>
          <Button
            size="lg"
            block
            icon={<Star size={18} />}
            onClick={() => navigate(`/pots/${p.id}/rate`)}
          >
            동승자 평가
          </Button>
        </div>
      );
    }

    if (p.status === 'RUNNING' && isParticipant) {
      const canClaim = isHost && ['NONE', 'REJECTED', 'OVERDUE'].includes(p.fareClaimStatus);
      return (
        <div className="footer-actions">
          {chat}
          {canClaim ? (
            <Button
              size="lg"
              block
              icon={<ReceiptText size={18} />}
              onClick={() => navigate(`/pots/${p.id}/claim`)}
            >
              실요금 청구하기
            </Button>
          ) : (
            <Button
              size="lg"
              block
              variant="secondary"
              onClick={() => navigate(`/pots/${p.id}/settlement`)}
            >
              정산 현황 보기
            </Button>
          )}
        </div>
      );
    }

    if (live && isParticipant && me) {
      const primary = !me.arrivedAt ? (
        <Button
          size="lg"
          block
          icon={<MapPinCheck size={18} />}
          loading={locating || busy}
          disabled={deadlinePassed}
          onClick={() => void arrive()}
        >
          {deadlinePassed ? '집결 기한이 지났어요' : '출발지 도착 확인'}
        </Button>
      ) : isHost ? (
        <Button
          size="lg"
          block
          icon={<CarTaxiFront size={18} />}
          disabled={!allArrived || busy}
          onClick={() => setConfirm('start')}
        >
          {allArrived
            ? '탑승 시작'
            : joined.length < 2
              ? '2명 이상 모이면 출발할 수 있어요'
              : '모두 도착하면 출발할 수 있어요'}
        </Button>
      ) : (
        <Button size="lg" block variant="secondary" disabled>
          도착 완료 · 출발을 기다리는 중
        </Button>
      );
      return (
        <div className="footer-stack">
          <div className="footer-actions">
            {chat}
            {primary}
          </div>
          <div className="footer-links">
            {!isHost && (
              <button
                type="button"
                onClick={() => {
                  setSeat(me.preferredSeat);
                  setSheet('seat');
                }}
              >
                좌석 변경
              </button>
            )}
            {!cancelPassed && (
              <button
                type="button"
                className="is-danger"
                onClick={() => setConfirm(isHost ? 'cancel' : 'leave')}
              >
                {isHost ? '방 취소' : '참여 취소'}
              </button>
            )}
          </div>
        </div>
      );
    }

    if (status === 'REQUESTED') {
      return (
        <Button size="lg" block variant="secondary" onClick={() => setConfirm('withdrawRequest')}>
          입장 요청 철회
        </Button>
      );
    }

    if (p.status === 'RECRUITING' && !['REJECTED', 'KICKED', 'NO_SHOW'].includes(status ?? '')) {
      return deadlinePassed ? (
        <Button
          size="lg"
          block
          variant="amber"
          onClick={() => {
            setSeat('NONE');
            setSheet('request');
          }}
        >
          출발지에서 입장 요청하기
        </Button>
      ) : (
        <Button
          size="lg"
          block
          onClick={() => {
            setSeat('NONE');
            setSheet('join');
          }}
          disabled={!user.isVerified}
        >
          {user.isVerified
            ? `참여하기 · ${won(p.holdAmount)} 예치`
            : '학생 인증 후 참여할 수 있어요'}
        </Button>
      );
    }

    return null;
  }

  /* ─────────── 시트 ─────────── */

  function JoinSheets() {
    const p = pot as PotDetailResponse;
    const balance = wallet.data?.balance ?? 0;
    const shortage = Math.max(0, p.holdAmount - balance);
    const summary = (
      <dl className="sheet-summary">
        <InfoRow label="예치할 금액">{won(p.holdAmount)}</InfoRow>
        <InfoRow label="내 지갑 잔액">{won(balance)}</InfoRow>
      </dl>
    );
    return (
      <>
        <Sheet
          open={sheet === 'join'}
          title="희망 좌석을 골라 주세요"
          onClose={() => setSheet(null)}
          footer={
            shortage > 0 ? (
              <Link to="/wallet" className="btn btn--amber btn--lg btn--block">
                <span>{won(shortage)} 부족해요 · 지갑 확인</span>
              </Link>
            ) : (
              <Button
                size="lg"
                block
                loading={busy}
                onClick={() =>
                  void act(
                    () => api.pots.join(p.id, { preferredSeat: seat }),
                    '택시팟에 참여했어요.',
                  )
                }
              >
                {won(p.holdAmount)} 예치하고 참여
              </Button>
            )
          }
        >
          <SeatPicker value={seat} onChange={setSeat} taken={takenSeats} />
          {summary}
          <p className="sheet-note">
            출발 10분 전까지는 취소하면 전액 돌려드려요. 정산 후 남은 예치금도 돌려드려요.
          </p>
        </Sheet>

        <Sheet
          open={sheet === 'request'}
          title="입장 요청"
          onClose={() => setSheet(null)}
          footer={
            <Button
              size="lg"
              block
              variant="amber"
              loading={busy || locating}
              onClick={() => void requestJoin()}
            >
              현재 위치로 요청 보내기
            </Button>
          }
        >
          <p className="sheet-note">
            참여 마감이 지난 방은 출발지 50m 안에서만 입장을 요청할 수 있어요. 방장이 수락하면 그때
            예치돼요.
          </p>
          <SeatPicker value={seat} onChange={setSeat} taken={takenSeats} />
          {summary}
        </Sheet>

        <Sheet
          open={sheet === 'seat'}
          title="좌석 변경"
          onClose={() => setSheet(null)}
          footer={
            <Button
              size="lg"
              block
              loading={busy}
              onClick={() =>
                void act(
                  () => api.pots.changeSeat(p.id, { preferredSeat: seat }),
                  '희망 좌석을 바꿨어요.',
                )
              }
            >
              바꾸기
            </Button>
          }
        >
          <SeatPicker value={seat} onChange={setSeat} taken={takenSeats} />
        </Sheet>

        {sheet === 'edit' && (
          <EditSheet
            pot={p}
            busy={busy}
            onClose={() => setSheet(null)}
            onSave={(body) => void act(() => api.pots.update(p.id, body), '방 정보를 수정했어요.')}
          />
        )}
      </>
    );
  }

  function ConfirmDialogs() {
    const p = pot as PotDetailResponse;
    const kick = typeof confirm === 'object' && confirm !== null ? confirm : null;
    return (
      <>
        <ConfirmDialog
          open={confirm === 'leave'}
          title="참여를 취소할까요?"
          message={`예치금 ${won(p.holdAmount)}은 바로 돌려드려요. 출발 10분 전부터는 취소할 수 없어요.`}
          confirmLabel="참여 취소"
          tone="danger"
          loading={busy}
          onClose={() => setConfirm(null)}
          onConfirm={() => void act(() => api.pots.leave(p.id), '참여를 취소했어요.')}
        />
        <ConfirmDialog
          open={confirm === 'cancel'}
          title="방을 취소할까요?"
          message="모든 참여자의 예치금을 돌려드리고 방이 닫혀요. 되돌릴 수 없어요."
          confirmLabel="방 취소"
          tone="danger"
          loading={busy}
          onClose={() => setConfirm(null)}
          onConfirm={() =>
            void act(
              () => api.pots.cancel(p.id),
              '방을 취소했어요.',
              () => navigate('/home', { replace: true }),
            )
          }
        />
        <ConfirmDialog
          open={confirm === 'start'}
          title="탑승을 시작할까요?"
          message="택시에 탄 뒤 눌러 주세요. 시작하면 참여·취소가 닫히고, 하차 후 실요금을 청구할 수 있어요."
          confirmLabel="탑승 시작"
          loading={busy}
          onClose={() => setConfirm(null)}
          onConfirm={() =>
            void act(() => api.pots.start(p.id), '탑승을 시작했어요. 안전하게 이동하세요.')
          }
        />
        <ConfirmDialog
          open={confirm === 'withdrawRequest'}
          title="입장 요청을 철회할까요?"
          message="아직 예치 전이라 돌려받을 금액은 없어요."
          confirmLabel="철회"
          loading={busy}
          onClose={() => setConfirm(null)}
          onConfirm={() =>
            void act(() => api.pots.withdrawJoinRequest(p.id), '입장 요청을 철회했어요.')
          }
        />
        <ConfirmDialog
          open={kick !== null}
          title={`${kick?.nickname ?? ''}님을 내보낼까요?`}
          message={
            deadlinePassed
              ? '집결 기한이 지나 미도착 퇴장으로 처리되고, 상대는 15분 동안 이용이 제한돼요.'
              : '도착 확인 전인 동승자만 내보낼 수 있어요. 예치금은 상대에게 돌려드려요.'
          }
          confirmLabel="내보내기"
          tone="danger"
          loading={busy}
          onClose={() => setConfirm(null)}
          onConfirm={() =>
            kick &&
            void act(() => api.pots.kick(p.id, kick.kick), `${kick.nickname}님을 내보냈어요.`)
          }
        />
      </>
    );
  }
}

function EditSheet({
  pot,
  busy,
  onClose,
  onSave,
}: {
  pot: PotDetailResponse;
  busy: boolean;
  onClose: () => void;
  onSave: (body: { title: string; openChatUrl: string }) => void;
}) {
  const [title, setTitle] = useState(pot.title);
  const [openChatUrl, setOpenChatUrl] = useState(pot.openChatUrl ?? '');
  const urlError = validateOpenChatUrl(openChatUrl);
  return (
    <Sheet
      open
      title="방 정보 수정"
      onClose={onClose}
      footer={
        <Button
          size="lg"
          block
          loading={busy}
          disabled={!title.trim() || Boolean(urlError)}
          onClick={() => onSave({ title: title.trim(), openChatUrl: openChatUrl.trim() })}
        >
          저장
        </Button>
      }
    >
      <div className="form-stack">
        <TextField
          label="방 제목"
          maxLength={100}
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <TextField
          label="오픈채팅 링크"
          value={openChatUrl}
          onChange={(e) => setOpenChatUrl(e.target.value)}
          error={urlError}
        />
        <p className="sheet-note">
          출발 시각과 요금은 예치금이 다시 계산돼야 해서 바꿀 수 없어요. 혼자일 때 취소 후 다시
          만들어 주세요.
        </p>
      </div>
    </Sheet>
  );
}
