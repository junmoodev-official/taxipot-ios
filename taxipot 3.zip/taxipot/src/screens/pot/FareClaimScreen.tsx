/** 방장의 실요금 청구 (결제내역 사진 + 실제 요금, multipart) */
import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '@/api';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/Field';
import { ErrorState, InfoRow, Loader, Notice } from '@/components/ui/Feedback';
import { ImagePicker } from '@/components/ui/ImagePicker';
import { POLICY } from '@/config/policy';
import { useAsync } from '@/hooks/useAsync';
import { won } from '@/lib/format';
import { validateImage } from '@/lib/validators';
import { useToast } from '@/store/ToastContext';

export function FareClaimScreen() {
  const potId = Number(useParams().potId);
  const navigate = useNavigate();
  const toast = useToast();
  const detail = useAsync(() => api.pots.detail(potId), [potId]);
  const [fare, setFare] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const pot = detail.data;
  const amount = Number(fare.replace(/\D/g, '')) || 0;
  const boarded = pot?.members.filter((m) => m.status === 'BOARDED').length ?? 1;
  const ratio = pot && pot.expectedFare > 0 ? amount / pot.expectedFare : 1;

  async function submit() {
    const err = validateImage(file);
    if (err) return setFileError(err);
    if (amount <= 0 || amount > POLICY.maxFare)
      return toast.error('실제 요금을 정확히 입력해 주세요.');
    setBusy(true);
    try {
      await api.pots.claimFare(potId, amount, file!);
      toast.success('정산을 청구했어요. 운영자가 확인하면 알려드려요.');
      navigate(`/pots/${potId}`, { replace: true });
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen
      header={<PageHeader title="실요금 청구" />}
      footer={
        <Button size="lg" block loading={busy} onClick={() => void submit()} disabled={!pot}>
          {amount ? `${won(amount)} 청구하기` : '청구하기'}
        </Button>
      }
    >
      {!pot ? (
        detail.error ? (
          <ErrorState error={detail.error} onRetry={() => void detail.reload()} />
        ) : (
          <Loader />
        )
      ) : (
        <div className="form-stack">
          {pot.fareClaimStatus === 'REJECTED' && (
            <Notice tone="warn">반려 사유: {pot.fareRejectReason}</Notice>
          )}
          <ImagePicker
            label="결제내역 사진"
            hint="카드 영수증 또는 택시 앱 결제 화면"
            file={file}
            error={fileError}
            onChange={(next, err) => {
              setFile(next);
              setFileError(err);
            }}
          />
          <TextField
            label="실제 결제 금액"
            inputMode="numeric"
            suffix="원"
            value={amount ? amount.toLocaleString('ko-KR') : ''}
            onChange={(e) => setFare(e.target.value)}
            hint="사진 속 결제 금액과 같아야 승인돼요."
          />
          {amount > 0 && ratio > 1.5 && (
            <Notice tone="warn">
              예상 요금({won(pot.expectedFare)})보다 많이 나왔어요. 금액을 한 번 더 확인해 주세요.
            </Notice>
          )}
          <section className="calc-card">
            <dl>
              <InfoRow label="탑승 인원">{boarded}명</InfoRow>
              <InfoRow label="1인 분담금 (내림)">
                {won(Math.floor(amount / Math.max(boarded, 1)))}
              </InfoRow>
              <InfoRow label="방장에게 지급" strong>
                {won(amount)}
              </InfoRow>
            </dl>
            <p>
              운영자가 사진과 금액을 확인한 뒤 정산이 실행돼요. 1원 단위 끝수는 택시팟이 부담해요.
            </p>
          </section>
        </div>
      )}
    </Screen>
  );
}
