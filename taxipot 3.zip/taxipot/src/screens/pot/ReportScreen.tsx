/** 신고 — 끝까지 함께 탑승한 사람(또는 노쇼 피해자)만 가능 */
import { useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '@/api';
import type { ReportType } from '@/api/types';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { Button } from '@/components/ui/Button';
import { SelectField, TextArea } from '@/components/ui/Field';
import { ErrorState, Loader, Notice } from '@/components/ui/Feedback';
import { Segmented } from '@/components/ui/Segmented';
import { useAsync } from '@/hooks/useAsync';
import { useUser } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

export function ReportScreen() {
  const potId = Number(useParams().potId);
  const user = useUser();
  const toast = useToast();
  const navigate = useNavigate();
  const settlement = useAsync(() => api.pots.settlement(potId), [potId]);
  const [target, setTarget] = useState('');
  const [type, setType] = useState<ReportType>('ABUSIVE');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);

  const candidates = useMemo(
    () => settlement.data?.settlements.filter((s) => s.memberId !== user.id) ?? [],
    [settlement.data, user.id],
  );

  async function submit() {
    if (!target) return toast.error('신고할 사람을 골라 주세요.');
    if (!reason.trim()) return toast.error('신고 사유를 적어 주세요.');
    setBusy(true);
    try {
      await api.reports.create({ potId, reportedId: Number(target), type, reason: reason.trim() });
      toast.success('신고를 접수했어요. 운영자가 확인 후 결과를 알려드려요.');
      navigate(-1);
    } catch (error) {
      toast.error(error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen
      header={<PageHeader title="신고하기" />}
      footer={
        <Button size="lg" block variant="danger" loading={busy} onClick={() => void submit()}>
          신고 접수
        </Button>
      }
    >
      {!settlement.data ? (
        settlement.error ? (
          <ErrorState error={settlement.error} onRetry={() => void settlement.reload()} />
        ) : (
          <Loader />
        )
      ) : (
        <div className="form-stack">
          <Notice>
            끝까지 함께 탑승한 동승자, 또는 나타나지 않은 동승자(노쇼)만 신고할 수 있어요. 허위
            신고는 제재될 수 있어요.
          </Notice>
          <SelectField label="대상" value={target} onChange={(e) => setTarget(e.target.value)}>
            <option value="">선택해 주세요</option>
            {candidates.map((c) => (
              <option key={c.memberId} value={c.memberId}>
                {c.nickname}
              </option>
            ))}
          </SelectField>
          <div className="field">
            <span className="field__label">유형</span>
            <Segmented
              label="신고 유형"
              value={type}
              onChange={setType}
              options={[
                { value: 'NO_SHOW', label: '노쇼' },
                { value: 'ABUSIVE', label: '불쾌한 언행' },
                { value: 'ETC', label: '기타' },
              ]}
            />
          </div>
          <TextArea
            label="자세한 내용"
            rows={5}
            maxLength={255}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="언제, 어떤 일이 있었는지 적어 주세요."
          />
        </div>
      )}
    </Screen>
  );
}
