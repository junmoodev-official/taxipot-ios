import { useCallback } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '@/api';
import { PageHeader } from '@/components/layout/PageHeader';
import { Screen } from '@/components/layout/Screen';
import { AuthImage } from '@/components/ui/AuthImage';
import { Badge, ErrorState, InfoRow, Loader, Notice } from '@/components/ui/Feedback';
import { useAsync } from '@/hooks/useAsync';
import { fullDateTime, won } from '@/lib/format';
import { debtStatusLabel, settlementStatusLabel } from '@/lib/labels';
import { useUser } from '@/store/SessionContext';

export function SettlementScreen() {
  const potId = Number(useParams().potId);
  const user = useUser();
  const state = useAsync(
    () => Promise.all([api.pots.settlement(potId), api.pots.detail(potId)]),
    [potId],
  );
  const loadReceipt = useCallback(() => api.pots.receipt(potId), [potId]);

  if (!state.data) {
    return (
      <Screen header={<PageHeader title="정산 내역" />}>
        {state.error ? (
          <ErrorState error={state.error} onRetry={() => void state.reload()} />
        ) : (
          <Loader />
        )}
      </Screen>
    );
  }

  const [settlement, pot] = state.data;
  const mine = settlement.settlements.find((s) => s.memberId === user.id);
  const settled = settlement.actualFare !== null;
  const boardedMe = pot.myMemberStatus === 'BOARDED';

  return (
    <Screen header={<PageHeader title="정산 내역" />}>
      <section className="receipt-hero">
        <p>{pot.title}</p>
        <strong>{settled ? won(settlement.actualFare) : '정산 전'}</strong>
        <span>
          예상 {won(settlement.expectedFare)} · 탑승 {settlement.boardedCount}명
        </span>
      </section>

      {!settled && <Notice>운영자가 실요금 청구를 승인하면 아래 금액이 확정돼요.</Notice>}

      {mine && (
        <section className="panel">
          <h3 className="panel__title">내 정산</h3>
          <dl>
            <InfoRow label="예치했던 금액">{won(mine.heldAmount)}</InfoRow>
            <InfoRow label="택시비 분담금">{won(mine.fareShare)}</InfoRow>
            <InfoRow label="서비스 수수료">{won(mine.feeAmount)}</InfoRow>
            <InfoRow
              label={
                mine.diffAmount !== null && mine.diffAmount < 0
                  ? '예치금보다 더 낸 금액'
                  : '돌려받은 금액'
              }
              strong
            >
              {mine.diffAmount === null ? '-' : won(Math.abs(mine.diffAmount))}
            </InfoRow>
            {mine.uncoveredAmount > 0 && (
              <InfoRow label="미수금">
                {won(mine.debtAmount)} · {debtStatusLabel(mine.debtStatus)}
              </InfoRow>
            )}
            {pot.hostId === user.id && settlement.hostPayoutAmount !== null && (
              <InfoRow label="방장 정산금 (입금)" strong>
                {won(settlement.hostPayoutAmount)}
              </InfoRow>
            )}
          </dl>
          {mine.debtStatus === 'UNPAID' || mine.debtStatus === 'OVERDUE' ? (
            <Link to="/wallet/debts" className="btn btn--danger btn--block">
              <span>미수금 납부하기</span>
            </Link>
          ) : null}
          {mine.settledAt && <p className="panel__foot">{fullDateTime(mine.settledAt)} 정산</p>}
        </section>
      )}

      <section className="panel">
        <h3 className="panel__title">참여자별</h3>
        <ul className="settle-list">
          {settlement.settlements.map((row) => (
            <li key={row.id}>
              <span>
                {row.nickname}
                {row.memberId === user.id && <em> (나)</em>}
              </span>
              <Badge
                tone={
                  row.status === 'SETTLED' ? 'success' : row.status === 'HELD' ? 'brand' : 'neutral'
                }
              >
                {settlementStatusLabel(row.status)}
              </Badge>
              <strong>
                {row.fareShare === null
                  ? won(row.heldAmount)
                  : won(row.fareShare + (row.feeAmount ?? 0))}
              </strong>
            </li>
          ))}
        </ul>
      </section>

      {settlement.receiptUrl && boardedMe && (
        <section className="panel">
          <h3 className="panel__title">결제내역 사진</h3>
          <AuthImage load={loadReceipt} alt="방장이 올린 결제내역" />
          <p className="panel__foot">정산 승인 후 90일 동안 보관돼요.</p>
        </section>
      )}
    </Screen>
  );
}
