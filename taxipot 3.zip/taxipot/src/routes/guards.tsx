import { useEffect, type ReactNode } from 'react';
import { Navigate, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Brand } from '@/components/layout/Brand';
import { DeviceFrame } from '@/components/layout/DeviceFrame';
import { appEvents } from '@/lib/events';
import { useSession } from '@/store/SessionContext';
import { useToast } from '@/store/ToastContext';

function Splash() {
  return (
    <div className="splash">
      <Brand size="lg" />
      <span className="spinner" aria-label="불러오는 중" />
    </div>
  );
}

/** 휴대폰 화면 틀 */
export function PhoneShell() {
  return (
    <DeviceFrame>
      <Outlet />
    </DeviceFrame>
  );
}

/** 로그인 사용자 전용 (운영자는 운영자 콘솔로) */
export function RequireAuth() {
  const { status, user } = useSession();
  const location = useLocation();
  if (status === 'loading') return <Splash />;
  if (status === 'guest' || !user)
    return <Navigate to="/welcome" replace state={{ from: location.pathname }} />;
  if (user.role === 'ADMIN') return <Navigate to="/admin" replace />;
  return <Outlet />;
}

/** 비로그인 전용 (로그인 상태면 홈으로) */
export function GuestOnly() {
  const { status, user } = useSession();
  if (status === 'loading') return <Splash />;
  if (status === 'authed' && user)
    return <Navigate to={user.role === 'ADMIN' ? '/admin' : '/home'} replace />;
  return <Outlet />;
}

export function RequireAdmin({ children }: { children: ReactNode }) {
  const { status, user } = useSession();
  if (status === 'loading') return <Splash />;
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== 'ADMIN') return <Navigate to="/home" replace />;
  return <>{children}</>;
}

/** API 계층 이벤트 → 화면 이동 */
export function AppEventsBridge() {
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToast();

  useEffect(() => {
    const offExpired = appEvents.on('session-expired', ({ message }) => {
      toast.error(message);
      navigate('/login', { replace: true });
    });
    const offDebt = appEvents.on('unpaid-debt', () => {
      if (window.location.pathname !== '/wallet/debts') navigate('/wallet/debts');
    });
    return () => {
      offExpired();
      offDebt();
    };
  }, [navigate, toast]);

  useEffect(() => {
    document.querySelector('.screen__body')?.scrollTo({ top: 0 });
  }, [location.pathname]);

  return null;
}
