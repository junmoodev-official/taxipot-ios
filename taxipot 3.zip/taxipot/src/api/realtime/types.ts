import type { Id, PotRealtimeEvent } from '../types';

export type PotEventHandler = (event: PotRealtimeEvent) => void;

export interface RealtimeClient {
  /** `/topic/pots/{potId}` 구독. 반환 함수로 구독을 해제합니다. */
  subscribePot(potId: Id, handler: PotEventHandler): () => void;
  disconnect(): void;
}
