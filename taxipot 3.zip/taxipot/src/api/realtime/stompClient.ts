/**
 * Spring WebSocket + STOMP 실시간 통신.
 * - 엔드포인트 `/ws`, CONNECT 헤더 `Authorization: Bearer {accessToken}`
 * - 구독 `/topic/pots/{potId}` (서버가 참여자 여부 검증)
 * - 메시지 type: CHAT_MESSAGE | POT_UPDATED
 */
import { Client, type IMessage, type StompSubscription } from '@stomp/stompjs';
import { env } from '@/config/env';
import { tokenStore } from '../tokenStore';
import type { ChatMessageResponse, Id, PotRealtimeEvent } from '../types';
import type { PotEventHandler, RealtimeClient } from './types';

/** 서버 페이로드 모양이 조금 달라도 받아들이도록 정규화합니다. */
function normalize(potId: Id, raw: unknown): PotRealtimeEvent | null {
  if (!raw || typeof raw !== 'object') return null;
  const record = raw as Record<string, unknown>;
  const body = (record.payload ?? record.data ?? record.message ?? record) as Record<
    string,
    unknown
  >;
  if (record.type === 'CHAT_MESSAGE') {
    return { type: 'CHAT_MESSAGE', payload: body as unknown as ChatMessageResponse };
  }
  if (record.type === 'POT_UPDATED') {
    return { type: 'POT_UPDATED', payload: { potId } };
  }
  return null;
}

export function createStompClient(): RealtimeClient {
  const listeners = new Map<Id, Set<PotEventHandler>>();
  const subscriptions = new Map<Id, StompSubscription>();

  const client = new Client({
    brokerURL: env.wsUrl,
    reconnectDelay: 4000,
    heartbeatIncoming: 10_000,
    heartbeatOutgoing: 10_000,
    beforeConnect: async () => {
      client.connectHeaders = tokenStore.access
        ? { Authorization: `Bearer ${tokenStore.access}` }
        : {};
    },
    onConnect: () => {
      subscriptions.clear();
      listeners.forEach((_, potId) => subscribe(potId));
    },
  });

  function subscribe(potId: Id) {
    if (!client.connected || subscriptions.has(potId)) return;
    const subscription = client.subscribe(`/topic/pots/${potId}`, (message: IMessage) => {
      let parsed: unknown;
      try {
        parsed = JSON.parse(message.body);
      } catch {
        return;
      }
      const event = normalize(potId, parsed);
      if (event) listeners.get(potId)?.forEach((handler) => handler(event));
    });
    subscriptions.set(potId, subscription);
  }

  return {
    subscribePot(potId, handler) {
      const set = listeners.get(potId) ?? new Set();
      set.add(handler);
      listeners.set(potId, set);
      if (!client.active) client.activate();
      subscribe(potId);

      return () => {
        set.delete(handler);
        if (set.size > 0) return;
        listeners.delete(potId);
        subscriptions.get(potId)?.unsubscribe();
        subscriptions.delete(potId);
        if (listeners.size === 0) void client.deactivate();
      };
    },
    disconnect() {
      listeners.clear();
      subscriptions.clear();
      void client.deactivate();
    },
  };
}
