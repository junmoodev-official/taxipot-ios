/**
 * Spring Boot REST 서버용 fetch 래퍼.
 * - Authorization: Bearer {accessToken}
 * - 401 UNAUTHORIZED → 리프레시 토큰으로 1회 재발급 후 재시도 (동시 요청은 한 번만 재발급)
 * - 401 TOKEN_REVOKED → 토큰 삭제 + session-expired 이벤트
 * - 409 UNPAID_DEBT_EXISTS → unpaid-debt 이벤트 (미수금 화면 이동)
 * - 응답 Date 헤더로 서버 시각 보정 (서버 CORS 설정에 `Access-Control-Expose-Headers: Date` 필요)
 */
import { env } from '@/config/env';
import { appEvents } from '@/lib/events';
import { serverClock } from '@/lib/time';
import { ApiError, errorMessage } from './errors';
import { tokenStore } from './tokenStore';
import type { ErrorResponse, TokenResponse } from './types';

type Primitive = string | number | boolean;
export type Query = Record<string, Primitive | null | undefined>;

export interface RequestOptions {
  query?: Query;
  body?: unknown;
  form?: FormData;
  /** false 이면 Authorization 헤더를 붙이지 않습니다 (security: [] API). */
  auth?: boolean;
  /** 'blob' 이면 이미지 등 바이너리로 받습니다. */
  as?: 'json' | 'blob';
}

function buildUrl(path: string, query?: Query): string {
  const url = new URL(`${env.apiBaseUrl}${path}`);
  if (query) {
    Object.entries(query).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        url.searchParams.set(key, String(value));
      }
    });
  }
  return url.toString();
}

async function parseError(response: Response): Promise<ApiError> {
  let body: Partial<ErrorResponse> = {};
  try {
    body = (await response.json()) as Partial<ErrorResponse>;
  } catch {
    body = { code: response.status >= 500 ? 'SERVER_ERROR' : 'UNKNOWN' };
  }
  return new ApiError(response.status, body);
}

let refreshing: Promise<boolean> | null = null;

function expireSession(error: ApiError) {
  tokenStore.clear();
  appEvents.emit('session-expired', { message: errorMessage(error) });
}

async function refreshTokens(): Promise<boolean> {
  const refreshToken = tokenStore.refresh;
  if (!refreshToken) return false;
  refreshing ??= (async () => {
    try {
      const response = await fetch(buildUrl('/api/auth/refresh'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ refreshToken }),
      });
      if (!response.ok) {
        expireSession(await parseError(response));
        return false;
      }
      tokenStore.save((await response.json()) as TokenResponse);
      return true;
    } catch {
      return false;
    } finally {
      refreshing = null;
    }
  })();
  return refreshing;
}

export async function request<T>(
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE',
  path: string,
  options: RequestOptions = {},
  retried = false,
): Promise<T> {
  const { query, body, form, auth = true, as = 'json' } = options;
  const headers: Record<string, string> = {
    Accept: as === 'blob' ? 'image/*' : 'application/json',
  };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (auth && tokenStore.access) headers.Authorization = `Bearer ${tokenStore.access}`;

  let response: Response;
  try {
    response = await fetch(buildUrl(path, query), {
      method,
      headers,
      body: form ?? (body !== undefined ? JSON.stringify(body) : undefined),
    });
  } catch {
    throw new ApiError(0, { code: 'NETWORK_ERROR', message: '네트워크 연결을 확인해 주세요.' });
  }

  serverClock.sync(response.headers.get('Date'));

  if (response.ok) {
    if (response.status === 204) return undefined as T;
    return (as === 'blob' ? await response.blob() : await response.json()) as T;
  }

  const error = await parseError(response);

  if (error.status === 401 && auth) {
    if (error.code === 'TOKEN_REVOKED') {
      expireSession(error);
    } else if (!retried && (await refreshTokens())) {
      return request<T>(method, path, options, true);
    } else if (tokenStore.hasSession()) {
      expireSession(error);
    }
  }

  if (error.code === 'UNPAID_DEBT_EXISTS') {
    appEvents.emit('unpaid-debt', { debtAmount: error.num('debtAmount') });
  }

  throw error;
}

export const http = {
  get: <T>(path: string, options?: RequestOptions) => request<T>('GET', path, options),
  post: <T>(path: string, options?: RequestOptions) => request<T>('POST', path, options),
  put: <T>(path: string, options?: RequestOptions) => request<T>('PUT', path, options),
  patch: <T>(path: string, options?: RequestOptions) => request<T>('PATCH', path, options),
  delete: <T>(path: string, options?: RequestOptions) => request<T>('DELETE', path, options),
};
