/**
 * 액세스·리프레시 토큰 보관.
 * 명세: 401 TOKEN_REVOKED 를 받으면 재발급하지 말고 저장된 토큰을 지운 뒤 로그인 화면으로 이동.
 */
import type { TokenResponse } from './types';

const KEY = 'taxipot.tokens.v1';

interface StoredTokens {
  accessToken: string;
  refreshToken: string;
  /** 액세스 토큰 만료 시각(ms) */
  expiresAt: number;
}

function read(): StoredTokens | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<StoredTokens>;
    if (typeof parsed.accessToken !== 'string' || typeof parsed.refreshToken !== 'string') {
      return null;
    }
    return {
      accessToken: parsed.accessToken,
      refreshToken: parsed.refreshToken,
      expiresAt: Number(parsed.expiresAt) || 0,
    };
  } catch {
    return null;
  }
}

let cache: StoredTokens | null = read();

export const tokenStore = {
  get access(): string | null {
    return cache?.accessToken ?? null;
  },
  get refresh(): string | null {
    return cache?.refreshToken ?? null;
  },
  hasSession(): boolean {
    return cache !== null;
  },
  save(tokens: TokenResponse): void {
    cache = {
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      expiresAt: Date.now() + tokens.expiresIn * 1000,
    };
    localStorage.setItem(KEY, JSON.stringify(cache));
  },
  clear(): void {
    cache = null;
    localStorage.removeItem(KEY);
  },
};
