/**
 * 택시팟 API 명세서 3.10.0 의 components.schemas 를 그대로 옮긴 타입 정의.
 * - required + nullable 아님  → 항상 값이 있는 필드
 * - required + nullable       → `T | null`
 * - required 아님 (Request)    → `?:`
 * 일시는 모두 ISO-8601 + `+09:00` 문자열(KST)입니다.
 */

export type Id = number;
export type IsoDateTime = string;

/* ───────────────────────── 코드값 (DB '코드 정의' 시트) ───────────────────────── */

export type Gender = 'M' | 'F';
export type UserRole = 'USER' | 'ADMIN';
export type UserStatus = 'ACTIVE' | 'SUSPENDED' | 'WITHDRAWN';
export type EmailStatus = 'PENDING' | 'VERIFIED';
export type ReviewStatus = 'NOT_SUBMITTED' | 'PENDING' | 'APPROVED' | 'REJECTED';
export type GenderOption = 'ALL' | 'MALE' | 'FEMALE';
export type PotStatus = 'RECRUITING' | 'CLOSED' | 'RUNNING' | 'COMPLETED' | 'CANCELED';
export type PotMemberRole = 'HOST' | 'GUEST';
export type PreferredSeat = 'FRONT' | 'BACK_LEFT' | 'BACK_MID' | 'BACK_RIGHT' | 'NONE';
export type PotMemberStatus =
  | 'JOINED'
  | 'CANCELED'
  | 'BOARDED'
  | 'NO_SHOW'
  | 'KICKED'
  | 'REQUESTED'
  | 'REJECTED';
export type PgProvider = 'PORTONE' | 'DUMMY';
export type PaymentStatus = 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED';
export type PointType =
  | 'CHARGE'
  | 'CHARGE_REFUND'
  | 'ADMIN_ADJUST'
  | 'FARE_HOLD'
  | 'FARE_REFUND'
  | 'FARE_ADJUST'
  | 'FARE_PAY'
  | 'FEE'
  | 'HOST_PAYOUT'
  | 'DEBT_PAY'
  | 'BALANCE_EXPIRE'
  | 'WITHDRAW'
  | 'WITHDRAW_REFUND';
export type FareClaimStatus = 'NONE' | 'PENDING' | 'APPROVED' | 'REJECTED' | 'OVERDUE';
export type WithdrawalStatus = 'REQUESTED' | 'COMPLETED' | 'FAILED';
export type SettlementStatus = 'HELD' | 'SETTLED' | 'REFUNDED';
export type DebtStatus = 'NONE' | 'UNPAID' | 'OVERDUE' | 'PAID';
export type ReportType = 'NO_SHOW' | 'ABUSIVE' | 'ETC';
export type ReportStatus = 'PENDING' | 'APPROVED' | 'REJECTED';
export type MsgType = 'TEXT' | 'QUICK';
export type NotificationType =
  | 'POT'
  | 'PAYMENT'
  | 'LATE_WARNING'
  | 'KICKED'
  | 'RATING_REQUEST'
  | 'REPORT_RESULT'
  | 'SYSTEM';
export type PotSort = 'DEPARTURE_TIME' | 'DISTANCE' | 'HOST_RATING';

/* ───────────────────────── 공통 ───────────────────────── */

export interface PageMeta {
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
}

export interface Page<T> {
  content: T[];
  page: PageMeta;
}

export interface PageQuery {
  page?: number;
  size?: number;
}

export interface ErrorResponse {
  code: string;
  message: string;
  detail: Record<string, unknown> | null;
  timestamp: IsoDateTime;
}

export interface AvailabilityResponse {
  available: boolean;
  reason: 'DUPLICATE' | 'RESERVED' | null;
}

export interface UniversityResponse {
  id: Id;
  name: string;
  emailDomain: string;
}

export interface BankResponse {
  code: string;
  name: string;
}

/* ───────────────────────── Auth ───────────────────────── */

export interface SignupRequest {
  email: string;
  password: string;
  name: string;
  nickname: string;
  phone: string;
  gender: Gender;
  university: string;
  studentNo: string;
  bankCode: string;
  accountNumber: string;
  accountHolder: string;
  agreeRequired: boolean;
  agreeMarketing?: boolean;
}

export interface LoginRequest {
  email: string;
  password: string;
  fcmToken?: string;
}

export interface TokenResponse {
  accessToken: string;
  refreshToken: string;
  tokenType: string;
  expiresIn: number;
}

export interface LoginResponse extends TokenResponse {
  user: MyProfileResponse;
}

export interface RefreshRequest {
  refreshToken: string;
}

/* ───────────────────────── Verification ───────────────────────── */

export interface EmailCodeSendResponse {
  verificationId: Id;
  email: string;
  expiresAt: IsoDateTime;
}

export interface EmailCodeConfirmRequest {
  emailCode: string;
}

export interface VerificationResponse {
  id: Id;
  studentNo: string;
  emailStatus: EmailStatus;
  reviewStatus: ReviewStatus;
  rejectReason: string | null;
  reviewedAt: IsoDateTime | null;
  createdAt: IsoDateTime;
}

/* ───────────────────────── User ───────────────────────── */

export interface MyProfileResponse {
  id: Id;
  email: string;
  name: string;
  nickname: string;
  phone: string;
  gender: Gender;
  university: string;
  studentNo: string;
  isVerified: boolean;
  ratingAvg: number;
  noShowCount: number;
  reportCount: number;
  cleanStreak: number;
  role: UserRole;
  status: UserStatus;
  suspendedUntil: IsoDateTime | null;
  agreeMarketing: boolean;
  createdAt: IsoDateTime;
  updatedAt: IsoDateTime;
  nextSuspensionIn: number | null;
}

export interface UserUpdateRequest {
  nickname?: string;
  phone?: string;
  agreeMarketing?: boolean;
}

export interface PasswordChangeRequest {
  currentPassword: string;
  newPassword: string;
}

export interface WithdrawRequest {
  password: string;
  agreeBalanceForfeit: boolean;
}

export interface FcmTokenRequest {
  fcmToken: string;
}

export interface UserPublicResponse {
  id: Id;
  nickname: string;
  university: string;
  ratingAvg: number;
  isWithdrawn: boolean;
}

export interface AccountResponse {
  bankCode: string;
  bankName: string;
  maskedAccountNumber: string;
  accountHolder: string;
}

export interface AccountUpdateRequest {
  password: string;
  bankCode: string;
  accountNumber: string;
  accountHolder: string;
}

export interface MyPotHistoryResponse {
  potId: Id;
  title: string;
  departureName: string;
  destinationName: string;
  departureTime: IsoDateTime;
  potStatus: PotStatus;
  actualFare: number | null;
  myRole: PotMemberRole;
  myStatus: PotMemberStatus;
  heldAmount: number;
  fareShare: number | null;
  feeAmount: number | null;
  diffAmount: number | null;
  uncoveredAmount: number;
  debtStatus: DebtStatus;
  debtAmount: number;
  settlementStatus: SettlementStatus;
  isRated: boolean;
}

export interface MyPotHistoryQuery extends PageQuery {
  role?: PotMemberRole;
  status?: PotStatus;
}

/* ───────────────────────── Wallet ───────────────────────── */

export interface WalletResponse {
  id: Id;
  memberId: Id;
  balance: number;
  debtAmount: number;
  heldBalance: number;
  updatedAt: IsoDateTime;
}

export interface PointHistoryResponse {
  id: Id;
  potId: Id | null;
  potTitle: string | null;
  paymentId: Id | null;
  type: PointType;
  amount: number;
  balanceAfter: number;
  createdAt: IsoDateTime;
}

export interface DebtResponse {
  settlementId: Id;
  potId: Id;
  potTitle: string;
  settledAt: IsoDateTime;
  uncoveredAmount: number;
  debtStatus: DebtStatus;
  debtAmount: number;
  debtDueAt: IsoDateTime;
}

export interface DebtPayResponse {
  settlementId: Id;
  paidAmount: number;
  debtStatus: DebtStatus;
  debtAmount: number;
  balanceAfter: number;
}

export interface WithdrawalRequest {
  amount: number;
}

export interface WithdrawalResponse {
  id: Id;
  amount: number;
  bankName: string | null;
  maskedAccountNumber: string | null;
  accountHolder: string | null;
  transferProvider: string;
  transferTid: string | null;
  status: WithdrawalStatus;
  failReason: string | null;
  balanceAfter: number | null;
  requestedAt: IsoDateTime;
  completedAt: IsoDateTime | null;
}

export interface PaymentResponse {
  id: Id;
  orderId: string;
  pgProvider: PgProvider;
  pgTid: string | null;
  amount: number;
  status: PaymentStatus;
  paidAt: IsoDateTime | null;
  balanceAfter: number | null;
  createdAt: IsoDateTime;
}

/* ───────────────────────── Pot ───────────────────────── */

export interface PotListQuery extends PageQuery {
  lat?: number;
  lng?: number;
  radius?: number;
  departureName?: string;
  destinationName?: string;
  from?: IsoDateTime;
  to?: IsoDateTime;
  genderOption?: GenderOption;
  minHostRating?: number;
  sort?: PotSort;
}

export interface PotSummaryResponse {
  id: Id;
  title: string;
  hostId: Id;
  hostNickname: string;
  hostRatingAvg: number;
  departureName: string;
  departureLat: number;
  departureLng: number;
  destinationName: string;
  departureTime: IsoDateTime;
  maxMembers: number;
  currentMembers: number;
  genderOption: GenderOption;
  expectedFare: number;
  holdAmount: number;
  joinDeadline: IsoDateTime;
  status: PotStatus;
  hasCanceled: boolean;
  createdAt: IsoDateTime;
  distanceMeters: number | null;
}

export interface PotMemberResponse {
  id: Id;
  memberId: Id;
  nickname: string;
  ratingAvg: number;
  role: PotMemberRole;
  preferredSeat: PreferredSeat;
  status: PotMemberStatus;
  arrivedAt: IsoDateTime | null;
  joinedAt: IsoDateTime;
  canceledAt: IsoDateTime | null;
}

export interface PotDetailResponse {
  id: Id;
  title: string;
  hostId: Id;
  hostNickname: string;
  hostRatingAvg: number;
  departureName: string;
  departureLat: number;
  departureLng: number;
  destinationName: string;
  destinationLat: number;
  destinationLng: number;
  departureTime: IsoDateTime;
  arrivalDeadline: IsoDateTime;
  cancelDeadline: IsoDateTime;
  maxMembers: number;
  currentMembers: number;
  genderOption: GenderOption;
  expectedFare: number;
  holdAmount: number;
  actualFare: number | null;
  status: PotStatus;
  hasCanceled: boolean;
  openChatUrl: string | null;
  isJoined: boolean;
  myMemberStatus: PotMemberStatus | null;
  hasReceipt: boolean;
  fareClaimStatus: FareClaimStatus;
  fareRejectReason: string | null;
  members: PotMemberResponse[];
  createdAt: IsoDateTime;
  updatedAt: IsoDateTime;
}

export interface PotCreateRequest {
  title: string;
  departureName: string;
  departureLat: number;
  departureLng: number;
  destinationName: string;
  destinationLat: number;
  destinationLng: number;
  departureTime: IsoDateTime;
  maxMembers: 3 | 4;
  genderOption?: GenderOption;
  expectedFare: number;
  openChatUrl?: string;
  preferredSeat?: PreferredSeat;
}

export interface PotUpdateRequest {
  title?: string;
  openChatUrl?: string;
}

/* ───────────────────────── Pot member ───────────────────────── */

export interface JoinRequest {
  preferredSeat?: PreferredSeat;
}

export interface JoinResponse {
  potId: Id;
  member: PotMemberResponse;
  heldAmount: number;
  balanceAfter: number;
  potStatus: PotStatus;
}

export interface JoinRequestCreateRequest {
  lat: number;
  lng: number;
  preferredSeat?: PreferredSeat;
}

export interface JoinRequestResponse {
  potId: Id;
  memberId: Id;
  nickname: string;
  ratingAvg: number;
  preferredSeat: PreferredSeat;
  status: PotMemberStatus;
  requestedAt: IsoDateTime;
}

export interface SeatChangeRequest {
  preferredSeat: PreferredSeat;
}

export interface ArrivalRequest {
  lat: number;
  lng: number;
}

export interface ArrivalResponse {
  potId: Id;
  arrivedAt: IsoDateTime;
  distanceMeters: number;
  arrivedCount: number;
  totalMembers: number;
  allArrived: boolean;
}

/* ───────────────────────── Settlement ───────────────────────── */

export interface FareClaimResponse {
  potId: Id;
  title: string;
  hostId: Id;
  hostNickname: string;
  potStatus: PotStatus;
  fareClaimStatus: FareClaimStatus;
  expectedFare: number;
  actualFare: number | null;
  fareRatio: number | null;
  boardedCount: number;
  receiptUrl: string | null;
  startedAt: IsoDateTime | null;
  claimDeadline: IsoDateTime | null;
  fareClaimedAt: IsoDateTime | null;
  fareReviewedAt: IsoDateTime | null;
  fareRejectReason: string | null;
}

export interface FareClaimReviewRequest {
  decision: 'APPROVED' | 'REJECTED';
  rejectReason?: string | null;
}

export interface SettlementResponse {
  id: Id;
  potId: Id;
  memberId: Id;
  nickname: string;
  heldAmount: number;
  fareShare: number | null;
  feeAmount: number | null;
  diffAmount: number | null;
  uncoveredAmount: number;
  debtStatus: DebtStatus;
  debtAmount: number;
  debtDueAt: IsoDateTime | null;
  status: SettlementStatus;
  settledAt: IsoDateTime | null;
  createdAt: IsoDateTime;
}

export interface PotSettlementResponse {
  potId: Id;
  expectedFare: number;
  actualFare: number | null;
  boardedCount: number;
  hostPayoutAmount: number | null;
  receiptUrl: string | null;
  settlements: SettlementResponse[];
}

/* ───────────────────────── Rating / Report ───────────────────────── */

export interface RatingTargetResponse {
  memberId: Id;
  nickname: string;
  role: PotMemberRole;
  isRated: boolean;
}

export interface RatingItem {
  revieweeId: Id;
  noshowScore: number;
  mannerScore: number;
  communicationScore: number;
  paymentScore: number;
  badReason?: string;
}

export interface RatingCreateRequest {
  ratings: RatingItem[];
}

export interface RatingResponse {
  id: Id;
  potId: Id;
  reviewerId: Id;
  revieweeId: Id;
  noshowScore: number;
  mannerScore: number;
  communicationScore: number;
  paymentScore: number;
  avgScore: number;
  badReason: string | null;
  isDefault: boolean;
  createdAt: IsoDateTime;
}

export interface ReportCreateRequest {
  reportedId: Id;
  potId: Id;
  type: ReportType;
  reason: string;
}

export interface ReportResponse {
  id: Id;
  reportedId: Id;
  reportedNickname: string;
  potId: Id;
  type: ReportType;
  reason: string;
  status: ReportStatus;
  processedAt: IsoDateTime | null;
  createdAt: IsoDateTime;
}

/* ───────────────────────── Chat / Notification ───────────────────────── */

export interface ChatMessageRequest {
  msgType?: MsgType;
  content: string;
}

export interface ChatMessageResponse {
  id: Id;
  potId: Id;
  senderId: Id;
  senderNickname: string;
  msgType: MsgType;
  content: string;
  sentAt: IsoDateTime;
}

export interface ChatMessagePageResponse {
  messages: ChatMessageResponse[];
  nextCursor: Id | null;
  hasNext: boolean;
}

export interface QuickBlockResponse {
  code: string;
  content: string;
}

export interface NotificationResponse {
  id: Id;
  potId: Id | null;
  type: NotificationType;
  title: string;
  content: string;
  isRead: boolean;
  createdAt: IsoDateTime;
}

export interface UnreadCountResponse {
  unreadCount: number;
}

/* ───────────────────────── Admin ───────────────────────── */

export interface AdminVerificationResponse {
  id: Id;
  memberId: Id;
  memberName: string;
  memberGender: Gender;
  university: string;
  registeredStudentNo: string;
  submittedStudentNo: string;
  email: string;
  emailStatus: EmailStatus;
  captureImgUrl: string | null;
  reviewStatus: ReviewStatus;
  rejectReason: string | null;
  reviewedAt: IsoDateTime | null;
  createdAt: IsoDateTime;
}

export interface VerificationReviewRequest {
  reviewStatus: 'APPROVED' | 'REJECTED';
  rejectReason?: string;
}

export interface AdminUserResponse {
  id: Id;
  email: string | null;
  name: string | null;
  nickname: string;
  university: string;
  studentNo: string | null;
  isVerified: boolean;
  ratingAvg: number;
  noShowCount: number;
  reportCount: number;
  role: UserRole;
  status: UserStatus;
  suspendedUntil: IsoDateTime | null;
  withdrawnAt: IsoDateTime | null;
  createdAt: IsoDateTime;
}

export interface AdminReportResponse {
  id: Id;
  reporterId: Id;
  reporterNickname: string;
  reportedId: Id;
  reportedNickname: string;
  reportedReportCount: number;
  potId: Id;
  potTitle: string;
  type: ReportType;
  reason: string;
  status: ReportStatus;
  processedAt: IsoDateTime | null;
  createdAt: IsoDateTime;
}

export interface AdminUserDetailResponse extends AdminUserResponse {
  cleanStreak: number;
  walletBalance: number;
  heldBalance: number;
  debtAmount: number;
  verifications: AdminVerificationResponse[];
  receivedReports: AdminReportResponse[];
  phone: string | null;
  gender: Gender | null;
  potHistory: MyPotHistoryResponse[];
}

export interface UserStatusUpdateRequest {
  status: 'ACTIVE' | 'SUSPENDED';
  suspendedUntil?: IsoDateTime | null;
}

export interface WalletAdjustRequest {
  amount: number;
}

export interface ReportProcessRequest {
  status: 'APPROVED' | 'REJECTED';
}

export interface StatisticsResponse {
  totalPots: number;
  completedPots: number;
  canceledPots: number;
  topDepartures: { name: string; count: number }[];
  topDestinations: { name: string; count: number }[];
  hourlyTraffic: { hour: number; potCount: number }[];
}

/* ───────────────────────── Realtime (STOMP /topic/pots/{potId}) ───────────────────────── */

export type PotRealtimeEvent =
  | { type: 'CHAT_MESSAGE'; payload: ChatMessageResponse }
  | { type: 'POT_UPDATED'; payload: { potId: Id } };
