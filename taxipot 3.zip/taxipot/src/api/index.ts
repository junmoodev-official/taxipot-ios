/**
 * 화면에서 사용하는 단일 진입점.
 * VITE_API_BASE_URL 이 비어 있으면 시연용 Mock 서버, 있으면 Spring Boot 서버에 연결합니다.
 */
import { env } from '@/config/env';
import { mockApi, mockRealtime } from '@/mock/server';
import type { TaxipotApi } from './contract';
import { restApi } from './endpoints';
import { createStompClient } from './realtime/stompClient';
import type { RealtimeClient } from './realtime/types';

export const api: TaxipotApi = env.isMock ? mockApi : restApi;

export const realtime: RealtimeClient = env.isMock ? mockRealtime : createStompClient();

export { ApiError, errorMessage, isApiError } from './errors';
export { tokenStore } from './tokenStore';
export type * from './types';
