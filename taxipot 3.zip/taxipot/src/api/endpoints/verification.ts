import type { VerificationApi } from '../contract';
import { http } from '../http';
import type * as T from '../types';

export const verificationEndpoints: VerificationApi = {
  resendEmailCode: () => http.post<T.EmailCodeSendResponse>('/api/verifications/email-code'),
  confirmEmailCode: (body) =>
    http.post<T.VerificationResponse>('/api/verifications/email-code/confirm', { body }),
  submitCapture: (captureImage, studentNo) => {
    const form = new FormData();
    form.append('captureImage', captureImage);
    form.append('studentNo', studentNo);
    return http.post<T.VerificationResponse>('/api/verifications/capture', { form });
  },
  me: () => http.get<T.VerificationResponse>('/api/verifications/me'),
};
