import type { AuthApi } from '../contract';
import { http } from '../http';
import type * as T from '../types';

export const authEndpoints: AuthApi = {
  signup: (body) => http.post<T.LoginResponse>('/api/auth/signup', { body, auth: false }),
  checkNickname: (nickname) =>
    http.get<T.AvailabilityResponse>('/api/auth/nickname-check', {
      query: { nickname },
      auth: false,
    }),
  universities: () => http.get<T.UniversityResponse[]>('/api/universities', { auth: false }),
  banks: () => http.get<T.BankResponse[]>('/api/banks', { auth: false }),
  login: (body) => http.post<T.LoginResponse>('/api/auth/login', { body, auth: false }),
  logout: () => http.post<void>('/api/auth/logout'),
};
