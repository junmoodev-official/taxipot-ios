import type { ChatApi, NotificationsApi, ReportsApi } from '../contract';
import { http } from '../http';
import type * as T from '../types';

export const reportsEndpoints: ReportsApi = {
  create: (body) => http.post<T.ReportResponse>('/api/reports', { body }),
};

export const chatEndpoints: ChatApi = {
  messages: (potId, cursor, size = 30) =>
    http.get<T.ChatMessagePageResponse>(`/api/pots/${potId}/messages`, {
      query: { cursor, size },
    }),
  send: (potId, body) => http.post<T.ChatMessageResponse>(`/api/pots/${potId}/messages`, { body }),
  quickBlocks: () => http.get<T.QuickBlockResponse[]>('/api/quick-blocks'),
};

export const notificationsEndpoints: NotificationsApi = {
  list: (query = {}) =>
    http.get<T.Page<T.NotificationResponse>>('/api/notifications', { query: { ...query } }),
  unreadCount: () => http.get<T.UnreadCountResponse>('/api/notifications/unread-count'),
  read: (notificationId) => http.patch<void>(`/api/notifications/${notificationId}/read`),
  readAll: () => http.patch<void>('/api/notifications/read-all'),
};
