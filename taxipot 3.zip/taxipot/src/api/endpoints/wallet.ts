import type { WalletApi } from '../contract';
import { http } from '../http';
import type * as T from '../types';

export const walletEndpoints: WalletApi = {
  get: () => http.get<T.WalletResponse>('/api/wallet'),
  history: (query = {}) =>
    http.get<T.Page<T.PointHistoryResponse>>('/api/wallet/history', { query: { ...query } }),
  debts: () => http.get<T.DebtResponse[]>('/api/wallet/debts'),
  payDebt: (settlementId) => http.post<T.DebtPayResponse>(`/api/wallet/debts/${settlementId}/pay`),
  withdraw: (body) => http.post<T.WithdrawalResponse>('/api/wallet/withdrawals', { body }),
  withdrawals: (query = {}) =>
    http.get<T.Page<T.WithdrawalResponse>>('/api/wallet/withdrawals', { query: { ...query } }),
  payments: (query = {}) =>
    http.get<T.Page<T.PaymentResponse>>('/api/payments', { query: { ...query } }),
};
