import type { UsersApi } from '../contract';
import { http } from '../http';
import type * as T from '../types';

export const usersEndpoints: UsersApi = {
  me: () => http.get<T.MyProfileResponse>('/api/users/me'),
  update: (body) => http.patch<T.MyProfileResponse>('/api/users/me', { body }),
  withdraw: (body) => http.post<void>('/api/users/me/withdraw', { body }),
  changePassword: (body) => http.patch<T.TokenResponse>('/api/users/me/password', { body }),
  account: () => http.get<T.AccountResponse>('/api/users/me/account'),
  updateAccount: (body) => http.put<T.AccountResponse>('/api/users/me/account', { body }),
  updateFcmToken: (body) => http.put<void>('/api/users/me/fcm-token', { body }),
  myPots: (query = {}) =>
    http.get<T.Page<T.MyPotHistoryResponse>>('/api/users/me/pots', { query: { ...query } }),
  myReports: (query = {}) =>
    http.get<T.Page<T.ReportResponse>>('/api/users/me/reports', { query: { ...query } }),
  publicProfile: (userId) => http.get<T.UserPublicResponse>(`/api/users/${userId}`),
};
