import type { TaxipotApi } from '../contract';
import { adminEndpoints } from './admin';
import { authEndpoints } from './auth';
import { potsEndpoints } from './pots';
import { chatEndpoints, notificationsEndpoints, reportsEndpoints } from './social';
import { usersEndpoints } from './users';
import { verificationEndpoints } from './verification';
import { walletEndpoints } from './wallet';

/** Spring Boot 서버(API 명세 3.10.0)에 연결하는 실제 구현 */
export const restApi: TaxipotApi = {
  auth: authEndpoints,
  verification: verificationEndpoints,
  users: usersEndpoints,
  wallet: walletEndpoints,
  pots: potsEndpoints,
  reports: reportsEndpoints,
  chat: chatEndpoints,
  notifications: notificationsEndpoints,
  admin: adminEndpoints,
};
