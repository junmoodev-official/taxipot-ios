import type { PotsApi } from '../contract';
import { http } from '../http';
import type * as T from '../types';

const pot = (potId: T.Id) => `/api/pots/${potId}`;

export const potsEndpoints: PotsApi = {
  list: (query = {}) =>
    http.get<T.Page<T.PotSummaryResponse>>('/api/pots', { query: { ...query } }),
  create: (body) => http.post<T.PotDetailResponse>('/api/pots', { body }),
  detail: (potId) => http.get<T.PotDetailResponse>(pot(potId)),
  update: (potId, body) => http.patch<T.PotDetailResponse>(pot(potId), { body }),
  cancel: (potId) => http.delete<void>(pot(potId)),
  start: (potId) => http.post<T.PotDetailResponse>(`${pot(potId)}/start`),

  join: (potId, body = {}) => http.post<T.JoinResponse>(`${pot(potId)}/members`, { body }),
  leave: (potId) => http.delete<void>(`${pot(potId)}/members/me`),
  changeSeat: (potId, body) =>
    http.patch<T.PotMemberResponse>(`${pot(potId)}/members/me/seat`, { body }),
  arrive: (potId, body) =>
    http.post<T.ArrivalResponse>(`${pot(potId)}/members/me/arrival`, { body }),
  kick: (potId, userId) => http.post<void>(`${pot(potId)}/members/${userId}/kick`),

  requestJoin: (potId, body) =>
    http.post<T.JoinRequestResponse>(`${pot(potId)}/join-requests`, { body }),
  joinRequests: (potId) => http.get<T.JoinRequestResponse[]>(`${pot(potId)}/join-requests`),
  withdrawJoinRequest: (potId) => http.delete<void>(`${pot(potId)}/join-requests/me`),
  acceptJoinRequest: (potId, userId) =>
    http.post<T.JoinResponse>(`${pot(potId)}/join-requests/${userId}/accept`),
  rejectJoinRequest: (potId, userId) =>
    http.post<void>(`${pot(potId)}/join-requests/${userId}/reject`),

  claimFare: (potId, actualFare, receiptImage) => {
    const form = new FormData();
    form.append('actualFare', String(actualFare));
    form.append('receiptImage', receiptImage);
    return http.post<T.FareClaimResponse>(`${pot(potId)}/fare-claim`, { form });
  },
  settlement: (potId) => http.get<T.PotSettlementResponse>(`${pot(potId)}/settlement`),
  receipt: (potId) => http.get<Blob>(`${pot(potId)}/receipt`, { as: 'blob' }),

  ratingTargets: (potId) => http.get<T.RatingTargetResponse[]>(`${pot(potId)}/ratings/targets`),
  rate: (potId, body) => http.post<T.RatingResponse[]>(`${pot(potId)}/ratings`, { body }),
};
