import type { AdminApi } from '../contract';
import { http } from '../http';
import type * as T from '../types';

export const adminEndpoints: AdminApi = {
  verifications: (query = {}) =>
    http.get<T.Page<T.AdminVerificationResponse>>('/api/admin/verifications', {
      query: { ...query },
    }),
  verification: (id) => http.get<T.AdminVerificationResponse>(`/api/admin/verifications/${id}`),
  reviewVerification: (id, body) =>
    http.patch<T.AdminVerificationResponse>(`/api/admin/verifications/${id}`, { body }),
  verificationCapture: (id) =>
    http.get<Blob>(`/api/admin/verifications/${id}/capture`, { as: 'blob' }),

  users: (query = {}) =>
    http.get<T.Page<T.AdminUserResponse>>('/api/admin/users', { query: { ...query } }),
  user: (userId) => http.get<T.AdminUserDetailResponse>(`/api/admin/users/${userId}`),
  userPots: (userId, query = {}) =>
    http.get<T.Page<T.MyPotHistoryResponse>>(`/api/admin/users/${userId}/pots`, {
      query: { ...query },
    }),
  updateUserStatus: (userId, body) =>
    http.patch<T.AdminUserResponse>(`/api/admin/users/${userId}/status`, { body }),
  adjustWallet: (userId, body) =>
    http.patch<T.WalletResponse>(`/api/admin/users/${userId}/wallet`, { body }),

  reports: (query = {}) =>
    http.get<T.Page<T.AdminReportResponse>>('/api/admin/reports', { query: { ...query } }),
  processReport: (reportId, body) =>
    http.patch<T.AdminReportResponse>(`/api/admin/reports/${reportId}`, { body }),

  pots: (query = {}) =>
    http.get<T.Page<T.PotSummaryResponse>>('/api/admin/pots', { query: { ...query } }),
  fareClaims: (query = {}) =>
    http.get<T.Page<T.FareClaimResponse>>('/api/admin/fare-claims', { query: { ...query } }),
  reviewFareClaim: (potId, body) =>
    http.patch<T.FareClaimResponse>(`/api/admin/pots/${potId}/fare-claim`, { body }),
  receipt: (potId) => http.get<Blob>(`/api/admin/pots/${potId}/receipt`, { as: 'blob' }),
  statistics: (query = {}) =>
    http.get<T.StatisticsResponse>('/api/admin/statistics', { query: { ...query } }),
};
