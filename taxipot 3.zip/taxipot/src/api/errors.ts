/**
 * 공통 ErrorResponse → 화면 안내 문구.
 * 명세 'ErrorResponse.detail 규격'에 맞춰 detail 값을 문구에 반영합니다.
 */
import { clock, dayAndTime, won } from '@/lib/format';
import { genderOptionLabel } from '@/lib/labels';
import type { ErrorResponse } from './types';

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly detail: Record<string, unknown> | null;

  constructor(status: number, body: Partial<ErrorResponse>) {
    super(body.message || '요청을 처리하지 못했어요.');
    this.name = 'ApiError';
    this.status = status;
    this.code = body.code || 'UNKNOWN';
    this.detail = body.detail ?? null;
  }

  num(key: string): number | undefined {
    const value = this.detail?.[key];
    return typeof value === 'number' ? value : undefined;
  }

  str(key: string): string | undefined {
    const value = this.detail?.[key];
    return typeof value === 'string' ? value : undefined;
  }
}

/** 서버 메시지보다 우선해서 보여 줄 고정 문구 */
const FIXED_MESSAGES: Record<string, string> = {
  INVALID_INPUT: '입력값을 다시 확인해 주세요.',
  INVALID_DATETIME_FORMAT: '일시 형식이 올바르지 않아요.',
  TERMS_NOT_AGREED: '필수 약관에 동의해 주세요.',
  EXPIRED_EMAIL_CODE: '인증코드가 만료됐어요. 재발송해 주세요.',
  EMAIL_CODE_ATTEMPTS_EXCEEDED: '인증코드를 5번 틀렸어요. 새 코드를 재발송해 주세요.',
  STUDENT_NO_MISMATCH: '제출한 학번이 가입 학번과 달라요.',
  RESERVED_NICKNAME: '이후 사용할 수 없는 닉네임입니다.',
  UNSUPPORTED_UNIVERSITY: '아직 가입할 수 없는 학교예요.',
  EMAIL_DOMAIN_MISMATCH: '선택한 학교의 이메일 주소만 사용할 수 있어요.',
  ACCOUNT_HOLDER_MISMATCH: '예금주는 가입한 이름과 같아야 해요.',
  RECEIPT_REQUIRED: '결제내역 사진을 첨부해 주세요.',
  BALANCE_FORFEIT_NOT_AGREED: '잔액 소멸 안내에 동의해 주세요.',
  BAD_REASON_REQUIRED: '별점이 낮은 동승자에게는 사유를 적어 주세요.',
  SELF_RATING_NOT_ALLOWED: '자기 자신은 평가할 수 없어요.',
  SELF_REPORT_NOT_ALLOWED: '자기 자신은 신고할 수 없어요.',
  REJECT_REASON_REQUIRED: '반려 사유를 입력해 주세요.',
  INVALID_QUICK_MESSAGE: '사용할 수 없는 빠른 메시지예요.',
  UNAUTHORIZED: '로그인이 필요해요.',
  INVALID_CREDENTIALS: '이메일 또는 비밀번호가 맞지 않아요.',
  TOKEN_REVOKED: '다른 기기에서 비밀번호가 바뀌었거나 탈퇴한 계정이에요. 다시 로그인해 주세요.',
  FORBIDDEN: '접근 권한이 없어요.',
  WITHDRAWN_USER: '탈퇴한 계정이에요.',
  NOT_POT_HOST: '방장만 할 수 있어요.',
  NOT_POT_MEMBER: '이 택시팟 참여자만 할 수 있어요.',
  KICKED_FROM_POT: '이 택시팟에서 내보내져 다시 참여할 수 없어요.',
  HOST_CANNOT_LEAVE: '방장은 참여 취소 대신 방을 취소해 주세요.',
  EMAIL_NOT_VERIFIED: '이메일 인증을 먼저 완료해 주세요.',
  REPORT_NOT_ELIGIBLE: '끝까지 함께 탑승한 동승자만 신고할 수 있어요.',
  JOIN_REQUEST_REJECTED: '방장이 입장 요청을 거절한 택시팟이에요.',
  NOT_FOUND: '요청한 정보를 찾을 수 없어요.',
  DUPLICATE_EMAIL: '이미 가입된 이메일이에요.',
  DUPLICATE_NICKNAME: '이미 사용 중인 닉네임이에요.',
  DUPLICATE_STUDENT_NO: '이미 가입된 학번이에요.',
  ALREADY_VERIFIED: '이미 인증을 마쳤어요.',
  REVIEW_IN_PROGRESS: '제출한 캡처본을 심사하고 있어요.',
  ALREADY_JOINED: '이미 참여 중인 택시팟이에요.',
  INVALID_POT_STATUS: '지금 상태에서는 할 수 없는 작업이에요.',
  ALREADY_ARRIVED: '이미 도착 확인을 했어요.',
  MEMBER_ALREADY_ARRIVED: '도착 확인한 동승자는 내보낼 수 없어요.',
  NOT_ALL_ARRIVED: '남은 참여자가 모두 도착 확인해야 출발할 수 있어요.',
  NOT_ENOUGH_MEMBERS: '2명 이상이어야 출발할 수 있어요.',
  ALREADY_SETTLED: '이미 정산된 택시팟이에요.',
  ALREADY_RATED: '이미 평가한 동승자가 있어요.',
  DUPLICATE_REPORT: '이미 신고한 동승자예요.',
  ALREADY_REVIEWED: '이미 심사가 끝난 건이에요.',
  ALREADY_PROCESSED: '이미 처리된 건이에요.',
  JOIN_REQUEST_NOT_AVAILABLE: '아직 일반 참여가 가능해요. 참여하기를 이용해 주세요.',
  ALREADY_REQUESTED: '이미 입장을 요청했어요. 방장의 수락을 기다려 주세요.',
  JOIN_REQUEST_NOT_FOUND: '대기 중인 입장 요청이 없어요.',
  NO_DEBT: '납부할 미수금이 없어요.',
  CAPTURE_NOT_SUBMITTED: '캡처본이 제출되지 않았어요.',
  RATING_PERIOD_EXPIRED: '평가 기간(정산 후 24시간)이 지났어요.',
  ACCOUNT_NOT_REGISTERED: '출금 계좌를 먼저 등록해 주세요.',
  FARE_CLAIM_IN_REVIEW: '운영자가 청구 내용을 확인하고 있어요.',
  FARE_CLAIM_NOT_PENDING: '확인 대기 중인 청구가 아니에요.',
  PAYMENT_CHECK_FAILED: '결제 상태를 확인하지 못했어요. 잠시 후 다시 시도해 주세요.',
  TOO_MANY_REQUESTS: '60초 후에 다시 요청할 수 있어요.',
  NETWORK_ERROR: '네트워크 연결을 확인해 주세요.',
  SERVER_ERROR: '서버에 일시적인 문제가 생겼어요. 잠시 후 다시 시도해 주세요.',
};

/** detail 이 있는 코드는 상황에 맞는 문구를 만듭니다. */
function detailedMessage(error: ApiError): string | null {
  switch (error.code) {
    case 'INSUFFICIENT_BALANCE': {
      const shortage = error.num('shortageAmount');
      return shortage !== undefined
        ? `지갑 잔액이 ${won(shortage)} 부족해요. 충전 후 다시 시도해 주세요.`
        : '지갑 잔액이 부족해요.';
    }
    case 'SUSPENDED_USER': {
      const until = error.str('suspendedUntil');
      return until
        ? `${dayAndTime(until)}까지 방 생성·참여가 제한돼요.`
        : '이용이 정지된 계정이에요. 운영자에게 문의해 주세요.';
    }
    case 'OUT_OF_ARRIVAL_RANGE': {
      const d = error.num('distanceMeters');
      const r = error.num('allowedRadiusMeters') ?? 50;
      return d !== undefined
        ? `출발지에서 ${Math.round(d)}m 떨어져 있어요. ${r}m 안에서 다시 시도해 주세요.`
        : `출발지 ${r}m 안에서만 확인할 수 있어요.`;
    }
    case 'CANCEL_TIME_EXPIRED': {
      const deadline = error.str('cancelDeadline');
      return deadline
        ? `취소는 ${clock(deadline)}까지만 가능했어요.`
        : '출발 10분 전부터는 취소할 수 없어요.';
    }
    case 'ARRIVAL_DEADLINE_PASSED':
      return '집결 기한이 지나 도착 확인을 할 수 없어요.';
    case 'ACTIVE_POT_EXISTS':
      return '이미 진행 중인 다른 택시팟이 있어요. 한 번에 하나만 이용할 수 있어요.';
    case 'GENDER_RESTRICTED':
      return `${genderOptionLabel(error.str('genderOption'))} 참여할 수 있는 택시팟이에요.`;
    case 'POT_FULL':
      return '자리가 모두 찼어요.';
    case 'NOT_VERIFIED':
      return '학생 인증을 마쳐야 택시팟을 만들거나 참여할 수 있어요.';
    case 'WALLET_LIMIT_EXCEEDED': {
      const available = error.num('availableAmount');
      return available !== undefined
        ? `지갑 한도(50만 원)를 넘어요. ${won(available)}까지 가능해요.`
        : '지갑 잔액 한도(50만 원)를 넘어요.';
    }
    case 'INVALID_EMAIL_CODE': {
      const left = error.num('remainingAttempts');
      if (left === 0) return '인증코드를 5번 틀렸어요. 새 코드를 재발송해 주세요.';
      return left !== undefined
        ? `인증코드가 맞지 않아요. ${left}번 더 시도할 수 있어요.`
        : '인증코드가 맞지 않아요.';
    }
    case 'JOIN_DEADLINE_PASSED':
      return '참여 마감이 지났어요. 출발지 근처라면 입장 요청을 보내 주세요.';
    case 'DEPARTURE_TIME_TOO_SOON': {
      const min = error.str('minDepartureTime');
      return min
        ? `출발 시각은 ${dayAndTime(min)} 이후로 정해 주세요.`
        : '출발 15분 전까지만 만들 수 있어요.';
    }
    case 'DEPARTURE_TIME_TOO_FAR': {
      const max = error.str('maxDepartureTime');
      return max
        ? `출발 시각은 ${dayAndTime(max)} 이전으로 정해 주세요.`
        : '24시간 이내 출발만 만들 수 있어요.';
    }
    case 'UNPAID_DEBT_EXISTS': {
      const amount = error.num('debtAmount');
      return amount !== undefined
        ? `미수금 ${won(amount)}을 먼저 납부해 주세요.`
        : '미수금을 먼저 납부해 주세요.';
    }
    default:
      return null;
  }
}

export function errorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    return detailedMessage(error) ?? FIXED_MESSAGES[error.code] ?? error.message;
  }
  if (error instanceof Error && error.message) return error.message;
  return '알 수 없는 오류가 발생했어요.';
}

export function isApiError(error: unknown, ...codes: string[]): error is ApiError {
  return error instanceof ApiError && (codes.length === 0 || codes.includes(error.code));
}
