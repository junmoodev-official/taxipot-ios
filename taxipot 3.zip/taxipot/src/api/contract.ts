/**
 * 화면이 사용하는 API 계약.
 * 실제 서버(endpoints/*)와 시연용 Mock 서버(mock/server.ts)가 같은 계약을 구현합니다.
 * 메서드 이름 옆 주석은 명세의 HTTP 경로입니다.
 */
import type * as T from './types';

export interface AuthApi {
  /** POST /api/auth/signup */
  signup(body: T.SignupRequest): Promise<T.LoginResponse>;
  /** GET /api/auth/nickname-check */
  checkNickname(nickname: string): Promise<T.AvailabilityResponse>;
  /** GET /api/universities */
  universities(): Promise<T.UniversityResponse[]>;
  /** GET /api/banks */
  banks(): Promise<T.BankResponse[]>;
  /** POST /api/auth/login */
  login(body: T.LoginRequest): Promise<T.LoginResponse>;
  /** POST /api/auth/logout */
  logout(): Promise<void>;
}

export interface VerificationApi {
  /** POST /api/verifications/email-code */
  resendEmailCode(): Promise<T.EmailCodeSendResponse>;
  /** POST /api/verifications/email-code/confirm */
  confirmEmailCode(body: T.EmailCodeConfirmRequest): Promise<T.VerificationResponse>;
  /** POST /api/verifications/capture (multipart) */
  submitCapture(captureImage: File, studentNo: string): Promise<T.VerificationResponse>;
  /** GET /api/verifications/me */
  me(): Promise<T.VerificationResponse>;
}

export interface UsersApi {
  /** GET /api/users/me */
  me(): Promise<T.MyProfileResponse>;
  /** PATCH /api/users/me */
  update(body: T.UserUpdateRequest): Promise<T.MyProfileResponse>;
  /** POST /api/users/me/withdraw */
  withdraw(body: T.WithdrawRequest): Promise<void>;
  /** PATCH /api/users/me/password */
  changePassword(body: T.PasswordChangeRequest): Promise<T.TokenResponse>;
  /** GET /api/users/me/account */
  account(): Promise<T.AccountResponse>;
  /** PUT /api/users/me/account */
  updateAccount(body: T.AccountUpdateRequest): Promise<T.AccountResponse>;
  /** PUT /api/users/me/fcm-token */
  updateFcmToken(body: T.FcmTokenRequest): Promise<void>;
  /** GET /api/users/me/pots */
  myPots(query?: T.MyPotHistoryQuery): Promise<T.Page<T.MyPotHistoryResponse>>;
  /** GET /api/users/me/reports */
  myReports(query?: T.PageQuery): Promise<T.Page<T.ReportResponse>>;
  /** GET /api/users/{userId} */
  publicProfile(userId: T.Id): Promise<T.UserPublicResponse>;
}

export interface WalletApi {
  /** GET /api/wallet */
  get(): Promise<T.WalletResponse>;
  /** GET /api/wallet/history */
  history(query?: T.PageQuery & { type?: T.PointType }): Promise<T.Page<T.PointHistoryResponse>>;
  /** GET /api/wallet/debts */
  debts(): Promise<T.DebtResponse[]>;
  /** POST /api/wallet/debts/{settlementId}/pay */
  payDebt(settlementId: T.Id): Promise<T.DebtPayResponse>;
  /** POST /api/wallet/withdrawals */
  withdraw(body: T.WithdrawalRequest): Promise<T.WithdrawalResponse>;
  /** GET /api/wallet/withdrawals */
  withdrawals(query?: T.PageQuery): Promise<T.Page<T.WithdrawalResponse>>;
  /** GET /api/payments (PORTONE 충전 내역 — 캡스톤 범위 외, 조회만) */
  payments(query?: T.PageQuery): Promise<T.Page<T.PaymentResponse>>;
}

export interface PotsApi {
  /** GET /api/pots */
  list(query?: T.PotListQuery): Promise<T.Page<T.PotSummaryResponse>>;
  /** POST /api/pots */
  create(body: T.PotCreateRequest): Promise<T.PotDetailResponse>;
  /** GET /api/pots/{potId} */
  detail(potId: T.Id): Promise<T.PotDetailResponse>;
  /** PATCH /api/pots/{potId} */
  update(potId: T.Id, body: T.PotUpdateRequest): Promise<T.PotDetailResponse>;
  /** DELETE /api/pots/{potId} */
  cancel(potId: T.Id): Promise<void>;
  /** POST /api/pots/{potId}/start */
  start(potId: T.Id): Promise<T.PotDetailResponse>;
  /** POST /api/pots/{potId}/members */
  join(potId: T.Id, body?: T.JoinRequest): Promise<T.JoinResponse>;
  /** DELETE /api/pots/{potId}/members/me */
  leave(potId: T.Id): Promise<void>;
  /** PATCH /api/pots/{potId}/members/me/seat */
  changeSeat(potId: T.Id, body: T.SeatChangeRequest): Promise<T.PotMemberResponse>;
  /** POST /api/pots/{potId}/members/me/arrival */
  arrive(potId: T.Id, body: T.ArrivalRequest): Promise<T.ArrivalResponse>;
  /** POST /api/pots/{potId}/members/{userId}/kick */
  kick(potId: T.Id, userId: T.Id): Promise<void>;
  /** POST /api/pots/{potId}/join-requests */
  requestJoin(potId: T.Id, body: T.JoinRequestCreateRequest): Promise<T.JoinRequestResponse>;
  /** GET /api/pots/{potId}/join-requests */
  joinRequests(potId: T.Id): Promise<T.JoinRequestResponse[]>;
  /** DELETE /api/pots/{potId}/join-requests/me */
  withdrawJoinRequest(potId: T.Id): Promise<void>;
  /** POST /api/pots/{potId}/join-requests/{userId}/accept */
  acceptJoinRequest(potId: T.Id, userId: T.Id): Promise<T.JoinResponse>;
  /** POST /api/pots/{potId}/join-requests/{userId}/reject */
  rejectJoinRequest(potId: T.Id, userId: T.Id): Promise<void>;
  /** POST /api/pots/{potId}/fare-claim (multipart) */
  claimFare(potId: T.Id, actualFare: number, receiptImage: File): Promise<T.FareClaimResponse>;
  /** GET /api/pots/{potId}/settlement */
  settlement(potId: T.Id): Promise<T.PotSettlementResponse>;
  /** GET /api/pots/{potId}/receipt (image) */
  receipt(potId: T.Id): Promise<Blob>;
  /** GET /api/pots/{potId}/ratings/targets */
  ratingTargets(potId: T.Id): Promise<T.RatingTargetResponse[]>;
  /** POST /api/pots/{potId}/ratings */
  rate(potId: T.Id, body: T.RatingCreateRequest): Promise<T.RatingResponse[]>;
}

export interface ReportsApi {
  /** POST /api/reports */
  create(body: T.ReportCreateRequest): Promise<T.ReportResponse>;
}

export interface ChatApi {
  /** GET /api/pots/{potId}/messages */
  messages(potId: T.Id, cursor?: T.Id | null, size?: number): Promise<T.ChatMessagePageResponse>;
  /** POST /api/pots/{potId}/messages */
  send(potId: T.Id, body: T.ChatMessageRequest): Promise<T.ChatMessageResponse>;
  /** GET /api/quick-blocks */
  quickBlocks(): Promise<T.QuickBlockResponse[]>;
}

export interface NotificationsApi {
  /** GET /api/notifications */
  list(query?: T.PageQuery & { unreadOnly?: boolean }): Promise<T.Page<T.NotificationResponse>>;
  /** GET /api/notifications/unread-count */
  unreadCount(): Promise<T.UnreadCountResponse>;
  /** PATCH /api/notifications/{notificationId}/read */
  read(notificationId: T.Id): Promise<void>;
  /** PATCH /api/notifications/read-all */
  readAll(): Promise<void>;
}

export interface AdminApi {
  /** GET /api/admin/verifications */
  verifications(
    query?: T.PageQuery & { reviewStatus?: T.ReviewStatus },
  ): Promise<T.Page<T.AdminVerificationResponse>>;
  /** GET /api/admin/verifications/{id} */
  verification(id: T.Id): Promise<T.AdminVerificationResponse>;
  /** PATCH /api/admin/verifications/{id} */
  reviewVerification(
    id: T.Id,
    body: T.VerificationReviewRequest,
  ): Promise<T.AdminVerificationResponse>;
  /** GET /api/admin/verifications/{id}/capture (image) */
  verificationCapture(id: T.Id): Promise<Blob>;
  /** GET /api/admin/users */
  users(
    query?: T.PageQuery & { keyword?: string; status?: T.UserStatus },
  ): Promise<T.Page<T.AdminUserResponse>>;
  /** GET /api/admin/users/{userId} */
  user(userId: T.Id): Promise<T.AdminUserDetailResponse>;
  /** GET /api/admin/users/{userId}/pots */
  userPots(userId: T.Id, query?: T.PageQuery): Promise<T.Page<T.MyPotHistoryResponse>>;
  /** PATCH /api/admin/users/{userId}/status */
  updateUserStatus(userId: T.Id, body: T.UserStatusUpdateRequest): Promise<T.AdminUserResponse>;
  /** PATCH /api/admin/users/{userId}/wallet */
  adjustWallet(userId: T.Id, body: T.WalletAdjustRequest): Promise<T.WalletResponse>;
  /** GET /api/admin/reports */
  reports(
    query?: T.PageQuery & { status?: T.ReportStatus; type?: T.ReportType },
  ): Promise<T.Page<T.AdminReportResponse>>;
  /** PATCH /api/admin/reports/{reportId} */
  processReport(reportId: T.Id, body: T.ReportProcessRequest): Promise<T.AdminReportResponse>;
  /** GET /api/admin/pots */
  pots(
    query?: T.PageQuery & { status?: T.PotStatus; from?: string; to?: string },
  ): Promise<T.Page<T.PotSummaryResponse>>;
  /** GET /api/admin/fare-claims */
  fareClaims(
    query?: T.PageQuery & { fareClaimStatus?: T.FareClaimStatus },
  ): Promise<T.Page<T.FareClaimResponse>>;
  /** PATCH /api/admin/pots/{potId}/fare-claim */
  reviewFareClaim(potId: T.Id, body: T.FareClaimReviewRequest): Promise<T.FareClaimResponse>;
  /** GET /api/admin/pots/{potId}/receipt (image) */
  receipt(potId: T.Id): Promise<Blob>;
  /** GET /api/admin/statistics */
  statistics(query?: { from?: string; to?: string; limit?: number }): Promise<T.StatisticsResponse>;
}

export interface TaxipotApi {
  auth: AuthApi;
  verification: VerificationApi;
  users: UsersApi;
  wallet: WalletApi;
  pots: PotsApi;
  reports: ReportsApi;
  chat: ChatApi;
  notifications: NotificationsApi;
  admin: AdminApi;
}
