/** 빌드 시점 환경 변수를 한 곳에서 정규화합니다. */

function clean(value: string | undefined): string {
  return (value ?? '').trim().replace(/\/+$/, '');
}

const apiBaseUrl = clean(import.meta.env.VITE_API_BASE_URL);
const wsUrl = clean(import.meta.env.VITE_WS_URL);

export const env = {
  /** Spring Boot API 서버 주소. 비어 있으면 시연용 Mock 서버를 사용합니다. */
  apiBaseUrl,
  /** STOMP WebSocket 엔드포인트 (`/ws`). */
  wsUrl: wsUrl || (apiBaseUrl ? `${apiBaseUrl.replace(/^http/, 'ws')}/ws` : ''),
  /** 카카오맵 JavaScript 키 (선택). */
  kakaoMapKey: (import.meta.env.VITE_KAKAO_MAP_KEY ?? '').trim(),
  /** true 이면 실제 서버 대신 브라우저 안의 Mock 서버로 동작합니다. */
  isMock: apiBaseUrl === '',
} as const;
