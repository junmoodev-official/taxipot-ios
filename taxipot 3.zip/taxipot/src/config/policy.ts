/**
 * 서버 설정값(application.yml)과 같은 정책 상수.
 * 화면 안내와 사전 검증에만 사용하며 최종 판정은 항상 서버가 합니다.
 */
export const POLICY = {
  /** 1인 수수료 (정산 시 탑승자에게만) */
  feeAmount: 1_000,
  /** 예치 여유분 비율 1.2 = 12 / 10 (app.pot.hold-buffer-rate) */
  holdBufferNumerator: 12,
  holdBufferDenominator: 10,
  /** 방 생성: 출발 15분 전 ~ 24시간 이내 */
  minLeadMinutes: 15,
  maxAdvanceHours: 24,
  /** 참여 마감 = 집결 기한 = 출발 5분 전 */
  arrivalDeadlineMinutes: 5,
  /** 출발 10분 전부터 참여 취소·방 취소 불가 */
  cancelDeadlineMinutes: 10,
  /** 도착 인정 반경(m) */
  arrivalRadiusMeters: 50,
  /** 탑승 시작 후 실요금 청구 기한(시간) */
  fareClaimDeadlineHours: 24,
  /** 정산 후 평가 가능 기간(시간) */
  ratingPeriodHours: 24,
  /** 미수금 납부 기한(일) */
  debtDueDays: 3,
  /** 미도착 정지(분) */
  noShowSuspendMinutes: 15,
  /** 이메일 인증코드 유효(초) / 재발송 간격(초) / 입력 시도 횟수 */
  emailCodeTtlSeconds: 60,
  emailResendIntervalSeconds: 60,
  emailCodeMaxAttempts: 5,
  /** 지갑 잔액(balance + held) 상한 */
  walletMaxBalance: 500_000,
  /** 출금 1회 범위 */
  minWithdrawal: 1_000,
  maxWithdrawal: 1_000_000,
  /** 택시 요금 최대 */
  maxFare: 500_000,
  /** 닉네임 예약어 */
  reservedNicknamePrefix: '탈퇴회원_',
  /** 업로드 이미지 최대 크기(byte) */
  maxUploadBytes: 10 * 1024 * 1024,
} as const;

/** 1인 예치액 = floor(expected_fare × 12 ÷ (max_members × 10)) + 수수료 */
export function holdAmountOf(expectedFare: number, maxMembers: number): number {
  const share = Math.floor(
    (expectedFare * POLICY.holdBufferNumerator) / (maxMembers * POLICY.holdBufferDenominator),
  );
  return share + POLICY.feeAmount;
}
