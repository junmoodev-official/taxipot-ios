# API 명세 3.10.0 ↔ 코드 대응표

`src/api/contract.ts` 의 주석에서 자동 생성했습니다. 화면은 항상 `api.*` 만 호출하고,
실제 HTTP 호출은 `src/api/endpoints/*.ts`, 시연용 구현은 `src/mock/server.ts` 에 있습니다.

| 메서드 | 경로 | 비고 | 클라이언트 함수 |
| --- | --- | --- | --- |
| POST | `/api/auth/signup` |  | `api.auth.signup` |
| GET | `/api/auth/nickname-check` |  | `api.auth.checkNickname` |
| GET | `/api/universities` |  | `api.auth.universities` |
| GET | `/api/banks` |  | `api.auth.banks` |
| POST | `/api/auth/login` |  | `api.auth.login` |
| POST | `/api/auth/logout` |  | `api.auth.logout` |
| POST | `/api/verifications/email-code` |  | `api.verification.resendEmailCode` |
| POST | `/api/verifications/email-code/confirm` |  | `api.verification.confirmEmailCode` |
| POST | `/api/verifications/capture` | (multipart) | `api.verification.submitCapture` |
| GET | `/api/verifications/me` |  | `api.verification.me` |
| GET | `/api/users/me` |  | `api.users.me` |
| PATCH | `/api/users/me` |  | `api.users.update` |
| POST | `/api/users/me/withdraw` |  | `api.users.withdraw` |
| PATCH | `/api/users/me/password` |  | `api.users.changePassword` |
| GET | `/api/users/me/account` |  | `api.users.account` |
| PUT | `/api/users/me/account` |  | `api.users.updateAccount` |
| PUT | `/api/users/me/fcm-token` |  | `api.users.updateFcmToken` |
| GET | `/api/users/me/pots` |  | `api.users.myPots` |
| GET | `/api/users/me/reports` |  | `api.users.myReports` |
| GET | `/api/users/{userId}` |  | `api.users.publicProfile` |
| GET | `/api/wallet` |  | `api.wallet.get` |
| GET | `/api/wallet/history` |  | `api.wallet.history` |
| GET | `/api/wallet/debts` |  | `api.wallet.debts` |
| POST | `/api/wallet/debts/{settlementId}/pay` |  | `api.wallet.payDebt` |
| POST | `/api/wallet/withdrawals` |  | `api.wallet.withdraw` |
| GET | `/api/wallet/withdrawals` |  | `api.wallet.withdrawals` |
| GET | `/api/payments` | (PORTONE 충전 내역 — 캡스톤 범위 외, 조회만) | `api.wallet.payments` |
| GET | `/api/pots` |  | `api.pots.list` |
| POST | `/api/pots` |  | `api.pots.create` |
| GET | `/api/pots/{potId}` |  | `api.pots.detail` |
| PATCH | `/api/pots/{potId}` |  | `api.pots.update` |
| DELETE | `/api/pots/{potId}` |  | `api.pots.cancel` |
| POST | `/api/pots/{potId}/start` |  | `api.pots.start` |
| POST | `/api/pots/{potId}/members` |  | `api.pots.join` |
| DELETE | `/api/pots/{potId}/members/me` |  | `api.pots.leave` |
| PATCH | `/api/pots/{potId}/members/me/seat` |  | `api.pots.changeSeat` |
| POST | `/api/pots/{potId}/members/me/arrival` |  | `api.pots.arrive` |
| POST | `/api/pots/{potId}/members/{userId}/kick` |  | `api.pots.kick` |
| POST | `/api/pots/{potId}/join-requests` |  | `api.pots.requestJoin` |
| GET | `/api/pots/{potId}/join-requests` |  | `api.pots.joinRequests` |
| DELETE | `/api/pots/{potId}/join-requests/me` |  | `api.pots.withdrawJoinRequest` |
| POST | `/api/pots/{potId}/join-requests/{userId}/accept` |  | `api.pots.acceptJoinRequest` |
| POST | `/api/pots/{potId}/join-requests/{userId}/reject` |  | `api.pots.rejectJoinRequest` |
| POST | `/api/pots/{potId}/fare-claim` | (multipart) | `api.pots.claimFare` |
| GET | `/api/pots/{potId}/settlement` |  | `api.pots.settlement` |
| GET | `/api/pots/{potId}/receipt` | (image) | `api.pots.receipt` |
| GET | `/api/pots/{potId}/ratings/targets` |  | `api.pots.ratingTargets` |
| POST | `/api/pots/{potId}/ratings` |  | `api.pots.rate` |
| POST | `/api/reports` |  | `api.reports.create` |
| GET | `/api/pots/{potId}/messages` |  | `api.chat.messages` |
| POST | `/api/pots/{potId}/messages` |  | `api.chat.send` |
| GET | `/api/quick-blocks` |  | `api.chat.quickBlocks` |
| GET | `/api/notifications` |  | `api.notifications.list` |
| GET | `/api/notifications/unread-count` |  | `api.notifications.unreadCount` |
| PATCH | `/api/notifications/{notificationId}/read` |  | `api.notifications.read` |
| PATCH | `/api/notifications/read-all` |  | `api.notifications.readAll` |
| GET | `/api/admin/verifications` |  | `api.admin.verifications` |
| GET | `/api/admin/verifications/{id}` |  | `api.admin.verification` |
| PATCH | `/api/admin/verifications/{id}` |  | `api.admin.reviewVerification` |
| GET | `/api/admin/verifications/{id}/capture` | (image) | `api.admin.verificationCapture` |
| GET | `/api/admin/users` |  | `api.admin.users` |
| GET | `/api/admin/users/{userId}` |  | `api.admin.user` |
| GET | `/api/admin/users/{userId}/pots` |  | `api.admin.userPots` |
| PATCH | `/api/admin/users/{userId}/status` |  | `api.admin.updateUserStatus` |
| PATCH | `/api/admin/users/{userId}/wallet` |  | `api.admin.adjustWallet` |
| GET | `/api/admin/reports` |  | `api.admin.reports` |
| PATCH | `/api/admin/reports/{reportId}` |  | `api.admin.processReport` |
| GET | `/api/admin/pots` |  | `api.admin.pots` |
| GET | `/api/admin/fare-claims` |  | `api.admin.fareClaims` |
| PATCH | `/api/admin/pots/{potId}/fare-claim` |  | `api.admin.reviewFareClaim` |
| GET | `/api/admin/pots/{potId}/receipt` | (image) | `api.admin.receipt` |
| GET | `/api/admin/statistics` |  | `api.admin.statistics` |

총 72개 엔드포인트. `POST /api/auth/refresh` 는 `src/api/http.ts` 가 401 응답 때 자동 호출합니다.
`POST /api/payments`, `POST /api/payments/confirm` (PORTONE 충전)과 `POST /api/admin/pots/batch-status` 는 명세상 캡스톤 범위 외·선택 기능이라 화면을 두지 않았습니다.

## 실시간 (STOMP)

| 항목 | 값 | 코드 |
| --- | --- | --- |
| 엔드포인트 | `/ws` (CONNECT 헤더 `Authorization: Bearer …`) | `src/api/realtime/stompClient.ts` |
| 구독 | `/topic/pots/{potId}` | `src/hooks/usePotRealtime.ts` |
| 메시지 | `CHAT_MESSAGE`, `POT_UPDATED` | 채팅·상세 화면 |
